"""Тести етапу 1 (без GUI): налаштування та локалізація."""
import json
import re
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


class SettingsTests(unittest.TestCase):
    def test_defaults_and_persistence(self):
        from core.settings_store import SettingsStore
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "settings.json"
            s = SettingsStore(p)
            self.assertEqual(s.get("theme"), "light")
            self.assertEqual(s.get("language"), "uk")
            self.assertEqual(s.get("timezone"), "Europe/Kyiv")
            s.set("theme", "dark"); s.set("language", "en")
            s2 = SettingsStore(p)
            self.assertEqual((s2.get("theme"), s2.get("language")), ("dark", "en"))

    def test_corrupt_file_falls_back(self):
        from core.settings_store import SettingsStore
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "settings.json"
            p.write_text("{broken", encoding="utf-8")
            self.assertEqual(SettingsStore(p).get("theme"), "light")

    def test_invalid_value_rejected(self):
        from core.settings_store import SettingsStore
        with tempfile.TemporaryDirectory() as d:
            s = SettingsStore(Path(d) / "s.json")
            with self.assertRaises(ValueError):
                s.set("theme", "neon")


class LocalizationTests(unittest.TestCase):
    def test_same_keys(self):
        uk = json.loads((ROOT / "localization/uk.json").read_text(encoding="utf-8"))
        en = json.loads((ROOT / "localization/en.json").read_text(encoding="utf-8"))
        self.assertEqual(set(uk), set(en))

    def test_all_used_keys_exist(self):
        uk = json.loads((ROOT / "localization/uk.json").read_text(encoding="utf-8"))
        used = set()
        for f in (ROOT / "ui").glob("*.py"):
            text = f.read_text(encoding="utf-8")
            used |= set(re.findall(r'["\']((?:nav|common|action|status|weekday|dashboard|library|queue|calendar|scheduler|history|settings|app)\.[a-z_.]+)["\']', text))
        missing = {k for k in used if k not in uk and not k.endswith(".")}
        # f-string ключі (status.{s}, weekday.{d}) перевіряються окремо
        self.assertEqual(missing, set())


if __name__ == "__main__":
    unittest.main()
