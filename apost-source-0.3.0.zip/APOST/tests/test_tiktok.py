"""Тести інтеграції з TikTok проти ЛОКАЛЬНОГО імітатора API (реальний TikTok не викликається)."""
import hashlib, json, os, socket, sys, tempfile, threading, time, unittest
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import requests

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ.setdefault("APOST_HOME", tempfile.mkdtemp(prefix="apost_test_"))

from core.database import Database
from core.scheduler_engine import SchedulerEngine
from core.settings_store import SettingsStore
from core.timeutil import DB_FMT
from publisher.tiktok_api import MB, TikTokClient, TikTokError, plan_chunks
from publisher.tiktok_auth import SecretStore, TikTokAuth, make_pkce
from publisher.tiktok_publisher import ManualPublisher, RoutingPublisher, TikTokPublisher


class MemKeyring:
    def __init__(self): self.d = {}
    def get_password(self, s, n): return self.d.get((s, n))
    def set_password(self, s, n, v): self.d[(s, n)] = v
    def delete_password(self, s, n): self.d.pop((s, n), None)


class Mock:
    """Стан імітатора TikTok."""
    def reset(self):
        self.challenge = None
        self.valid = {"act.1", "act.2"}
        self.refresh_token = "rft.1"
        self.privacy_options = ["SELF_ONLY"]
        self.max_dur = 600
        self.status_script = ["PUBLISH_COMPLETE"]
        self.status_http = 200
        self.init_error = None
        self.log = []          # (метод, шлях, тіло)
        self.uploads = []      # (Content-Range, Content-Type, bytes)
        self.revoked = []


M = Mock(); M.reset()


class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _send(self, code, body):
        raw = json.dumps(body).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw)

    def _auth(self):
        tok = (self.headers.get("Authorization") or "").replace("Bearer ", "")
        if tok not in M.valid:
            self._send(401, {"error": {"code": "access_token_invalid", "message": "bad token"}})
            return False
        return True

    def do_PUT(self):
        n = int(self.headers["Content-Length"]); data = self.rfile.read(n)
        rng = self.headers["Content-Range"]; M.uploads.append((rng, self.headers["Content-Type"], data))
        end, total = rng.split(" ")[1].split("/"); last = int(end.split("-")[1]) + 1 == int(total)
        self.send_response(201 if last else 206); self.send_header("Content-Length", "0"); self.end_headers()

    def do_GET(self):
        if not self._auth(): return
        M.log.append(("GET", self.path, None))
        self._send(200, {"data": {"user": {"open_id": "oid", "display_name": "TestUser"}},
                         "error": {"code": "ok", "message": ""}})

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0)); raw = self.rfile.read(n).decode()
        path = self.path
        if path == "/v2/oauth/token/":
            f = {k: v[0] for k, v in parse_qs(raw).items()}
            M.log.append(("POST", path, f))
            if f["client_key"] != "ck" or f["client_secret"] != "cs":
                return self._send(401, {"error": "invalid_client"})
            if f["grant_type"] == "authorization_code":
                ok = f["code"] == "good-code" and hashlib.sha256(
                    f["code_verifier"].encode()).hexdigest() == M.challenge
                if not ok: return self._send(400, {"error": "invalid_grant", "error_description": "pkce"})
                return self._send(200, {"access_token": "act.1", "refresh_token": "rft.1",
                                        "expires_in": 86400, "refresh_expires_in": 31536000, "open_id": "oid"})
            if f["refresh_token"] != M.refresh_token:
                return self._send(400, {"error": "invalid_grant"})
            M.refresh_token = "rft.2"
            return self._send(200, {"access_token": "act.2", "refresh_token": "rft.2", "expires_in": 86400})
        if path == "/v2/oauth/revoke/":
            M.revoked.append(parse_qs(raw)); return self._send(200, {})
        if not self._auth(): return
        body = json.loads(raw) if raw else {}
        M.log.append(("POST", path, body))
        ok = {"code": "ok", "message": ""}
        if path == "/v2/post/publish/creator_info/query/":
            return self._send(200, {"data": {"privacy_level_options": M.privacy_options,
                                             "max_video_post_duration_sec": M.max_dur}, "error": ok})
        if path in ("/v2/post/publish/video/init/", "/v2/post/publish/inbox/video/init/"):
            if M.init_error:
                return self._send(403, {"error": {"code": M.init_error, "message": "blocked"}})
            return self._send(200, {"data": {"publish_id": "v_pub_file~1",
                                             "upload_url": f"http://127.0.0.1:{self.server.server_port}/upload/?id=1"},
                                    "error": ok})
        if path == "/v2/post/publish/status/fetch/":
            if M.status_http != 200:
                self.send_response(M.status_http); self.send_header("Content-Length", "4"); self.end_headers()
                self.wfile.write(b"boom"); return
            st = M.status_script.pop(0) if len(M.status_script) > 1 else M.status_script[0]
            data = {"status": st}
            if st == "FAILED": data["fail_reason"] = "video_pull_failed"
            return self._send(200, {"data": data, "error": ok})
        self._send(404, {"error": {"code": "not_found"}})


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


class FakeLang:
    _tables = {"en": {}}
    def t(self, k, **kw): return k


class FakeNotifier:
    def __init__(self): self.lang = FakeLang(); self.events = []
    def time_to_publish(self, n): self.events.append(("due", n))
    def failed(self, n, r): self.events.append(("fail", n, r))
    def inbox_ready(self, n): self.events.append(("inbox", n))
    def published(self, n): self.events.append(("published", n))


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
        cls.base = f"http://127.0.0.1:{cls.srv.server_port}"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls): cls.srv.shutdown()

    def setUp(self):
        M.reset()
        self.tmp = Path(tempfile.mkdtemp())
        self.settings = SettingsStore(self.tmp / "s.json")
        self.kr = MemKeyring()
        self.client = TikTokClient(api_base=self.base, timeout=10)
        self.auth = TikTokAuth(self.settings, SecretStore(self.kr), self.client)
        self.auth.save_credentials("ck", "cs")

    def connect(self, expires_in=86400):
        self.kr.set_password("APOST-TikTok", "tokens", json.dumps({
            "access_token": "act.1", "refresh_token": "rft.1", "expires_at": time.time() + expires_in,
            "refresh_expires_at": time.time() + 10**7, "open_id": "oid"}))
        self.settings.set("tiktok_account", "TestUser")


class AuthTests(Base):
    def run_login(self, state_override=None, code="good-code"):
        port = free_port(); self.settings.set("tiktok_port", port)

        def opener(url):
            q = parse_qs(urlparse(url).query)
            self.assertEqual(q["code_challenge_method"], ["S256"])
            self.assertEqual(q["redirect_uri"], [f"http://127.0.0.1:{port}/callback/"])
            self.assertIn("video.publish", q["scope"][0])
            M.challenge = q["code_challenge"][0]
            st = state_override or q["state"][0]
            threading.Thread(target=lambda: (time.sleep(0.3), requests.get(
                f"http://127.0.0.1:{port}/callback/?code={code}&state={st}")), daemon=True).start()
        self.auth.opener = opener
        return self.auth.login(timeout=10)

    def test_plan_chunks(self):
        self.assertEqual(plan_chunks(4 * MB), [(0, 4 * MB - 1)])
        c = plan_chunks(50_000_123)       # 4 × 10 МіБ, остача входить в останню частину
        self.assertEqual(len(c), 4); self.assertEqual(c[0], (0, 10 * MB - 1))
        self.assertEqual(c[-1][1], 50_000_122)
        self.assertTrue(all(c[i][1] + 1 == c[i + 1][0] for i in range(len(c) - 1)))
        self.assertTrue(all(b - a + 1 >= 5 * MB for a, b in c))
        self.assertTrue(len(plan_chunks(10 * 1024 * MB)) <= 1000)

    def test_pkce_is_hex_sha256(self):
        v, ch = make_pkce()
        self.assertTrue(43 <= len(v) <= 128)
        self.assertEqual(ch, hashlib.sha256(v.encode()).hexdigest())

    def test_login_stores_secrets_only_in_keychain(self):
        self.assertEqual(self.run_login(), "TestUser")
        self.assertTrue(self.auth.is_connected())
        blob = (self.tmp / "s.json").read_text()
        for secret in ("act.1", "rft.1", "cs"):
            self.assertNotIn(f'"{secret}"', blob)
        self.assertNotIn("client_secret", blob)
        self.assertEqual(self.auth.access_token(), "act.1")

    def test_wrong_state_is_rejected(self):
        with self.assertRaises(TikTokError) as cm: self.run_login(state_override="evil")
        self.assertEqual(cm.exception.code, "state_mismatch")
        self.assertFalse(self.auth.is_connected())

    def test_refresh_when_expiring_and_reauth(self):
        self.connect(expires_in=60)                      # скоро спливає → refresh
        self.assertEqual(self.auth.access_token(), "act.2")
        self.connect(expires_in=60); M.refresh_token = "other"
        with self.assertRaises(TikTokError) as cm: self.auth.access_token()
        self.assertEqual(cm.exception.code, "reauth")

    def test_disconnect_revokes_and_clears(self):
        self.connect(); self.auth.disconnect()
        self.assertFalse(self.auth.is_connected()); self.assertEqual(len(M.revoked), 1)
        self.assertEqual(self.settings.get("tiktok_account"), "")

    def test_no_keychain_means_no_plaintext_fallback(self):
        class Broken:
            def set_password(self, *a): raise RuntimeError("no backend")
        auth = TikTokAuth(self.settings, SecretStore(Broken()), self.client)
        with self.assertRaises(TikTokError) as cm: auth.save_credentials("ck", "secret-value")
        self.assertEqual(cm.exception.code, "keyring_unavailable")
        self.assertNotIn("secret-value", (self.tmp / "s.json").read_text())


class PublishTests(Base):
    def setUp(self):
        super().setUp()
        self.db = Database(self.tmp / "t.db"); self.n = FakeNotifier()
        self.tt = TikTokPublisher(self.auth, self.client, self.settings)
        self.pub = RoutingPublisher(ManualPublisher(), self.tt, self.auth, self.settings)
        self.engine = SchedulerEngine(self.db, self.settings, self.pub, self.n)
        self.file = self.tmp / "v.mp4"
        self.data = os.urandom(26 * MB)                       # 2 частини
        self.file.write_bytes(self.data)
        vid = self.db.add_video(path=str(self.file), original_name="v.mp4", is_copy=False, size_bytes=len(self.data),
                                duration_sec=30.0, thumb_path=None, fingerprint="f",
                                description="Привіт", hashtags="#apost")
        self.db.add_to_queue([vid]); self.pid = self.db.queue_posts()[0]["id"]
        self.connect(); self.settings.set("tiktok_mode", "direct")
        self.due()

    def due(self):
        self.db.set_schedule(self.pid, (datetime.now(timezone.utc).replace(tzinfo=None)
                                        - timedelta(minutes=1)).strftime(DB_FMT))

    def post(self): return self.db.get_post(self.pid)

    def test_direct_post_end_to_end_confirmed_only_by_tiktok(self):
        M.status_script = ["PROCESSING_UPLOAD", "PROCESSING_UPLOAD", "PUBLISH_COMPLETE"]
        self.engine.tick()          # відправка + перша перевірка статусу
        p = self.post()
        self.assertEqual((p["status"], p["publish_id"]), ("posting", "v_pub_file~1"))   # ще НЕ опубліковано
        init = [b for m, path, b in M.log if path.endswith("/video/init/")][0]
        self.assertEqual(init["post_info"]["privacy_level"], "SELF_ONLY")
        self.assertEqual(init["post_info"]["title"], "Привіт\n\n#apost")
        self.assertEqual(init["source_info"]["total_chunk_count"], 2)
        self.assertEqual(b"".join(u[2] for u in M.uploads), self.data)                 # файл дійшов цілим
        self.assertEqual([u[0] for u in M.uploads], [f"bytes 0-{10*MB-1}/{26*MB}", f"bytes {10*MB}-{26*MB-1}/{26*MB}"])
        self.assertEqual(M.uploads[0][1], "video/mp4")
        self.engine.tick(); self.assertEqual(self.post()["status"], "posting")          # PROCESSING_UPLOAD
        self.assertEqual(self.db.stats()["published"], 0)
        self.engine.tick()
        p = self.post(); self.assertEqual((p["status"], p["confirmed_by"]), ("published", "tiktok"))
        self.assertIn(("published", "v.mp4"), self.n.events)

    def test_inbox_mode_goes_to_drafts_not_published(self):
        self.settings.set("tiktok_mode", "inbox"); M.status_script = ["SEND_TO_USER_INBOX"]
        self.engine.tick()
        paths = [path for _, path, _ in M.log]
        self.assertIn("/v2/post/publish/inbox/video/init/", paths)
        self.assertNotIn("/v2/post/publish/video/init/", paths)
        p = self.post(); self.assertEqual((p["status"], p["manual_due"]), ("scheduled", 1))
        self.assertEqual(self.db.history("manual")[0]["message"], "inbox")

    def test_failed_status_becomes_error_with_reason(self):
        M.status_script = ["FAILED"]; self.engine.tick(); self.engine.tick()
        p = self.post(); self.assertEqual((p["status"], p["error"]), ("error", "video_pull_failed"))

    def test_privacy_not_allowed_blocks_before_upload(self):
        self.settings.set("tiktok_privacy", "PUBLIC_TO_EVERYONE")
        self.engine.tick()
        self.assertEqual(self.post()["error"], "privacy_not_allowed"); self.assertEqual(M.uploads, [])

    def test_unaudited_client_error_is_reported_honestly(self):
        M.init_error = "spam_risk_user_banned_from_posting"; self.engine.tick()
        p = self.post(); self.assertEqual((p["status"], p["error"]), ("error", "spam_risk_user_banned_from_posting"))

    def test_too_long_video_blocked(self):
        M.max_dur = 10; self.engine.tick()
        self.assertEqual(self.post()["error"], "too_long")

    def test_temporary_status_failure_keeps_waiting(self):
        M.status_script = ["PROCESSING_UPLOAD"]
        self.engine.tick(); M.status_http = 500
        self.engine.tick(); self.assertEqual(self.post()["status"], "posting")          # не «Помилка» і не «Опубліковано»
        M.status_http = 200; M.status_script = ["PUBLISH_COMPLETE"]; self.engine.tick()
        self.assertEqual(self.post()["status"], "published")

    def test_expired_login_reports_reauth(self):
        self.kr.d.clear(); self.auth.save_credentials("ck", "cs")                       # токенів нема
        self.settings.set("tiktok_mode", "direct")
        self.engine.tick()                                                              # не підключено → ручний режим
        p = self.post(); self.assertEqual((p["status"], p["manual_due"]), ("scheduled", 1))
        self.assertEqual([x for x in M.log if "init" in x[1]], [])

    def test_restart_resumes_waiting_for_tiktok(self):
        M.status_script = ["PROCESSING_UPLOAD", "PUBLISH_COMPLETE"]
        self.engine.tick(); self.assertEqual(self.post()["status"], "posting")
        engine2 = SchedulerEngine(self.db, self.settings, self.pub, FakeNotifier())     # «перезапуск»
        engine2.recover(); self.assertEqual(self.post()["status"], "posting")           # не втрачено
        engine2.tick(); self.assertEqual(self.post()["status"], "published")

    def test_posting_without_publish_id_is_interrupted(self):
        self.db.claim_post(self.pid); self.engine.recover()
        self.assertEqual(self.post()["error"], "interrupted")

    def test_no_double_publish(self):
        M.status_script = ["PROCESSING_UPLOAD"]
        self.engine.tick(); self.engine.tick(); self.engine.tick()
        self.assertEqual(len([p for _, p, _ in M.log if p.endswith("/video/init/")]), 1)


if __name__ == "__main__":
    unittest.main()
