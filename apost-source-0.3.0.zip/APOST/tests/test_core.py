"""Тести ядра: розподіл, БД, імпорт відео (реальний ffmpeg), планувальник."""
import os
import subprocess
import sys
import tempfile
import unittest
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ.setdefault("APOST_HOME", tempfile.mkdtemp(prefix="apost_test_"))

from core import config
from core.database import Database
from core.schedule_planner import (ScheduleConfig, day_times, generate_slots, interval_minutes,
                                   last_from_interval)
from core.settings_store import SettingsStore
from core.timeutil import DB_FMT, local_to_utc_str, utc_str_to_local, utcnow_str
from utils import video_utils


class PlannerTests(unittest.TestCase):
    NOW = datetime(2026, 11, 7, 10, 0)

    def test_three_per_day_times(self):
        cfg = ScheduleConfig(per_day=3, first=time(12, 0), last=time(20, 0))
        self.assertEqual(day_times(cfg), [time(12), time(16), time(20)])
        self.assertEqual(interval_minutes(cfg), 240)
        self.assertEqual(last_from_interval(time(12), 3, 240), time(20))

    def test_30_videos_over_10_days(self):
        cfg = ScheduleConfig(per_day=3, first=time(12), last=time(20))
        slots = generate_slots(cfg, 30, self.NOW)
        self.assertEqual(len(slots), 30)
        self.assertEqual(slots[0], datetime(2026, 11, 7, 12, 0))
        self.assertEqual(slots[-1], datetime(2026, 11, 16, 20, 0))
        self.assertEqual(len({s.date() for s in slots}), 10)

    def test_past_slots_skipped(self):
        cfg = ScheduleConfig(per_day=3, first=time(12), last=time(20))
        slots = generate_slots(cfg, 3, datetime(2026, 11, 7, 13, 0))
        self.assertEqual(slots[0], datetime(2026, 11, 7, 16, 0))

    def test_weekdays_and_end_date(self):
        cfg = ScheduleConfig(per_day=1, first=time(9), weekdays={0, 2},  # Пн, Ср
                             start=date(2026, 11, 9), end=date(2026, 11, 20))
        slots = generate_slots(cfg, 100, self.NOW)
        self.assertTrue(all(s.weekday() in (0, 2) for s in slots))
        self.assertEqual([s.date().day for s in slots], [9, 11, 16, 18])  # обмежено end

    def test_taken_slots_not_reused(self):
        cfg = ScheduleConfig(per_day=1, first=time(12))
        taken = {datetime(2026, 11, 7, 12, 0)}
        self.assertEqual(generate_slots(cfg, 1, self.NOW, taken)[0], datetime(2026, 11, 8, 12, 0))

    def test_validation(self):
        self.assertEqual(ScheduleConfig(per_day=0).validate(), "per_day")
        self.assertEqual(ScheduleConfig(per_day=2, first=time(20), last=time(12)).validate(), "time_order")
        self.assertEqual(ScheduleConfig(weekdays=set()).validate(), "no_weekdays")

    def test_timezone_roundtrip(self):
        local = datetime(2026, 7, 1, 12, 0)
        utc = local_to_utc_str(local, "Europe/Kyiv")
        self.assertEqual(utc, "2026-07-01 09:00:00")  # літо: UTC+3
        self.assertEqual(utc_str_to_local(utc, "Europe/Kyiv"), local)


def make_video(path: Path, seconds: int = 2) -> None:
    ff = video_utils.find_ffmpeg()
    subprocess.run([ff, "-y", "-loglevel", "error", "-f", "lavfi", "-i",
                    f"testsrc=duration={seconds}:size=360x640:rate=15", "-pix_fmt", "yuv420p",
                    str(path)], check=True)


class DbTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.tmp.name) / "t.db")

    def tearDown(self):
        self.db.close(); self.tmp.cleanup()

    def vid(self, n):
        return self.db.add_video(path=f"/x/{n}.mp4", original_name=f"{n}.mp4", is_copy=False,
                                 size_bytes=10, duration_sec=5.0, thumb_path=None, fingerprint=str(n))

    def test_queue_and_no_duplicates(self):
        a, b = self.vid(1), self.vid(2)
        self.assertEqual(self.db.add_to_queue([a, b, a]), 2)
        self.assertEqual(self.db.add_to_queue([a]), 0)          # вдруге не додається
        self.assertEqual([p["video_id"] for p in self.db.queue_posts()], [a, b])

    def test_schedule_and_claim_exactly_once(self):
        a = self.vid(1); self.db.add_to_queue([a]); pid = self.db.queue_posts()[0]["id"]
        self.db.set_schedule(pid, "2026-01-01 10:00:00")
        self.assertEqual(self.db.get_post(pid)["status"], "scheduled")
        self.assertEqual(len(self.db.due_posts("2026-01-01 10:00:01")), 1)
        self.assertTrue(self.db.claim_post(pid))
        self.assertFalse(self.db.claim_post(pid))                # повторно — неможливо
        self.assertEqual(len(self.db.due_posts("2030-01-01 00:00:00")), 0)

    def test_move_post(self):
        ids = [self.vid(i) for i in range(3)]; self.db.add_to_queue(ids)
        pid = self.db.queue_posts()[2]["id"]
        self.db.move_post(pid, -1)
        self.assertEqual(self.db.queue_posts()[1]["id"], pid)
        self.db.move_post(self.db.queue_posts()[0]["id"], -1)    # вже перший — без змін

    def test_stats_history_and_cascade(self):
        a = self.vid(1); self.db.add_to_queue([a]); pid = self.db.queue_posts()[0]["id"]
        self.db.mark_error(pid, "1.mp4", "missed")
        self.assertEqual(self.db.stats()["failed"], 1)
        self.assertEqual(self.db.stats()["missed"], 1)
        self.assertEqual(self.db.history(status="error")[0]["message"], "missed")
        self.db.delete_video(a)
        self.assertEqual(self.db.stats()["failed"], 0)           # публікації видалено
        self.assertEqual(len(self.db.history()), 1)              # історія збережена

    def test_persistence(self):
        a = self.vid(1); self.db.add_to_queue([a]); self.db.close()
        db2 = Database(Path(self.tmp.name) / "t.db")
        self.assertEqual(db2.stats()["total_videos"], 1)
        self.assertEqual(db2.stats()["in_queue"], 1); db2.close()
        self.db = Database(Path(self.tmp.name) / "t.db")


class VideoImportTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        config.VIDEOS_DIR, config.THUMBS_DIR = self.tmp / "videos", self.tmp / "thumbs"
        self.db = Database(self.tmp / "t.db")
        self.settings = SettingsStore(self.tmp / "s.json")
        from core.video_manager import VideoManager
        self.vm = VideoManager(self.db, self.settings)

    def test_import_probe_thumbnail_duplicate(self):
        self.assertIsNotNone(video_utils.find_ffmpeg(), "ffmpeg недоступний")
        f = self.tmp / "clip.mp4"; make_video(f, 2)
        r = self.vm.import_files([str(f)])
        self.assertEqual(len(r.added), 1)
        row = self.db.get_video(r.added[0])
        self.assertAlmostEqual(row["duration_sec"], 2.0, delta=0.6)
        self.assertTrue(Path(row["thumb_path"]).exists())
        self.assertEqual(row["path"], str(f))                    # без копії
        self.assertEqual(self.vm.import_files([str(f)]).skipped[0][1], "duplicate")

    def test_rejects_bad_files(self):
        txt = self.tmp / "a.txt"; txt.write_text("x")
        fake = self.tmp / "fake.mp4"; fake.write_bytes(b"not a video" * 100)
        empty = self.tmp / "e.mp4"; empty.write_bytes(b"")
        r = self.vm.import_files([str(txt), str(fake), str(empty), str(self.tmp / "none.mp4")])
        self.assertEqual({c for _, c in r.skipped}, {"not_mp4", "unreadable", "empty", "not_found"})
        self.assertEqual(self.db.stats()["total_videos"], 0)

    def test_copy_mode_and_delete_keeps_original(self):
        self.settings.set("copy_videos", True)
        f = self.tmp / "orig.mp4"; make_video(f, 1)
        vid = self.vm.import_files([str(f)]).added[0]
        stored = Path(self.db.get_video(vid)["path"])
        self.assertTrue(stored.exists() and stored != f)
        self.vm.delete_video(vid)
        self.assertFalse(stored.exists())
        self.assertTrue(f.exists())                              # оригінал не видаляється

    def test_vertical_videos_mp4_mov_and_rotated(self):
        ff = video_utils.find_ffmpeg()
        d = self.tmp / "Моє відео"; d.mkdir()
        mp4 = d / "вертикальне 1.MP4"; mov = d / "IMG 0001.MOV"; rot = d / "rotated.mov"; webm = d / "w.webm"
        base = [ff, "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc=duration=2:size=1080x1920:rate=15",
                "-pix_fmt", "yuv420p"]
        subprocess.run(base + [str(mp4)], check=True)
        subprocess.run(base + ["-f", "mov", str(mov)], check=True)
        # як на iPhone: кадр 1920x1080 + тег повороту на 90°
        subprocess.run([ff, "-y", "-loglevel", "error", "-f", "lavfi", "-i",
                        "testsrc=duration=2:size=1920x1080:rate=15", "-pix_fmt", "yuv420p",
                        "-metadata:s:v", "rotate=90", str(rot)], check=True)
        subprocess.run([ff, "-y", "-loglevel", "error", "-f", "lavfi", "-i",
                        "testsrc=duration=1:size=360x640:rate=15", str(webm)], check=True)
        r = self.vm.import_files([str(mp4), str(mov), str(rot), str(webm)])
        self.assertEqual(r.skipped, [], r.skipped)
        self.assertEqual(len(r.added), 4)
        for vid in r.added:
            row = self.db.get_video(vid)
            self.assertTrue(row["thumb_path"] and Path(row["thumb_path"]).exists())
            self.assertGreater(row["duration_sec"], 0.5)

    def test_hashtags(self):
        from core.video_manager import normalize_hashtags
        self.assertEqual(normalize_hashtags("a, #b  c #A"), "#a #b #c")


class FakeLang:
    _tables = {}
    def t(self, k, **kw): return k


class FakeNotifier:
    def __init__(self): self.lang = FakeLang(); self.events = []
    def time_to_publish(self, n): self.events.append(("due", n))
    def failed(self, n, r): self.events.append(("fail", n, r))
    def inbox_ready(self, n): self.events.append(("inbox", n))
    def published(self, n): self.events.append(("published", n))


class EngineTests(unittest.TestCase):
    def setUp(self):
        from core.scheduler_engine import SchedulerEngine
        from publisher.tiktok_publisher import ManualPublisher
        self.tmp = Path(tempfile.mkdtemp())
        self.db = Database(self.tmp / "t.db")
        self.settings = SettingsStore(self.tmp / "s.json")
        self.n = FakeNotifier()
        self.engine = SchedulerEngine(self.db, self.settings, ManualPublisher(), self.n)
        self.file = self.tmp / "v.mp4"; self.file.write_bytes(b"x")
        v = self.db.add_video(path=str(self.file), original_name="v.mp4", is_copy=False,
                              size_bytes=1, duration_sec=1, thumb_path=None, fingerprint="f")
        self.db.add_to_queue([v]); self.pid = self.db.queue_posts()[0]["id"]

    def at(self, minutes_from_now):
        return (datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(minutes=minutes_from_now)).strftime(DB_FMT)

    def test_due_goes_manual_and_never_published_automatically(self):
        self.db.set_schedule(self.pid, self.at(-1))
        self.engine.tick()
        p = self.db.get_post(self.pid)
        self.assertEqual((p["status"], p["manual_due"]), ("scheduled", 1))
        self.assertNotEqual(p["status"], "published")
        self.assertEqual(self.n.events, [("due", "v.mp4")])
        self.engine.tick()                                       # повторний tick нічого не робить
        self.assertEqual(len(self.n.events), 1)

    def test_user_confirmation_publishes(self):
        self.db.set_schedule(self.pid, self.at(-1)); self.engine.tick()
        self.db.mark_published(self.pid, "v.mp4", "user")
        p = self.db.get_post(self.pid)
        self.assertEqual((p["status"], p["confirmed_by"]), ("published", "user"))
        self.assertEqual(self.db.stats()["published"], 1)

    def test_future_not_touched(self):
        self.db.set_schedule(self.pid, self.at(30)); self.engine.tick()
        self.assertEqual(self.db.get_post(self.pid)["manual_due"], 0)

    def test_missed_after_downtime(self):
        self.db.set_schedule(self.pid, self.at(-120))
        self.engine.recover()
        p = self.db.get_post(self.pid)
        self.assertEqual((p["status"], p["error"]), ("error", "missed"))

    def test_pause_blocks_and_resume_marks_late_as_missed(self):
        self.db.set_schedule(self.pid, self.at(-1))
        self.engine.pause(); self.engine.tick()
        self.assertEqual(self.db.get_post(self.pid)["manual_due"], 0)
        self.engine.resume()
        self.assertFalse(self.engine.paused)

    def test_interrupted_posting_is_error(self):
        self.db.set_schedule(self.pid, self.at(-1)); self.db.claim_post(self.pid)
        self.engine.recover()
        self.assertEqual(self.db.get_post(self.pid)["error"], "interrupted")

    def test_missing_file_is_error(self):
        self.db.set_schedule(self.pid, self.at(-1)); self.file.unlink()
        self.engine.tick()
        self.assertEqual(self.db.get_post(self.pid)["error"], "file_missing")

    def test_background_scheduler_runs(self):
        self.db.set_schedule(self.pid, self.at(-1))
        self.engine.start()
        import time as _t
        for _ in range(30):
            if self.db.get_post(self.pid)["manual_due"]: break
            _t.sleep(0.1)
        self.engine.stop()
        self.assertEqual(self.db.get_post(self.pid)["manual_due"], 1)


if __name__ == "__main__":
    unittest.main()
