"""Інтеграційний GUI-тест (потрібен дисплей; на Linux — xvfb-run)."""
import os, sys, tempfile, time, subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
HOME = os.environ.setdefault("APOST_HOME", tempfile.mkdtemp(prefix="apost_gui_"))

import customtkinter as ctk
from core import config
config.ensure_dirs()
from utils.logger import setup_logging
setup_logging()
from core.bootstrap import build_context
from ui.app_window import AppWindow, PAGES
import ui.calendar as _cal, ui.queue as _q, ui.video_library as _lib, ui.scheduler_page as _sp
from utils import video_utils

def _raise(*a, **k): raise
_cal.log.exception = _raise                     # помилки календаря валять тест
for m in (_q, _lib, _sp):                       # діалоги без блокування
    m.ask = lambda *a, **k: True
    if hasattr(m, "info"): m.info = lambda *a, **k: None

shots = os.environ.get("SHOTS")
def pump(app, sec=0.3):
    end = time.time() + sec
    while time.time() < end:
        app.update(); time.sleep(0.02)
def snap(app, name):
    if not shots: return
    from PIL import ImageGrab
    pump(app, 0.4); ImageGrab.grab().save(f"{shots}/{name}.png")

def boot():
    ctx = build_context()
    app = AppWindow(ctx); app.report_callback_exception = lambda e, v, t: (_ for _ in ()).throw(v)
    return ctx, app

# ---------------- 1. перший запуск ----------------
ctx, app = boot(); pump(app)
assert ctk.get_appearance_mode() == "Light" and ctx.lang.code == "uk"
for key in PAGES: app.show_page(key); pump(app, 0.1)
print("DnD доступний:", app.dnd_ok)
snap(app, "01_dashboard_empty")

# ---------------- 2. імпорт реальних відео ----------------
ff = video_utils.find_ffmpeg(); src = Path(tempfile.mkdtemp())
paths = []
for i in range(1, 7):
    p = src / f"clip_{i}.mp4"
    subprocess.run([ff, "-y", "-loglevel", "error", "-f", "lavfi", "-i",
                    f"testsrc2=duration={i+1}:size=360x640:rate=15", "-pix_fmt", "yuv420p", str(p)], check=True)
    paths.append(str(p))
(src / "notes.txt").write_text("x"); paths.append(str(src / "notes.txt"))
app.show_page("library"); lib = app.pages["library"]
lib.import_paths(paths)
for _ in range(100):
    pump(app, 0.1)
    if not lib._importing: break
assert not lib._importing, "імпорт завис"
assert ctx.db.stats()["total_videos"] == 6, ctx.db.stats()
v = ctx.db.list_videos()[0]
assert v["thumb_path"] and Path(v["thumb_path"]).exists()
snap(app, "02_library")

# опис і хештеги
from ui.dialogs import EditDialog
first = ctx.db.list_videos()[-1]
dlg = EditDialog(app, ctx, video_id=first["id"]); pump(app, 0.3)
dlg.desc.insert("1.0", "Мій перший пост"); dlg.tags.insert(0, "apost, #tiktok  ukraine"); dlg.save(); pump(app, 0.2)
row = ctx.db.get_video(first["id"]); assert row["description"] == "Мій перший пост"
assert row["hashtags"] == "#apost #tiktok #ukraine", row["hashtags"]

# ---------------- 3. черга ----------------
lib._all_to_queue(); pump(app, 1.3)
assert ctx.db.stats()["in_queue"] == 6
app.show_page("queue"); pump(app, 0.3)
qpage = app.pages["queue"]
ids = [p["id"] for p in ctx.db.queue_posts()]
ctx.db.move_post(ids[1], -1); pump(app, 1.3)           # зміна порядку
assert [p["id"] for p in ctx.db.queue_posts()][0] == ids[1]
snap(app, "03_queue_pending")

# ---------------- 4. планувальник ----------------
app.show_page("scheduler"); sp = app.pages["scheduler"]; pump(app, 0.3)
def setf(k, val): sp.e[k].delete(0, "end"); sp.e[k].insert(0, val)
setf("per_day", "3"); setf("first", "12:00"); setf("last", "20:00")
sp._on_key("last"); assert sp.e["interval"].get() == "240", sp.e["interval"].get()
setf("interval", "180"); sp._on_key("interval"); assert sp.e["last"].get() == "18:00"
setf("last", "20:00"); sp._on_key("last"); pump(app, 0.5)
snap(app, "04_scheduler_preview")
sp._apply(); pump(app, 0.3)
st = ctx.db.stats(); assert st["scheduled"] == 6, st
times = sorted(ctx.to_local(p["scheduled_at"]) for p in ctx.db.queue_posts())
assert [t.strftime("%H:%M") for t in times[:3]] == ["12:00", "16:00", "20:00"] or times[0] > ctx.now_local()
assert len({t for t in times}) == 6, "дублікати слотів"
sp.e["per_day"].delete(0, "end"); sp.e["per_day"].insert(0, "0"); sp._on_key("per_day"); sp.refresh_preview()
assert "24" in sp.err.cget("text"), "валідація не спрацювала"
setf("per_day", "3"); sp._on_key("per_day")

# ---------------- 5. календар ----------------
app.show_page("calendar"); cal = app.pages["calendar"]; cal.refresh(force=True); pump(app, 0.3)
first_day = min(times).date(); cal.anchor = first_day; cal._render(); pump(app, 0.3)
assert len(cal.events) == 6, len(cal.events)
snap(app, "05_calendar_month")
cal._on_view(cal._view_names["week"]); pump(app, 0.3); snap(app, "06_calendar_week")
cal._on_view(cal._view_names["day"]); pump(app, 0.3)
cal._on_view(cal._view_names["month"]); pump(app, 0.2)
cells = [w for w in cal.content.winfo_children()[0].winfo_children() if w.winfo_height() > 30]
assert min(w.winfo_height() for w in cells) > 60, "клітинки схлопнулись"

# редагування часу через діалог з календаря
ev = cal.events[0]
d = EditDialog(app, ctx, post_id=ev.id); pump(app, 0.2)
new_dt = (ctx.now_local() + timedelta(days=30)).replace(hour=18, minute=30, second=0, microsecond=0)
d.date_e.delete(0, "end"); d.date_e.insert(0, new_dt.strftime("%Y-%m-%d"))
d.time_e.delete(0, "end"); d.time_e.insert(0, "18:30"); d.save(); pump(app, 0.2)
assert ctx.to_local(ctx.db.get_post(ev.id)["scheduled_at"]) == new_dt
d = EditDialog(app, ctx, post_id=ev.id); pump(app, 0.2)       # минулий час відхиляється
d.date_e.delete(0, "end"); d.date_e.insert(0, "2020-01-01"); d.save()
assert d.winfo_exists() and "минув" in d.err.cget("text"), d.err.cget("text")
d.destroy()

# ---------------- 6. настав час публікації ----------------
target = ctx.db.queue_posts()[0]["id"]
ctx.db.set_schedule(target, (datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(minutes=1)).strftime("%Y-%m-%d %H:%M:%S"))
ctx.engine.tick(); pump(app, 1.5)
p = ctx.db.get_post(target); assert (p["status"], p["manual_due"]) == ("scheduled", 1), dict(p)
assert ctx.db.stats()["published"] == 0, "без підтвердження не можна «Опубліковано»"
app.show_page("dashboard"); app.pages["dashboard"].refresh(force=True); snap(app, "07_dashboard_attention")
app.show_page("queue"); qpage.refresh(force=True); snap(app, "08_queue_manual_due")
qpage._confirm(ctx.db.get_post(target)); pump(app, 0.3)
assert ctx.db.get_post(target)["status"] == "published" and ctx.db.get_post(target)["confirmed_by"] == "user"

# пропущене завдання: час давно минув
miss = ctx.db.queue_posts()[0]["id"]
ctx.db.set_schedule(miss, (datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(hours=5)).strftime("%Y-%m-%d %H:%M:%S"))
ctx.engine.tick(); assert ctx.db.get_post(miss)["error"] == "missed"
qpage.refresh(force=True); qpage._reschedule_missed(); pump(app, 0.3)
rp = ctx.db.get_post(miss); assert rp["status"] == "scheduled" and rp["error"] is None
snap(app, "09_queue_after_reschedule")

# ---------------- 7. історія ----------------
app.show_page("history"); hp = app.pages["history"]; hp.refresh(force=True); pump(app, 0.3)
assert len(ctx.db.history()) >= 3
snap(app, "10_history")
hp.status_menu.set(hp.t("history.event.published")); hp.refresh(force=True)
assert all(r["status"] == "published" for r in ctx.db.history("published"))

# ---------------- 7b. доробки етапів 2–3 ----------------
# (а) порційний показ списків: 150 відео → 25 + «Показати ще»
for i in range(150):
    ctx.db.add_video(path=f"/nowhere/v{i}.mp4", original_name=f"bulk_{i:03d}.mp4", is_copy=False,
                     size_bytes=10, duration_sec=5.0, thumb_path=None, fingerprint=f"b{i}")
app.show_page("library"); lib.refresh(force=True); pump(app, 0.3)
assert lib._paged.n == 25 and len(lib._paged.rows) == 156, (lib._paged.n, len(lib._paged.rows))
lib._paged.more(); pump(app, 0.3); assert lib._paged.n == 50
# (б) відсутній файл відео позначається
rows = lib.holder.winfo_children()
assert not os.path.exists("/nowhere/v0.mp4")
# (в) ліміт довжини опису TikTok (2200)
vid = ctx.db.list_videos()[-1]["id"]
dlg = EditDialog(app, ctx, video_id=vid); pump(app, 0.2)
dlg.desc.insert("1.0", "x" * 2300); dlg.save()
assert dlg.winfo_exists() and "2200" in dlg.err.cget("text"); dlg.destroy()
# (г) графік у Налаштуваннях ↔ Планувальник
app.show_page("settings"); stp = app.pages["settings"]
for k, v in (("per_day", "2"), ("first", "10:00"), ("last", "18:00")):
    stp.sch[k].delete(0, "end"); stp.sch[k].insert(0, v)
stp._save_schedule(); pump(app, 0.2)
from core import planning_service
c = planning_service.load_config(ctx.settings); assert (c.per_day, c.first.hour, c.last.hour) == (2, 10, 18)
app.show_page("scheduler"); pump(app, 0.3)
assert app.pages["scheduler"].e["per_day"].get() == "2" and app.pages["scheduler"].e["first"].get() == "10:00"
stp.sch["per_day"].delete(0, "end"); stp.sch["per_day"].insert(0, "99"); stp._save_schedule()
assert "24" in stp.sch_msg.cget("text")
# (д) календар: кількість публікацій за день
cal.anchor = min(times).date(); cal._on_view(cal._view_names["month"]); app.show_page("calendar"); pump(app, 0.4)
assert any(len(cal._events_on(d)) >= 2 for d in {e.start.date() for e in cal.events})
snap(app, "12_calendar_counts")
for w in lib.winfo_children(): pass
# повертаємо чисту БД для подальших кроків: видаляємо службові відео
for v in ctx.db.list_videos():
    if v["original_name"].startswith("bulk_"):
        ctx.db.delete_video(v["id"])

# (е) TikTok у Налаштуваннях: підключення через ЛОКАЛЬНИЙ імітатор API
import threading, requests
from urllib.parse import parse_qs, urlparse
from http.server import ThreadingHTTPServer
from tests.test_tiktok import H, M, free_port, MemKeyring
from publisher.tiktok_auth import SecretStore
srv = ThreadingHTTPServer(("127.0.0.1", 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
M.reset(); auth = ctx.tiktok
auth.client.base = f"http://127.0.0.1:{srv.server_port}"; auth.store = SecretStore(MemKeyring())
app.show_page("settings"); stp = app.pages["settings"]; pump(app, 0.3)
stp._tt_connect(); assert "Client Key" in stp.tt_msg.cget("text"), "без ключів підключення неможливе"
stp.tt_key.insert(0, "ck"); stp.tt_secret.insert(0, "cs"); stp._tt_save_keys(); pump(app, 0.2)
assert auth.is_configured() and ctx.settings.get("tiktok_client_key") == "ck"
assert "cs" not in open(config.SETTINGS_FILE, encoding="utf-8").read().replace('"ck"', ""), "секрет у settings.json!"
port = free_port(); ctx.settings.set("tiktok_port", port)
def _opener(url):
    q = parse_qs(urlparse(url).query); M.challenge = q["code_challenge"][0]
    threading.Thread(target=lambda: (time.sleep(0.4), requests.get(
        f"http://127.0.0.1:{port}/callback/?code=good-code&state={q['state'][0]}")), daemon=True).start()
auth.opener = _opener
stp._tt_connect(); assert "браузері" in stp.tt_msg.cget("text")
for _ in range(150):
    pump(app, 0.1)
    if "TestUser" in stp.tt_status.cget("text"): break
assert "TestUser" in stp.tt_status.cget("text"), stp.tt_msg.cget("text")
assert auth.is_connected()
stp._tt_check()
for _ in range(100):
    pump(app, 0.1)
    if "Лише я" in stp.tt_msg.cget("text"): break
assert "Лише я" in stp.tt_msg.cget("text"), stp.tt_msg.cget("text")
stp._tt_mode(stp._mode_names["direct"]); assert ctx.settings.get("tiktok_mode") == "direct"
stp._tt_privacy(stp._privacy["PUBLIC_TO_EVERYONE"]); assert ctx.settings.get("tiktok_privacy") == "PUBLIC_TO_EVERYONE"
stp._tt_privacy(stp._privacy["SELF_ONLY"])
pump(app, 0.5)
for w in stp.body.winfo_children():
    if isinstance(w, ctk.CTkScrollableFrame): w._parent_canvas.yview_moveto(0.62)
pump(app, 0.6)
snap(app, "13_settings_tiktok")
stp._tt_disconnect(); assert not auth.is_connected() and len(M.revoked) == 1
ctx.settings.set("tiktok_mode", "manual"); srv.shutdown()

# ---------------- 8. пауза, тема, мова ----------------
sp = app.pages["scheduler"]; sp._toggle_engine(); assert ctx.engine.paused; sp._toggle_engine(); assert not ctx.engine.paused
app.show_page("settings"); stp = app.pages["settings"]
stp._on_theme(stp._theme_names["dark"]); pump(app, 0.3)
assert ctk.get_appearance_mode() == "Dark"
for key in ("dashboard", "library", "queue", "calendar", "scheduler", "history"):
    app.show_page(key); pump(app, 0.2); snap(app, f"dark_{key}")
app.show_page("settings"); app.pages["settings"]._on_language("English"); pump(app, 0.5)
assert ctx.lang.code == "en" and app.current == "settings"
for key in PAGES: app.show_page(key); pump(app, 0.15)
snap(app, "11_settings_en_dark")
stats_before = ctx.db.stats()
ctx.engine.stop(); ctx.db.close(); app.destroy()

# ---------------- 9. перезапуск: усе збереглось ----------------
import utils.icons, ui.widgets
ctx2, app2 = boot(); pump(app2, 0.3)
assert ctx2.db.stats() == stats_before, (ctx2.db.stats(), stats_before)
assert ctk.get_appearance_mode() == "Dark" and ctx2.lang.code == "en"
ctx2.engine.start(); pump(app2, 0.5)
assert ctx2.engine.state() == "running"
app2.on_close()
print("GUI SMOKE OK")
