"""Тонкий клієнт офіційного TikTok API (Login Kit v2 + Content Posting API).

Лише документовані ендпоінти. Жодної автоматизації браузера й підроблених запитів.
"""
from __future__ import annotations

import os
from pathlib import Path

import requests

from utils.logger import get_logger

log = get_logger("tiktok.api")

AUTH_URL = "https://www.tiktok.com/v2/auth/authorize/"
API_BASE = "https://open.tiktokapis.com"
SCOPES = "user.info.basic,video.publish,video.upload"

MB = 1024 * 1024
MIN_CHUNK, TARGET_CHUNK = 5 * MB, 10 * MB
MIME = {".mp4": "video/mp4", ".mov": "video/quicktime", ".m4v": "video/mp4", ".webm": "video/webm"}


class TikTokError(Exception):
    """Помилка API. `code` — код TikTok (наприклад access_token_invalid) або внутрішній."""

    def __init__(self, code: str, message: str = "", http: int | None = None) -> None:
        super().__init__(f"{code}: {message}" if message else code)
        self.code, self.message, self.http = code, message, http

    @property
    def needs_reauth(self) -> bool:
        return self.code in {"access_token_invalid", "invalid_grant", "reauth", "scope_not_authorized"}


def plan_chunks(size: int) -> list[tuple[int, int]]:
    """Розбиття файлу на частини (first_byte, last_byte) за правилами TikTok.

    <5 МБ — одним запитом; інакше частини по 10 МБ, остача приєднується до останньої.
    """
    if size <= 0:
        raise TikTokError("empty_file")
    if size < MIN_CHUNK:
        return [(0, size - 1)]
    step = TARGET_CHUNK
    if size // step > 1000:                      # ліміт TikTok: не більше 1000 частин
        step = min(-(-size // 1000), 64 * MB)
    total = max(size // step, 1)
    chunks = [(i * step, (i + 1) * step - 1) for i in range(total - 1)]
    chunks.append(((total - 1) * step, size - 1))
    return chunks


class TikTokClient:
    def __init__(self, api_base: str = API_BASE, timeout: int = 30) -> None:
        self.base, self.timeout = api_base.rstrip("/"), timeout
        self.http = requests.Session()

    # ---------- службове ----------
    def _json(self, resp: requests.Response) -> dict:
        try:
            body = resp.json()
        except ValueError:
            raise TikTokError("bad_response", resp.text[:200], resp.status_code)
        err = body.get("error")
        if isinstance(err, dict):                       # {"error": {"code": "...", "message": "..."}}
            if err.get("code") not in (None, "", "ok"):
                raise TikTokError(err["code"], err.get("message", ""), resp.status_code)
        elif err:                                       # OAuth: {"error": "invalid_grant", ...}
            raise TikTokError(str(err), body.get("error_description", ""), resp.status_code)
        if resp.status_code >= 400:
            raise TikTokError("http_error", resp.text[:200], resp.status_code)
        return body

    def _post(self, path: str, token: str | None = None, json: dict | None = None,
              data: dict | None = None) -> dict:
        headers = {"Authorization": f"Bearer {token}"} if token else {}
        if json is not None:
            headers["Content-Type"] = "application/json; charset=UTF-8"
        try:
            r = self.http.post(self.base + path, headers=headers, json=json, data=data,
                               timeout=self.timeout)
        except requests.RequestException as exc:
            raise TikTokError("network", str(exc)[:200]) from exc
        return self._json(r)

    # ---------- OAuth ----------
    def exchange_code(self, client_key: str, client_secret: str, code: str, redirect_uri: str,
                      verifier: str) -> dict:
        return self._post("/v2/oauth/token/", data={
            "client_key": client_key, "client_secret": client_secret, "code": code,
            "grant_type": "authorization_code", "redirect_uri": redirect_uri,
            "code_verifier": verifier})

    def refresh(self, client_key: str, client_secret: str, refresh_token: str) -> dict:
        return self._post("/v2/oauth/token/", data={
            "client_key": client_key, "client_secret": client_secret,
            "grant_type": "refresh_token", "refresh_token": refresh_token})

    def revoke(self, client_key: str, client_secret: str, token: str) -> None:
        self._post("/v2/oauth/revoke/", data={
            "client_key": client_key, "client_secret": client_secret, "token": token})

    # ---------- дані акаунта ----------
    def user_info(self, token: str) -> dict:
        try:
            r = self.http.get(self.base + "/v2/user/info/?fields=open_id,display_name",
                              headers={"Authorization": f"Bearer {token}"}, timeout=self.timeout)
        except requests.RequestException as exc:
            raise TikTokError("network", str(exc)[:200]) from exc
        return self._json(r).get("data", {}).get("user", {})

    def creator_info(self, token: str) -> dict:
        """Перевірка права публікувати + дозволені рівні приватності й ліміт тривалості."""
        return self._post("/v2/post/publish/creator_info/query/", token, json={}).get("data", {})

    # ---------- публікація ----------
    def init_upload(self, token: str, size: int, chunks: list[tuple[int, int]],
                    post_info: dict | None) -> tuple[str, str]:
        """Direct Post (post_info задано) або Inbox/чернетки (post_info=None)."""
        chunk_size = chunks[0][1] - chunks[0][0] + 1 if len(chunks) > 1 else size
        body = {"source_info": {"source": "FILE_UPLOAD", "video_size": size,
                                "chunk_size": chunk_size, "total_chunk_count": len(chunks)}}
        if post_info is not None:
            body["post_info"] = post_info
            path = "/v2/post/publish/video/init/"
        else:
            path = "/v2/post/publish/inbox/video/init/"
        data = self._post(path, token, json=body).get("data", {})
        if not data.get("publish_id") or not data.get("upload_url"):
            raise TikTokError("bad_response", "немає publish_id/upload_url")
        return data["publish_id"], data["upload_url"]

    def upload(self, upload_url: str, path: str | Path, chunks: list[tuple[int, int]]) -> None:
        """Послідовне завантаження частин (PUT + Content-Range). 5xx — до 3 повторів частини."""
        size = os.path.getsize(path)
        mime = MIME.get(Path(path).suffix.lower(), "video/mp4")
        with open(path, "rb") as fh:
            for i, (a, b) in enumerate(chunks):
                fh.seek(a)
                payload = fh.read(b - a + 1)
                headers = {"Content-Type": mime, "Content-Length": str(len(payload)),
                           "Content-Range": f"bytes {a}-{b}/{size}"}
                last = i == len(chunks) - 1
                for attempt in range(3):
                    try:
                        r = self.http.put(upload_url, data=payload, headers=headers,
                                          timeout=max(self.timeout, 120))
                    except requests.RequestException as exc:
                        if attempt == 2:
                            raise TikTokError("network", str(exc)[:200]) from exc
                        continue
                    if r.status_code >= 500 and attempt < 2:
                        continue
                    break
                ok = (201, 200) if last else (206, 201, 200)
                if r.status_code not in ok:
                    raise TikTokError("upload_failed", f"HTTP {r.status_code}: {r.text[:150]}",
                                      r.status_code)

    def status(self, token: str, publish_id: str) -> dict:
        return self._post("/v2/post/publish/status/fetch/", token,
                          json={"publish_id": publish_id}).get("data", {})
