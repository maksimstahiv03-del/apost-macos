"""OAuth 2.0 (PKCE) для десктопа: локальний callback на 127.0.0.1, токени — у Keychain.

* PKCE за вимогою TikTok для desktop: code_challenge = HEX(SHA256(code_verifier)).
* client_secret і токени зберігаються ЛИШЕ в системному сховищі (macOS Keychain через keyring);
  якщо його немає — підключення відмовляє, а не пише секрети відкритим текстом.
"""
from __future__ import annotations

import hashlib
import json
import secrets
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Callable
from urllib.parse import parse_qs, urlencode, urlparse

from publisher.tiktok_api import AUTH_URL, SCOPES, TikTokClient, TikTokError
from utils.logger import get_logger

log = get_logger("tiktok.auth")

SERVICE = "APOST-TikTok"
REFRESH_MARGIN = 300  # оновлюємо токен за 5 хв до завершення


class SecretStore:
    """Обгортка над keyring (секрет клієнта + токени)."""

    def __init__(self, backend=None) -> None:
        self._kr = backend

    @property
    def kr(self):
        if self._kr is None:
            import keyring
            self._kr = keyring
        return self._kr

    def get(self, name: str) -> str | None:
        try:
            return self.kr.get_password(SERVICE, name)
        except Exception:
            log.exception("Keychain: не вдалося прочитати %s", name)
            return None

    def set(self, name: str, value: str) -> None:
        try:
            self.kr.set_password(SERVICE, name, value)
        except Exception as exc:
            log.exception("Keychain недоступний")
            raise TikTokError("keyring_unavailable", "Системне сховище паролів недоступне") from exc

    def delete(self, name: str) -> None:
        try:
            self.kr.delete_password(SERVICE, name)
        except Exception:
            pass


def make_pkce() -> tuple[str, str]:
    verifier = secrets.token_urlsafe(64)[:96]            # 43–128 символів
    challenge = hashlib.sha256(verifier.encode()).hexdigest()   # HEX, не base64
    return verifier, challenge


class TikTokAuth:
    def __init__(self, settings, store: SecretStore | None = None,
                 client: TikTokClient | None = None,
                 opener: Callable[[str], object] = webbrowser.open) -> None:
        self.settings = settings
        self.store = store or SecretStore()
        self.client = client or TikTokClient()
        self.opener = opener
        self._lock = threading.Lock()

    # ---------- налаштування ----------
    @property
    def client_key(self) -> str:
        return (self.settings.get("tiktok_client_key", "") or "").strip()

    @property
    def redirect_uri(self) -> str:
        return f"http://127.0.0.1:{int(self.settings.get('tiktok_port', 8765))}/callback/"

    def save_credentials(self, client_key: str, client_secret: str) -> None:
        self.settings.set("tiktok_client_key", client_key.strip())
        if client_secret.strip():
            self.store.set("client_secret", client_secret.strip())

    def is_configured(self) -> bool:
        return bool(self.client_key and self.store.get("client_secret"))

    def _tokens(self) -> dict | None:
        raw = self.store.get("tokens")
        try:
            return json.loads(raw) if raw else None
        except ValueError:
            return None

    def is_connected(self) -> bool:
        return self._tokens() is not None

    def account_name(self) -> str:
        return self.settings.get("tiktok_account", "") or ""

    # ---------- вхід ----------
    def login(self, timeout: int = 180) -> str:
        """Блокуючий вхід: відкриває браузер і чекає callback. Викликати з фонового потоку."""
        if not self.is_configured():
            raise TikTokError("not_configured")
        verifier, challenge = make_pkce()
        state = secrets.token_urlsafe(16)
        port = int(self.settings.get("tiktok_port", 8765))
        result: dict = {}

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):  # noqa: N802
                q = parse_qs(urlparse(self.path).query)
                result.update({k: v[0] for k, v in q.items()})
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write("<html><body style='font-family:sans-serif;text-align:center;"
                                 "margin-top:15vh'><h2>APOST</h2><p>Готово. Можна закрити цю "
                                 "вкладку й повернутися до програми.</p></body></html>".encode())

            def log_message(self, *a):  # без шуму в консолі
                pass

        try:
            server = HTTPServer(("127.0.0.1", port), Handler)
        except OSError as exc:
            raise TikTokError("port_busy", f"Порт {port} зайнятий") from exc
        server.timeout = 1
        url = AUTH_URL + "?" + urlencode({
            "client_key": self.client_key, "scope": SCOPES, "response_type": "code",
            "redirect_uri": self.redirect_uri, "state": state,
            "code_challenge": challenge, "code_challenge_method": "S256"})
        try:
            self.opener(url)
            end = time.time() + timeout
            while time.time() < end and "code" not in result and "error" not in result:
                server.handle_request()
        finally:
            server.server_close()

        if "error" in result:
            raise TikTokError(result["error"], result.get("error_description", ""))
        if "code" not in result:
            raise TikTokError("timeout", "Вхід не завершено вчасно")
        if result.get("state") != state:
            raise TikTokError("state_mismatch", "Невірний параметр state (можлива підробка запиту)")

        tok = self.client.exchange_code(self.client_key, self.store.get("client_secret"),
                                        result["code"], self.redirect_uri, verifier)
        self._save_tokens(tok)
        try:
            name = self.client.user_info(tok["access_token"]).get("display_name", "") or "TikTok"
        except TikTokError:
            name = "TikTok"
        self.settings.set("tiktok_account", name)
        return name

    def _save_tokens(self, tok: dict) -> None:
        if not tok.get("access_token"):
            raise TikTokError("bad_response", "немає access_token")
        now = time.time()
        old = self._tokens() or {}
        self.store.set("tokens", json.dumps({
            "access_token": tok["access_token"],
            "refresh_token": tok.get("refresh_token") or old.get("refresh_token", ""),
            "expires_at": now + int(tok.get("expires_in", 86400)),
            "refresh_expires_at": now + int(tok.get("refresh_expires_in", 31536000)),
            "open_id": tok.get("open_id", old.get("open_id", ""))}))

    # ---------- токен для запитів ----------
    def access_token(self) -> str:
        with self._lock:
            t = self._tokens()
            if not t:
                raise TikTokError("reauth", "Акаунт не підключено")
            if t["expires_at"] - time.time() > REFRESH_MARGIN:
                return t["access_token"]
            if not t.get("refresh_token") or t["refresh_expires_at"] <= time.time():
                raise TikTokError("reauth", "Термін дії входу завершився")
            try:
                new = self.client.refresh(self.client_key, self.store.get("client_secret") or "",
                                          t["refresh_token"])
            except TikTokError as exc:
                if exc.code == "invalid_grant":
                    raise TikTokError("reauth", "Потрібно увійти знову") from exc
                raise
            self._save_tokens(new)
            return self._tokens()["access_token"]

    def disconnect(self) -> None:
        t = self._tokens()
        if t:
            try:
                self.client.revoke(self.client_key, self.store.get("client_secret") or "",
                                   t["access_token"])
            except Exception:
                log.warning("Не вдалося відкликати токен на боці TikTok", exc_info=True)
        self.store.delete("tokens")
        self.settings.set("tiktok_account", "")

    def forget_secret(self) -> None:
        self.store.delete("client_secret")
