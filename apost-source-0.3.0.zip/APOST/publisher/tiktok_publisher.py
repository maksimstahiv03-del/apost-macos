"""Публікація відео. Етап 3: безпечний ручний режим; офіційний Direct Post API — етап 4."""
from __future__ import annotations

import os
import subprocess
import sys
import webbrowser
from dataclasses import dataclass
from pathlib import Path

from core.video_manager import build_caption
from publisher.tiktok_api import TikTokClient, TikTokError, plan_chunks
from utils.logger import get_logger

log = get_logger("publisher")

TIKTOK_UPLOAD_URL = "https://www.tiktok.com/upload"


@dataclass
class PublishResult:
    # 'manual_required' | 'processing' (message = publish_id) | 'inbox_ready'
    # | 'published' | 'failed'
    state: str
    message: str = ""


class BasePublisher:
    name = "base"

    def publish(self, post: dict) -> PublishResult:  # pragma: no cover - інтерфейс
        raise NotImplementedError

    def check_status(self, post: dict) -> PublishResult:  # лише для API-публікаторів
        return PublishResult("processing")


class ManualPublisher(BasePublisher):
    """Режим без доступу до API: лише повідомляє, що настав час публікувати вручну.

    НІКОЛИ не повертає 'published': статус «Опубліковано» ставиться тільки після
    підтвердження користувачем (або, на етапі 4, після відповіді TikTok API).
    """
    name = "manual"

    def publish(self, post: dict) -> PublishResult:
        return PublishResult("manual_required")


class TikTokPublisher(BasePublisher):
    """Офіційний Content Posting API: Direct Post або чернетки (Inbox)."""
    name = "tiktok"
    CAPTION_LIMIT = 2200

    def __init__(self, auth, client: TikTokClient, settings) -> None:
        self.auth, self.client, self.settings = auth, client, settings

    def publish(self, post: dict) -> PublishResult:
        mode = self.settings.get("tiktok_mode", "manual")
        token = self.auth.access_token()
        path = post["path"]
        size = os.path.getsize(path)
        chunks = plan_chunks(size)
        post_info = None
        if mode == "direct":
            creator = self.client.creator_info(token)          # перевірка доступу до публікації
            privacy = self.settings.get("tiktok_privacy", "SELF_ONLY")
            allowed = creator.get("privacy_level_options") or []
            if allowed and privacy not in allowed:
                raise TikTokError("privacy_not_allowed",
                                  f"{privacy}; дозволено: {', '.join(allowed)}")
            limit, dur = creator.get("max_video_post_duration_sec"), post.get("duration_sec")
            if limit and dur and dur > limit:
                raise TikTokError("too_long", f"{int(dur)} с > {limit} с")
            post_info = {
                "title": build_caption(post.get("description") or "", post.get("hashtags") or "")
                [: self.CAPTION_LIMIT],
                "privacy_level": privacy, "disable_duet": False, "disable_comment": False,
                "disable_stitch": False, "video_cover_timestamp_ms": 1000}
        publish_id, upload_url = self.client.init_upload(token, size, chunks, post_info)
        self.client.upload(upload_url, path, chunks)
        return PublishResult("processing", publish_id)

    def check_status(self, post: dict) -> PublishResult:
        token = self.auth.access_token()
        data = self.client.status(token, post["publish_id"])
        st = data.get("status", "")
        if st == "PUBLISH_COMPLETE":
            return PublishResult("published", str(data.get("publicaly_available_post_id") or ""))
        if st == "SEND_TO_USER_INBOX":
            return PublishResult("inbox_ready")
        if st == "FAILED":
            return PublishResult("failed", data.get("fail_reason") or "failed")
        return PublishResult("processing")


class RoutingPublisher(BasePublisher):
    """Обирає спосіб публікації за налаштуваннями; без підключеного акаунта — ручний режим."""
    name = "routing"

    def __init__(self, manual: BasePublisher, tiktok: TikTokPublisher, auth, settings) -> None:
        self.manual, self.tiktok, self.auth, self.settings = manual, tiktok, auth, settings

    def _api_mode(self) -> bool:
        return self.settings.get("tiktok_mode", "manual") in ("direct", "inbox") \
            and self.auth.is_connected()

    def publish(self, post: dict) -> PublishResult:
        return (self.tiktok if self._api_mode() else self.manual).publish(post)

    def check_status(self, post: dict) -> PublishResult:
        return self.tiktok.check_status(post)


def reveal_file(path: str) -> None:
    """Показує файл у Finder (macOS) / файловому менеджері."""
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", "-R", path])
        elif sys.platform.startswith("linux"):
            subprocess.Popen(["xdg-open", str(Path(path).parent)])
    except OSError:
        log.exception("Не вдалося показати файл %s", path)


def open_file(path: str) -> None:
    """Відкриває відео у програвачі за замовчуванням (попередній перегляд)."""
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", path])
        elif sys.platform.startswith("linux"):
            subprocess.Popen(["xdg-open", path])
    except OSError:
        log.exception("Не вдалося відкрити %s", path)


def open_upload_page() -> None:
    webbrowser.open(TIKTOK_UPLOAD_URL)
