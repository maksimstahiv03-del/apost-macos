"""Головна сторінка (Dashboard): усі показники беруться з реальної БД."""
from __future__ import annotations

import customtkinter as ctk

from ui.base_page import BasePage
from ui.widgets import (C, Card, StatCard, chip, font, fmt_dt, label, primary_button,
                        secondary_button, small_button)


class DashboardPage(BasePage):
    title_key = "dashboard.title"
    subtitle_key = "dashboard.subtitle"

    def build(self) -> None:
        t, body = self.t, self.body
        self._rev = -1
        for c in range(3):
            body.columnconfigure(c, weight=1, uniform="stat")

        self.stats = {
            "total_videos": StatCard(body, t("dashboard.stat.total_videos")),
            "in_queue":     StatCard(body, t("dashboard.stat.in_queue")),
            "scheduled":    StatCard(body, t("dashboard.stat.scheduled")),
            "published":    StatCard(body, t("dashboard.stat.published")),
            "failed":       StatCard(body, t("dashboard.stat.failed")),
            "scheduler":    StatCard(body, t("dashboard.stat.scheduler")),
        }
        self.stats["scheduler"].value_label.configure(font=font(20, True))
        for i, card in enumerate(self.stats.values()):
            card.grid(row=i // 3, column=i % 3, sticky="ew", padx=6, pady=6)

        self.attention = Card(body, border_color=C("status_posting"))
        self.attention.grid(row=2, column=0, columnspan=3, sticky="ew", padx=6, pady=6)

        self.next_card = Card(body)
        self.next_card.grid(row=3, column=0, columnspan=3, sticky="ew", padx=6, pady=6)
        self.up_card = Card(body)
        self.up_card.grid(row=4, column=0, columnspan=3, sticky="ew", padx=6, pady=6)

        label(body, t("dashboard.actions.title"), 16, bold=True).grid(
            row=5, column=0, columnspan=3, sticky="w", padx=6, pady=(14, 4))
        row = ctk.CTkFrame(body, fg_color="transparent", height=0)
        row.grid(row=6, column=0, columnspan=3, sticky="w", padx=6)
        nav = self.ctx.navigate
        primary_button(row, t("action.add_video"), lambda: nav("library")).pack(side="left", padx=(0, 10))
        secondary_button(row, t("action.view_queue"), lambda: nav("queue")).pack(side="left", padx=5)
        secondary_button(row, t("action.open_calendar"), lambda: nav("calendar")).pack(side="left", padx=5)
        secondary_button(row, t("action.setup_schedule"), lambda: nav("scheduler")).pack(side="left", padx=5)
        self.refresh(force=True)

    def _clear(self, card):
        for w in card.winfo_children():
            w.destroy()

    def refresh(self, force: bool = False) -> None:
        ctx, t = self.ctx, self.t
        if not force and self._rev == ctx.db.revision:
            return
        self._rev = ctx.db.revision
        s = ctx.db.stats()
        for key in ("total_videos", "in_queue", "scheduled", "published", "failed"):
            self.stats[key].set_value(str(s[key]))
        state = ctx.engine.state() if ctx.engine else "stopped"
        self.stats["scheduler"].set_value(t({"running": "dashboard.scheduler.running",
                                             "paused": "dashboard.scheduler.paused",
                                             "stopped": "dashboard.scheduler.stopped"}[state]))

        # блок «потрібна увага»
        self._clear(self.attention)
        if s["manual_due"] or s["missed"]:
            self.attention.grid()
            label(self.attention, t("dashboard.attention.title"), 16, bold=True).pack(
                anchor="w", padx=20, pady=(16, 2))
            if s["manual_due"]:
                label(self.attention, t("dashboard.attention.manual", n=s["manual_due"]), 14).pack(
                    anchor="w", padx=20)
            if s["missed"]:
                label(self.attention, t("dashboard.attention.missed", n=s["missed"]), 14).pack(
                    anchor="w", padx=20)
            small_button(self.attention, t("dashboard.attention.open"),
                         lambda: ctx.navigate("queue")).pack(anchor="w", padx=20, pady=(8, 16))
        else:
            self.attention.grid_remove()

        # найближча та список найближчих
        upcoming = ctx.db.upcoming(6)
        self._clear(self.next_card)
        label(self.next_card, t("dashboard.next.title"), 16, bold=True).pack(
            anchor="w", padx=20, pady=(16, 2))
        if upcoming:
            n = upcoming[0]
            label(self.next_card, f"{fmt_dt(ctx.to_local(n['scheduled_at']))}   —   {n['name']}", 14).pack(
                anchor="w", padx=20, pady=(0, 16))
        else:
            label(self.next_card, t("dashboard.next.none"), 14, secondary=True).pack(
                anchor="w", padx=20, pady=(0, 16))

        self._clear(self.up_card)
        label(self.up_card, t("dashboard.upcoming.title"), 16, bold=True).pack(
            anchor="w", padx=20, pady=(16, 6))
        if upcoming:
            for p in upcoming:
                r = ctk.CTkFrame(self.up_card, fg_color="transparent", height=0)
                r.pack(fill="x", padx=20, pady=2)
                label(r, fmt_dt(ctx.to_local(p["scheduled_at"])), 13, secondary=True, width=150).pack(side="left")
                label(r, p["name"], 13).pack(side="left", padx=(8, 0))
                key = "posting" if p["manual_due"] else ("pending" if p["paused"] else "scheduled")
                text = t("queue.manual_due") if p["manual_due"] else (
                    t("queue.paused") if p["paused"] else t("status.scheduled"))
                chip(r, text, key).pack(side="right")
            ctk.CTkFrame(self.up_card, fg_color="transparent", height=10).pack()
        else:
            label(self.up_card, t("dashboard.upcoming.empty"), 14, secondary=True).pack(
                anchor="w", padx=20, pady=(0, 16))
