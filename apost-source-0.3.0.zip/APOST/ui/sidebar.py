"""Бічне меню навігації з намальованими іконками."""
from __future__ import annotations

from typing import Callable

import customtkinter as ctk
from PIL import Image

from core import config
from core.context import AppContext
from ui.widgets import C, font, label
from utils.icons import get_icon

NAV_ITEMS = [  # (ключ сторінки, назва іконки, ключ локалізації)
    ("dashboard", "dashboard", "nav.dashboard"),
    ("library",   "library",   "nav.library"),
    ("queue",     "queue",     "nav.queue"),
    ("calendar",  "calendar",  "nav.calendar"),
    ("scheduler", "scheduler", "nav.scheduler"),
    ("history",   "history",   "nav.history"),
    ("settings",  "settings",  "nav.settings"),
]


def _logo_image(size: int = 46):
    path = config.resource_path("assets/icons/apost_logo.png")
    try:
        img = Image.open(path)
        return ctk.CTkImage(light_image=img, dark_image=img, size=(size, size))
    except Exception:
        return None


class Sidebar(ctk.CTkFrame):
    WIDTH = 250

    def __init__(self, master, ctx: AppContext, on_select: Callable[[str], None]) -> None:
        super().__init__(master, width=self.WIDTH, corner_radius=0,
                         fg_color=C("bg_secondary"), border_width=0)
        self.grid_propagate(False)
        self.ctx = ctx
        self._on_select = on_select
        self._buttons: dict[str, ctk.CTkButton] = {}
        self._icons = {k: icon for k, icon, _ in NAV_ITEMS}

        brand = ctk.CTkFrame(self, fg_color="transparent", height=0)
        brand.pack(fill="x", padx=26, pady=(34, 28))
        logo = _logo_image()
        if logo is not None:
            ctk.CTkLabel(brand, text="", image=logo).pack(side="left", padx=(0, 12))
        names = ctk.CTkFrame(brand, fg_color="transparent", height=0)
        names.pack(side="left")
        ctk.CTkLabel(names, text="APOST", font=font(28, True),
                     text_color=C("accent"), anchor="w").pack(anchor="w")
        label(names, ctx.t("app.tagline"), 12, secondary=True).pack(anchor="w")

        for key, icon, tkey in NAV_ITEMS:
            btn = ctk.CTkButton(
                self, text="  " + ctx.t(tkey), anchor="w", height=48,
                corner_radius=24, font=font(14, True),
                image=get_icon(icon, 22), compound="left", border_spacing=14,
                fg_color="transparent", hover_color=C("hover"),
                text_color=C("text_secondary"),
                command=lambda k=key: self._on_select(k),
            )
            btn.pack(fill="x", padx=14, pady=3)
            self._buttons[key] = btn

        label(self, ctx.t("app.version", version=config.APP_VERSION), 11,
              secondary=True).pack(side="bottom", anchor="w", padx=26, pady=22)

    def set_active(self, key: str) -> None:
        for k, btn in self._buttons.items():
            on = k == key
            btn.configure(
                fg_color=C("accent") if on else "transparent",
                hover_color=C("accent_hover") if on else C("hover"),
                text_color=C("accent_text") if on else C("text_secondary"),
                image=get_icon(self._icons[k], 22, active=on),
            )
