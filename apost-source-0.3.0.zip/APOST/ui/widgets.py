"""Спільні UI-компоненти у фірмовому стилі APOST."""
from __future__ import annotations

from typing import Callable

import customtkinter as ctk

from core.theme_manager import ThemeManager
from utils.icons import get_icon

C = ThemeManager.color  # скорочення: C("accent") -> (light, dark)

RADIUS = 20


def font(size: int = 14, bold: bool = False) -> ctk.CTkFont:
    return ctk.CTkFont(size=size, weight="bold" if bold else "normal")


def label(master, text: str = "", size: int = 14, bold: bool = False,
          secondary: bool = False, **kw) -> ctk.CTkLabel:
    return ctk.CTkLabel(
        master, text=text, font=font(size, bold),
        text_color=C("text_secondary" if secondary else "text"),
        anchor=kw.pop("anchor", "w"), **kw,
    )


def primary_button(master, text: str, command: Callable | None = None,
                   state: str = "normal", **kw) -> ctk.CTkButton:
    return ctk.CTkButton(
        master, text=text, command=command, state=state, height=kw.pop("height", 44),
        corner_radius=22, font=font(14, True),
        fg_color=C("accent"), hover_color=C("accent_hover"),
        text_color=C("accent_text"), text_color_disabled=C("disabled"), **kw,
    )


def secondary_button(master, text: str, command: Callable | None = None,
                     state: str = "normal", **kw) -> ctk.CTkButton:
    return ctk.CTkButton(
        master, text=text, command=command, state=state, height=kw.pop("height", 44),
        corner_radius=22, font=font(14),
        fg_color=C("bg"), hover_color=C("hover"), border_width=1,
        border_color=C("border"), text_color=C("text"),
        text_color_disabled=C("disabled"), **kw,
    )


class Card(ctk.CTkFrame):
    """Заокруглена картка з тонкою межею."""

    def __init__(self, master, **kw) -> None:
        kw.setdefault("fg_color", C("bg_secondary"))
        kw.setdefault("corner_radius", RADIUS)
        kw.setdefault("border_width", 1)
        kw.setdefault("border_color", C("border"))
        super().__init__(master, **kw)


class StatCard(Card):
    def __init__(self, master, title: str, value: str = "0") -> None:
        super().__init__(master)
        self.columnconfigure(0, weight=1)
        label(self, title, 13, secondary=True).grid(
            row=0, column=0, sticky="w", padx=18, pady=(16, 0))
        self.value_label = label(self, value, 30, bold=True)
        self.value_label.grid(row=1, column=0, sticky="w", padx=18, pady=(2, 16))

    def set_value(self, value: str) -> None:
        self.value_label.configure(text=value)


class EmptyState(Card):
    """Порожній стан: заголовок, пояснення та (опційно) позначка етапу."""

    def __init__(self, master, icon: str, title: str, text: str,
                 note: str | None = None) -> None:
        super().__init__(master)
        inner = ctk.CTkFrame(self, fg_color="transparent")
        inner.place(relx=0.5, rely=0.5, anchor="center")
        ctk.CTkLabel(inner, text="", image=get_icon(icon, 56)).pack(pady=(0, 10))
        label(inner, title, 18, bold=True, anchor="center").pack()
        ctk.CTkLabel(inner, text=text, font=font(13), wraplength=420,
                     justify="center", text_color=C("text_secondary")).pack(pady=(6, 0))
        if note:
            ctk.CTkLabel(inner, text=note, font=font(12, True),
                         text_color=C("accent")).pack(pady=(14, 0))


def segmented(master, values: list[str], command=None, **kw) -> ctk.CTkSegmentedButton:
    """Сегментований перемикач у стилі iOS: світлий «повзунок» на сірій доріжці (текст завжди читабельний)."""
    return ctk.CTkSegmentedButton(
        master, values=values, command=command, height=42, corner_radius=21,
        border_width=4, font=font(14, True),
        selected_color=C("bg"), selected_hover_color=C("bg"),
        unselected_color=C("hover"), unselected_hover_color=C("border"),
        fg_color=C("hover"), text_color=C("text"),
        text_color_disabled=C("text_secondary"), **kw,
    )


# ---------- додаткові компоненти ----------
import tkinter as _tk
from pathlib import Path as _Path

from PIL import Image as _Image, ImageOps as _ImageOps

EVENT_TEXT = ("#FFFFFF", "#111111")  # текст на кольорових плашках


def icon_button(master, icon: str, command=None, tone: str | None = None, size: int = 38,
                state: str = "normal", **kw) -> ctk.CTkButton:
    """Кругла кнопка з іконкою."""
    return ctk.CTkButton(
        master, text="", image=get_icon(icon, 18, tone=tone), command=command, state=state,
        width=size, height=size, corner_radius=size // 2, fg_color="transparent",
        hover_color=C("hover"), **kw)


def small_button(master, text: str, command=None, icon: str | None = None,
                 primary: bool = True, **kw) -> ctk.CTkButton:
    """Компактна кнопка-капсула (для дій у рядках списків)."""
    return ctk.CTkButton(
        master, text=text, command=command, height=34, corner_radius=17, font=font(12, True),
        image=get_icon(icon, 16, tone="active" if primary else None) if icon else None,
        compound="left", fg_color=C("accent") if primary else C("bg"),
        hover_color=C("accent_hover") if primary else C("hover"),
        text_color=C("accent_text") if primary else C("text"),
        border_width=0 if primary else 1, border_color=C("border"), **kw)


def chip(master, text: str, status: str) -> ctk.CTkLabel:
    """Кольорова плашка статусу."""
    return ctk.CTkLabel(master, text=f" {text} ", font=font(11, True), corner_radius=11,
                        height=22, fg_color=C(f"status_{status}"), text_color=EVENT_TEXT)


_thumb_cache: dict = {}


def thumb_image(path: str | None, size: tuple[int, int] = (45, 80)) -> ctk.CTkImage:
    """Мініатюра відео (обрізана до size, з кешем); без файлу — заглушка з іконкою."""
    root_id = id(_tk._default_root)
    key = (path, size, root_id)
    if key in _thumb_cache:
        return _thumb_cache[key]
    img = None
    if path and _Path(path).exists():
        try:
            img = _ImageOps.fit(_Image.open(path).convert("RGB"), (size[0] * 2, size[1] * 2))
        except Exception:
            img = None
    if img is None:
        img = _Image.new("RGB", (size[0] * 2, size[1] * 2), (150, 150, 150))
    ci = ctk.CTkImage(light_image=img, dark_image=img, size=size)
    _thumb_cache[key] = ci
    return ci


def fmt_dt(dt) -> str:
    return dt.strftime("%d.%m.%Y  %H:%M")


class PagedRows:
    """Поступове додавання рядків списку.

    CustomTkinter малює віджети повільно (150 рядків ≈ 8 с), тому показуємо по `page` штук,
    а решту — за кнопкою «Показати ще», без перебудови вже намальованих рядків.
    """

    def __init__(self, parent, rows, make_row, more_text, page: int = 25, shown: int = 0) -> None:
        self.parent, self.rows, self.make_row = parent, rows, make_row
        self.more_text, self.page = more_text, page
        self.n = 0
        self._btn = None
        self.more(max(page, shown))

    def more(self, count: int | None = None) -> None:
        if self._btn is not None:
            self._btn.destroy()
            self._btn = None
        end = min(self.n + (count or self.page), len(self.rows))
        for i in range(self.n, end):
            self.make_row(self.parent, i, self.rows[i])
        self.n = end
        if self.n < len(self.rows):
            self._btn = secondary_button(
                self.parent, self.more_text(len(self.rows) - self.n), self.more)
            self._btn.grid(row=self.n, column=0, pady=12)
