"""Планувальник: автоматичний розподіл черги за графіком + керування рушієм."""
from __future__ import annotations

from datetime import time

import customtkinter as ctk

from core import planning_service
from core.schedule_planner import (ScheduleConfig, day_times, interval_minutes,
                                   last_from_interval, parse_date, parse_time)
from ui.base_page import BasePage
from ui.dialogs import ask
from ui.widgets import C, Card, chip, font, label, primary_button, secondary_button

WEEKDAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]


class SchedulerPage(BasePage):
    title_key = "scheduler.title"
    subtitle_key = "scheduler.subtitle"

    def build(self) -> None:
        t, ctx = self.t, self.ctx
        self._rev = -1
        self._job = None

        self.state_holder = ctk.CTkFrame(self.header_actions, fg_color="transparent", height=0)
        self.state_holder.pack(side="left", padx=(0, 10))
        self.pause_btn = secondary_button(self.header_actions, "", self._toggle_engine)
        self.pause_btn.pack(side="left")

        self.body.rowconfigure(0, weight=1)
        scroll = ctk.CTkScrollableFrame(self.body, fg_color="transparent", corner_radius=0)
        scroll.grid(row=0, column=0, sticky="nsew")
        scroll.columnconfigure(0, weight=1)

        # ----- форма -----
        form = Card(scroll)
        form.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        form.columnconfigure((0, 1), weight=1, uniform="f")
        label(form, t("scheduler.params.title"), 17, bold=True).grid(
            row=0, column=0, columnspan=2, sticky="w", padx=22, pady=(18, 6))

        saved = planning_service.load_config(ctx.settings)
        self.e = {}
        fields = [
            ("per_day", "scheduler.videos_per_day", str(saved.per_day), None),
            ("interval", "scheduler.interval_min", str(interval_minutes(saved)), None),
            ("first", "scheduler.first_time", saved.first.strftime("%H:%M"), None),
            ("last", "scheduler.last_time", saved.last.strftime("%H:%M"), None),
            ("start", "scheduler.start_date", saved.start.isoformat() if saved.start else "",
             t("scheduler.start_hint")),
            ("end", "scheduler.end_date", saved.end.isoformat() if saved.end else "",
             t("scheduler.end_hint")),
        ]
        for i, (key, tkey, value, hint) in enumerate(fields):
            cell = ctk.CTkFrame(form, fg_color="transparent")
            cell.grid(row=1 + i // 2, column=i % 2, sticky="ew", padx=22, pady=6)
            label(cell, t(tkey), 13, secondary=True).pack(anchor="w")
            ent = ctk.CTkEntry(cell, height=42, corner_radius=14, fg_color=C("bg"),
                               border_color=C("border"), text_color=C("text"),
                               placeholder_text=hint or "")
            ent.pack(fill="x", pady=(4, 0))
            if value:
                ent.insert(0, value)
            ent.bind("<KeyRelease>", lambda _e, k=key: self._on_key(k))
            self.e[key] = ent

        days = ctk.CTkFrame(form, fg_color="transparent")
        days.grid(row=4, column=0, columnspan=2, sticky="w", padx=22, pady=(10, 4))
        label(days, t("scheduler.weekdays"), 13, secondary=True).pack(anchor="w")
        row = ctk.CTkFrame(days, fg_color="transparent")
        row.pack(anchor="w", pady=(6, 0))
        self.day_vars = []
        for i, d in enumerate(WEEKDAYS):
            var = ctk.BooleanVar(value=i in saved.weekdays)
            self.day_vars.append(var)
            ctk.CTkCheckBox(row, text=t(f"weekday.{d}"), variable=var, width=72, font=font(13),
                            text_color=C("text"), fg_color=C("accent"),
                            hover_color=C("accent_hover"), corner_radius=8,
                            command=self._schedule_preview).pack(side="left")

        self.err = ctk.CTkLabel(form, text="", font=font(12, True), text_color=C("status_error"),
                                anchor="w", wraplength=700, justify="left")
        self.err.grid(row=5, column=0, columnspan=2, sticky="w", padx=22, pady=(6, 0))
        btns = ctk.CTkFrame(form, fg_color="transparent")
        btns.grid(row=6, column=0, columnspan=2, sticky="w", padx=22, pady=(10, 20))
        primary_button(btns, t("scheduler.distribute"), self._apply).pack(side="left", padx=(0, 10))
        secondary_button(btns, t("scheduler.redistribute"), self._redistribute).pack(side="left")

        # ----- попередній перегляд -----
        self.prev = Card(scroll)
        self.prev.grid(row=1, column=0, sticky="ew")
        self.prev_body = ctk.CTkFrame(self.prev, fg_color="transparent")
        self.prev_body.pack(fill="x", padx=22, pady=18)
        self.refresh(force=True)

    # ---------- читання форми ----------
    def _read(self) -> tuple[ScheduleConfig | None, str | None]:
        try:
            per_day = int(self.e["per_day"].get().strip())
        except ValueError:
            return None, "per_day"
        first, last = parse_time(self.e["first"].get()), parse_time(self.e["last"].get())
        if first is None or last is None:
            return None, "bad_time"
        start_s, end_s = self.e["start"].get().strip(), self.e["end"].get().strip()
        start, end = parse_date(start_s), parse_date(end_s)
        if (start_s and start is None) or (end_s and end is None):
            return None, "bad_date"
        weekdays = {i for i, v in enumerate(self.day_vars) if v.get()}
        cfg = ScheduleConfig(per_day, first, last, start, end, weekdays)
        return cfg, cfg.validate()

    def _on_key(self, source: str) -> None:
        """Зв'язок «інтервал ↔ час останньої публікації»: правка одного перераховує інше."""
        try:
            n = int(self.e["per_day"].get().strip())
        except ValueError:
            n = None
        first = parse_time(self.e["first"].get())
        if source == "interval" and n and first:
            try:
                last = last_from_interval(first, n, int(self.e["interval"].get().strip()))
            except ValueError:
                last = None
            if last is not None:
                self._set("last", last.strftime("%H:%M"))
        elif source in ("per_day", "first", "last"):
            last = parse_time(self.e["last"].get())
            if n and first and last and 1 <= n <= 24 and (n == 1 or last > first):
                self._set("interval", str(interval_minutes(ScheduleConfig(n, first, last))))
        self._schedule_preview()

    def _set(self, key: str, value: str) -> None:
        self.e[key].delete(0, "end")
        self.e[key].insert(0, value)

    def _schedule_preview(self) -> None:
        if self._job:
            self.after_cancel(self._job)
        self._job = self.after(250, self.refresh_preview)

    # ---------- дії ----------
    def _toggle_engine(self) -> None:
        eng = self.ctx.engine
        eng.resume() if eng.paused else eng.pause()

    def _apply(self) -> None:
        cfg, err = self._read()
        if err:
            return self._show_err(err)
        planning_service.save_config(self.ctx.settings, cfg)
        n, left = planning_service.distribute(self.ctx, cfg)
        self.err.configure(text=self.t("scheduler.applied", n=n), text_color=C("status_published"))

    def _redistribute(self) -> None:
        cfg, err = self._read()
        if err:
            return self._show_err(err)
        if not ask(self, self.t("scheduler.redistribute"), self.t("scheduler.redistribute.text"),
                   self.t("common.ok"), self.t("common.cancel")):
            return
        planning_service.save_config(self.ctx.settings, cfg)
        n, left = planning_service.redistribute_all(self.ctx, cfg)
        self.err.configure(text=self.t("scheduler.applied", n=n), text_color=C("status_published"))

    def _show_err(self, code: str) -> None:
        self.err.configure(text=self.t(f"scheduler.err.{code}"), text_color=C("status_error"))

    # ---------- відображення ----------
    def on_show(self) -> None:
        self._reload_fields()          # графік міг змінитися в Налаштуваннях
        self.refresh(force=True)

    def _reload_fields(self) -> None:
        saved = planning_service.load_config(self.ctx.settings)
        values = {"per_day": str(saved.per_day), "interval": str(interval_minutes(saved)),
                  "first": saved.first.strftime("%H:%M"), "last": saved.last.strftime("%H:%M"),
                  "start": saved.start.isoformat() if saved.start else "",
                  "end": saved.end.isoformat() if saved.end else ""}
        for k, v in values.items():
            self._set(k, v)
        for i, var in enumerate(self.day_vars):
            var.set(i in saved.weekdays)

    def refresh(self, force: bool = False) -> None:
        if not force and self._rev == self.ctx.db.revision:
            return
        self._rev = self.ctx.db.revision
        t, eng = self.t, self.ctx.engine
        for w in self.state_holder.winfo_children():
            w.destroy()
        state = eng.state() if eng else "stopped"
        chip(self.state_holder, t(f"scheduler.state.{state}"),
             {"running": "published", "paused": "posting", "stopped": "pending"}[state]).pack()
        self.pause_btn.configure(text=t("scheduler.resume" if state == "paused" else "scheduler.pause"))
        self.refresh_preview()

    def refresh_preview(self) -> None:
        self._job = None
        t = self.t
        for w in self.prev_body.winfo_children():
            w.destroy()
        label(self.prev_body, t("scheduler.preview"), 17, bold=True).pack(anchor="w")
        cfg, err = self._read()
        if err:
            self._show_err(err)
            return
        if self.err.cget("text") and self.err.cget("text_color") == C("status_error"):
            self.err.configure(text="")
        if cfg != planning_service.load_config(self.ctx.settings):   # автозбереження валідного графіка
            planning_service.save_config(self.ctx.settings, cfg)
        times = ", ".join(x.strftime("%H:%M") for x in day_times(cfg))
        label(self.prev_body, t("scheduler.times", times=times), 13, secondary=True).pack(
            anchor="w", pady=(2, 8))
        pending, slots = planning_service.preview(self.ctx, cfg)
        if not pending:
            label(self.prev_body, t("scheduler.summary.none"), 13, secondary=True).pack(anchor="w")
            return
        label(self.prev_body, t("scheduler.summary", pending=len(pending), n=len(slots)), 14,
              bold=True).pack(anchor="w", pady=(0, 6))
        if len(slots) < len(pending):
            ctk.CTkLabel(self.prev_body, text=t("scheduler.overflow", n=len(pending) - len(slots)),
                         font=font(12, True), text_color=C("status_posting"), anchor="w").pack(anchor="w")
        for post, slot in list(zip(pending, slots))[:10]:
            wd = t(f"weekday.{WEEKDAYS[slot.weekday()]}")
            label(self.prev_body, f"{wd}  {slot:%d.%m.%Y  %H:%M}   —   {post['name']}", 13).pack(
                anchor="w", pady=1)
        if len(slots) > 10:
            label(self.prev_body, t("scheduler.more", n=len(slots) - 10), 12, secondary=True).pack(
                anchor="w", pady=(4, 0))
