"""Головне вікно APOST: бічне меню + сторінки."""
from __future__ import annotations

import tkinter as tk
from pathlib import Path

import customtkinter as ctk

from core import config
from core.context import AppContext
from ui.base_page import BasePage
from ui.calendar import CalendarPage
from ui.dashboard import DashboardPage
from ui.history import HistoryPage
from ui.queue import QueuePage
from ui.scheduler_page import SchedulerPage
from ui.settings import SettingsPage
from ui.sidebar import Sidebar
from ui.video_library import VideoLibraryPage
from ui.widgets import C
from utils.logger import get_logger

log = get_logger("ui")

try:  # Drag & Drop необов'язковий: без tkinterdnd2 працюють кнопки «Додати відео»
    from tkinterdnd2 import DND_FILES, TkinterDnD
    _BASES = (ctk.CTk, TkinterDnD.DnDWrapper)
except Exception:  # pragma: no cover
    DND_FILES, TkinterDnD, _BASES = None, None, (ctk.CTk,)

PAGES: dict[str, type[BasePage]] = {
    "dashboard": DashboardPage,
    "library": VideoLibraryPage,
    "queue": QueuePage,
    "calendar": CalendarPage,
    "scheduler": SchedulerPage,
    "history": HistoryPage,
    "settings": SettingsPage,
}


class AppWindow(*_BASES):
    def __init__(self, ctx: AppContext) -> None:
        super().__init__(fg_color=C("bg"))
        self.ctx = ctx
        ctx.navigate = self.show_page
        self.current = "dashboard"
        self._rebuild_job: str | None = None

        self.geometry("1280x840")
        self.minsize(1040, 700)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)

        self.sidebar: Sidebar | None = None
        self.pages: dict[str, BasePage] = {}
        self._build()

        ctx.lang.subscribe(self._schedule_rebuild)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        self._set_icon()
        self._setup_dnd()
        self._seen_rev = ctx.db.revision if ctx.db else 0
        self.after(1000, self._poll)

    # ---------- іконка вікна / Dock ----------
    def _set_icon(self) -> None:
        try:
            png = config.resource_path("assets/icons/apost_icon_256.png")
            self._icon = tk.PhotoImage(file=str(png))
            self.iconphoto(True, self._icon)
        except Exception:
            log.warning("Не вдалося встановити іконку вікна", exc_info=True)

    # ---------- Drag & Drop ----------
    def _setup_dnd(self) -> None:
        self.dnd_ok = False
        if TkinterDnD is None:
            return
        try:
            self.TkdndVersion = TkinterDnD._require(self)
            self.drop_target_register(DND_FILES)
            self.dnd_bind("<<Drop>>", self._on_drop)
            self.dnd_ok = True
        except Exception:
            log.warning("Drag & Drop недоступний — працюють кнопки додавання", exc_info=True)

    def _on_drop(self, event) -> None:
        try:
            paths = [p for p in self.tk.splitlist(event.data)]
        except Exception:
            return
        self.show_page("library")
        self.pages["library"].import_paths(paths)
        return event.action

    # ---------- оновлення за змінами в БД ----------
    def _poll(self) -> None:
        try:
            rev = self.ctx.db.revision
            if rev != self._seen_rev:
                self._seen_rev = rev
                self.pages[self.current].refresh()
        except Exception:
            log.exception("Помилка оновлення сторінки")
        self.after(1000, self._poll)

    # ---------- побудова ----------
    def _build(self) -> None:
        self.title(self.ctx.t("app.window_title"))
        self.sidebar = Sidebar(self, self.ctx, self.show_page)
        self.sidebar.grid(row=0, column=0, sticky="ns")

        self.content = ctk.CTkFrame(self, fg_color=C("bg"), corner_radius=0)
        self.content.grid(row=0, column=1, sticky="nsew")
        self.content.columnconfigure(0, weight=1)
        self.content.rowconfigure(0, weight=1)

        self.pages = {}
        for key, cls in PAGES.items():
            page = cls(self.content, self.ctx)
            page.grid(row=0, column=0, sticky="nsew")
            self.pages[key] = page
        self.show_page(self.current)

    def show_page(self, key: str) -> None:
        if key not in self.pages:
            log.error("Невідома сторінка: %s", key)
            return
        self.current = key
        self.pages[key].tkraise()
        self.pages[key].on_show()
        self.sidebar.set_active(key)

    # ---------- зміна мови ----------
    def _schedule_rebuild(self) -> None:
        # відкладаємо, щоб не знищувати віджет усередині його власного callback
        if self._rebuild_job is None:
            self._rebuild_job = self.after(20, self._rebuild)

    def _rebuild(self) -> None:
        self._rebuild_job = None
        self.sidebar.destroy()
        self.content.destroy()
        self._build()

    def on_close(self) -> None:
        log.info("Завершення роботи APOST")
        try:
            if self.ctx.engine:
                self.ctx.engine.stop()
            if self.ctx.db:
                self.ctx.db.close()
        except Exception:
            log.exception("Помилка при завершенні")
        self.destroy()
