"""Базовий клас сторінки: однакова структура заголовка для всіх розділів."""
from __future__ import annotations

import customtkinter as ctk

from core.context import AppContext
from ui.widgets import C, label


class BasePage(ctk.CTkFrame):
    title_key = ""
    subtitle_key = ""

    def __init__(self, master, ctx: AppContext) -> None:
        super().__init__(master, fg_color=C("bg"), corner_radius=0)
        self.ctx = ctx
        self.t = ctx.t

        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        self.header = ctk.CTkFrame(self, fg_color="transparent")
        self.header.grid(row=0, column=0, sticky="ew", padx=32, pady=(28, 16))
        self.header.columnconfigure(0, weight=1)
        label(self.header, self.t(self.title_key), 28, bold=True).grid(
            row=0, column=0, sticky="w")
        label(self.header, self.t(self.subtitle_key), 14, secondary=True).grid(
            row=1, column=0, sticky="w", pady=(2, 0))
        self.header_actions = ctk.CTkFrame(self.header, fg_color="transparent", height=0)
        self.header_actions.grid(row=0, column=1, rowspan=2, sticky="e")

        self.body = ctk.CTkFrame(self, fg_color="transparent")
        self.body.grid(row=1, column=0, sticky="nsew", padx=32, pady=(0, 28))
        self.body.columnconfigure(0, weight=1)

        self.build()

    def build(self) -> None:  # перевизначається в нащадках
        pass

    def refresh(self) -> None:  # оновлення даних зі сховища (БД)
        pass

    def on_show(self) -> None:  # викликається при відкритті сторінки
        self.refresh()
