"""Відеотека: додавання (одне/масово/перетягуванням), мініатюри, перегляд, редагування."""
from __future__ import annotations

import os
import threading
from pathlib import Path
from tkinter import filedialog

import customtkinter as ctk

from core.video_manager import ALLOWED_EXT
from publisher.tiktok_publisher import open_file
from ui.base_page import BasePage
from ui.dialogs import EditDialog, ask, info
from ui.widgets import (C, Card, EmptyState, chip, font, icon_button, label, primary_button,
                        PagedRows, secondary_button, small_button, thumb_image)
from utils import video_utils


_PATTERNS = " ".join(f"*{e} *{e.upper()}" for e in ALLOWED_EXT)
_FILETYPES = [("Video", _PATTERNS)]


class VideoLibraryPage(BasePage):
    title_key = "library.title"
    subtitle_key = "library.subtitle"

    def build(self) -> None:
        t = self.t
        self._rev = -1
        self._importing = False
        self._progress = (0, 0)
        self._result = None

        secondary_button(self.header_actions, t("library.all_to_queue"),
                         self._all_to_queue).pack(side="left", padx=(0, 8))
        secondary_button(self.header_actions, t("action.add_many"),
                         self._pick_many).pack(side="left", padx=(0, 8))
        primary_button(self.header_actions, t("action.add_video"), self._pick_one).pack(side="left")

        self.body.rowconfigure(1, weight=1)
        self.info = ctk.CTkLabel(self.body, text="", font=font(13), anchor="w",
                                 text_color=C("text_secondary"))
        self.info.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        self.holder = ctk.CTkFrame(self.body, fg_color="transparent")
        self.holder.grid(row=1, column=0, sticky="nsew")
        self.holder.columnconfigure(0, weight=1)
        self.holder.rowconfigure(0, weight=1)
        self.refresh(force=True)

    # ---------- додавання ----------
    def _pick_one(self) -> None:
        path = filedialog.askopenfilename(title=self.t("library.select_title"),
                                          filetypes=_FILETYPES)
        if path:
            self.import_paths([path])

    def _pick_many(self) -> None:
        paths = filedialog.askopenfilenames(title=self.t("library.select_title"),
                                            filetypes=_FILETYPES)
        if paths:
            self.import_paths(list(paths))

    def import_paths(self, paths: list[str]) -> None:
        """Імпорт у фоновому потоці (не блокує інтерфейс); також викликається при Drag & Drop."""
        files: list[str] = []
        for p in paths:
            pp = Path(p)
            files += (sorted(str(x) for x in pp.iterdir() if x.suffix.lower() in ALLOWED_EXT)
                      if pp.is_dir() else [str(pp)])
        if not files or self._importing:
            return
        self._importing, self._result, self._progress = True, None, (0, len(files))

        def work():
            self._result = self.ctx.videos.import_files(
                files, progress=lambda d, n: setattr(self, "_progress", (d, n)))
        threading.Thread(target=work, daemon=True).start()
        self._poll_import()

    def _poll_import(self) -> None:
        if not self.winfo_exists():
            return
        if self._result is None:
            d, n = self._progress
            self.info.configure(text=self.t("library.importing", done=d, total=n),
                                text_color=C("accent"))
            self.after(150, self._poll_import)
            return
        res, self._importing = self._result, False
        self.info.configure(text=self.t("library.import_done", added=len(res.added),
                                        skipped=len(res.skipped)), text_color=C("text_secondary"))
        self.refresh(force=True)
        if res.skipped:
            lines = [f"• {Path(p).name}: {self.t('import.err.' + code)}" for p, code in res.skipped[:8]]
            if len(res.skipped) > 8:
                lines.append(self.t("scheduler.more", n=len(res.skipped) - 8))
            info(self, self.t("library.skipped_title"), "\n".join(lines), self.t("common.ok"))

    # ---------- дії ----------
    def _all_to_queue(self) -> None:
        n = self.ctx.db.add_to_queue([v["id"] for v in reversed(self.ctx.db.list_videos())])
        self.info.configure(text=self.t("library.added_to_queue", n=n))

    def _to_queue(self, vid: int) -> None:
        self.ctx.db.add_to_queue([vid])

    def _delete(self, row) -> None:
        if ask(self, self.t("library.delete.title"), self.t("library.delete.text", name=row["original_name"]),
               self.t("common.delete"), self.t("common.cancel"), danger=True):
            self.ctx.videos.delete_video(row["id"])

    # ---------- відображення ----------
    def refresh(self, force: bool = False) -> None:
        if self._importing and not force:      # під час імпорту не перебудовуємо список щосекунди
            return
        if not force and self._rev == self.ctx.db.revision:
            return
        self._rev = self.ctx.db.revision
        shown = getattr(self, "_paged", None).n if getattr(self, "_paged", None) else 0
        for w in self.holder.winfo_children():
            w.destroy()
        rows = self.ctx.db.list_videos()
        if not self._importing:
            hint = self.t("library.count", n=len(rows)) + "   " + self.t("library.drop_hint")
            if not video_utils.find_ffmpeg():
                hint = self.t("library.no_ffmpeg")
            self.info.configure(text=hint, text_color=C("text_secondary"))
        if not rows:
            EmptyState(self.holder, "library", self.t("library.empty.title"),
                       self.t("library.empty.text")).grid(row=0, column=0, sticky="nsew")
            return
        scroll = ctk.CTkScrollableFrame(self.holder, fg_color="transparent", corner_radius=0)
        scroll.grid(row=0, column=0, sticky="nsew")
        scroll.columnconfigure(0, weight=1)
        self._paged = PagedRows(scroll, rows, self._row, lambda n: self.t("common.show_more", n=n),
                                shown=shown)

    def _row(self, parent, i: int, v) -> None:
        t = self.t
        card = Card(parent)
        card.grid(row=i, column=0, sticky="ew", pady=5)
        card.columnconfigure(1, weight=1)
        ctk.CTkLabel(card, text="", image=thumb_image(v["thumb_path"])).grid(
            row=0, column=0, padx=14, pady=12)
        box = ctk.CTkFrame(card, fg_color="transparent")
        box.grid(row=0, column=1, sticky="ew", pady=10)
        label(box, v["original_name"], 15, bold=True).pack(anchor="w")
        meta = t("library.meta", duration=video_utils.format_duration(v["duration_sec"]),
                 size=video_utils.format_size(v["size_bytes"]))
        label(box, meta, 12, secondary=True).pack(anchor="w")
        if v["description"]:
            label(box, v["description"].replace("\n", " ")[:90], 12).pack(anchor="w", pady=(3, 0))
        if v["hashtags"]:
            ctk.CTkLabel(box, text=v["hashtags"][:90], font=font(12), anchor="w",
                         text_color=C("accent")).pack(anchor="w")

        status = v["post_status"]
        missing = not os.path.exists(v["path"])
        if missing and status != "published":
            chip(card, t("library.chip.missing"), "error").grid(row=0, column=2, padx=8)
        elif status == "published":
            chip(card, t("library.chip.published"), "published").grid(row=0, column=2, padx=8)
        elif status == "error":
            chip(card, t("library.chip.error"), "error").grid(row=0, column=2, padx=8)
        elif status:
            chip(card, t("library.chip.queued"), "scheduled").grid(row=0, column=2, padx=8)
        else:
            chip(card, t("library.chip.none"), "pending").grid(row=0, column=2, padx=8)

        btns = ctk.CTkFrame(card, fg_color="transparent")
        btns.grid(row=0, column=3, padx=(4, 12))
        icon_button(btns, "eye", lambda p=v["path"]: open_file(p)).pack(side="left")
        icon_button(btns, "pencil", lambda vid=v["id"]: EditDialog(
            self, self.ctx, video_id=vid, on_saved=None)).pack(side="left")
        if not status and not missing:
            small_button(btns, t("library.to_queue"), lambda vid=v["id"]: self._to_queue(vid),
                         icon="plus").pack(side="left", padx=4)
        icon_button(btns, "trash", lambda row=v: self._delete(row), tone="danger").pack(side="left")
