"""Налаштування: тема, мова, розклад, акаунт TikTok, сповіщення."""
from __future__ import annotations

import threading
import webbrowser

import requests

import customtkinter as ctk

from core import config, planning_service
from core.language_manager import LANGUAGES
from core.schedule_planner import parse_time
from ui.base_page import BasePage
from publisher.tiktok_api import TikTokError
from ui.widgets import C, Card, font, label, primary_button, secondary_button, segmented

TIMEZONES = ["Europe/Kyiv", "Europe/Warsaw", "Europe/Berlin", "Europe/London",
             "UTC", "America/New_York", "America/Los_Angeles"]


class SettingsPage(BasePage):
    title_key = "settings.title"
    subtitle_key = "settings.subtitle"

    # ---------- допоміжні ----------
    def _section(self, parent, title_key: str, desc_key: str | None = None) -> ctk.CTkFrame:
        card = Card(parent)
        card.pack(fill="x", pady=7)
        label(card, self.t(title_key), 17, bold=True).pack(anchor="w", padx=20, pady=(16, 0))
        if desc_key:
            label(card, self.t(desc_key), 13, secondary=True).pack(anchor="w", padx=20, pady=(2, 10))
        else:
            ctk.CTkFrame(card, height=6, fg_color="transparent").pack()
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill="x", padx=20, pady=(0, 18))
        return inner

    def _segmented(self, parent, values: list[str]) -> ctk.CTkSegmentedButton:
        return segmented(parent, values)

    def _switch(self, parent, text: str, key: str, notify: bool = True) -> ctk.CTkSwitch:
        var = ctk.BooleanVar(value=bool(self.ctx.settings.get(key, True)))
        sw = ctk.CTkSwitch(
            parent, text=text, variable=var, font=font(14), text_color=C("text"),
            text_color_disabled=C("text_secondary"), progress_color=C("accent"),
            command=lambda: self._on_notify(key, var.get(), notify),
        )
        sw._apost_var = var  # утримуємо посилання
        sw.pack(anchor="w", pady=5)
        return sw

    # ---------- побудова ----------
    def build(self) -> None:
        t, ctx = self.t, self.ctx
        self.body.rowconfigure(0, weight=1)
        scroll = ctk.CTkScrollableFrame(self.body, fg_color="transparent", corner_radius=0)
        scroll.grid(row=0, column=0, sticky="nsew")

        # Appearance
        inner = self._section(scroll, "settings.appearance.title", "settings.appearance.desc")
        self._theme_names = {"light": t("settings.theme.light"), "dark": t("settings.theme.dark")}
        self.theme_seg = self._segmented(inner, list(self._theme_names.values()))
        self.theme_seg.set(self._theme_names[ctx.theme.mode])
        self.theme_seg.configure(command=self._on_theme)
        self.theme_seg.pack(anchor="w")

        # Language
        inner = self._section(scroll, "settings.language.title", "settings.language.desc")
        self.lang_seg = self._segmented(inner, list(LANGUAGES.values()))
        self.lang_seg.set(LANGUAGES[ctx.lang.code])
        self.lang_seg.configure(command=self._on_language)
        self.lang_seg.pack(anchor="w")

        # Schedule
        inner = self._section(scroll, "settings.schedule.title", "settings.schedule.desc")
        label(inner, t("settings.schedule.timezone"), 13, secondary=True).pack(anchor="w")
        tz = ctx.settings.get("timezone")
        values = TIMEZONES if tz in TIMEZONES else [tz] + TIMEZONES
        self.tz_menu = ctk.CTkOptionMenu(
            inner, values=values, width=260, height=40, corner_radius=20, command=self._on_timezone,
            fg_color=C("bg"), button_color=C("accent"), button_hover_color=C("accent_hover"),
            text_color=C("text"))
        self.tz_menu.set(tz)
        self.tz_menu.pack(anchor="w", pady=(4, 0))

        row = ctk.CTkFrame(inner, fg_color="transparent", height=0)
        row.pack(anchor="w", pady=(12, 0))
        self.sch = {}
        saved = planning_service.load_config(ctx.settings)
        for key, tkey, val in (("per_day", "settings.schedule.per_day", str(saved.per_day)),
                               ("first", "settings.schedule.first", saved.first.strftime("%H:%M")),
                               ("last", "settings.schedule.last", saved.last.strftime("%H:%M"))):
            cell = ctk.CTkFrame(row, fg_color="transparent", height=0)
            cell.pack(side="left", padx=(0, 14))
            label(cell, t(tkey), 13, secondary=True).pack(anchor="w")
            e = ctk.CTkEntry(cell, width=130, height=40, corner_radius=20, fg_color=C("bg"),
                             border_color=C("border"), text_color=C("text"))
            e.insert(0, val)
            e.pack(pady=(4, 0))
            self.sch[key] = e
        srow = ctk.CTkFrame(inner, fg_color="transparent", height=0)
        srow.pack(anchor="w", pady=(10, 0))
        primary_button(srow, t("settings.schedule.save"), self._save_schedule, width=170).pack(side="left")
        self.sch_msg = ctk.CTkLabel(srow, text="", font=font(12, True), anchor="w")
        self.sch_msg.pack(side="left", padx=12)

        # Video library
        from utils import video_utils
        inner = self._section(scroll, "settings.library.title", "settings.library.desc")
        self._switch(inner, t("settings.library.copy"), "copy_videos", notify=False)
        ok = video_utils.find_ffmpeg() is not None
        ctk.CTkLabel(inner, text=t("settings.library.ffmpeg_ok" if ok else "settings.library.ffmpeg_missing"),
                     font=font(13, True), anchor="w",
                     text_color=C("status_published" if ok else "status_error")).pack(anchor="w", pady=(6, 0))

        # TikTok account
        inner = self._section(scroll, "settings.tiktok.title", "settings.tiktok.desc")
        self._build_tiktok(inner)

        # Notifications
        inner = self._section(scroll, "settings.notifications.title")
        self.sw_main = self._switch(inner, t("settings.notifications.enabled"), "notify_enabled")
        self.sw_sched = self._switch(inner, t("settings.notifications.scheduled"), "notify_scheduled")
        self.sw_err = self._switch(inner, t("settings.notifications.errors"), "notify_errors")
        self._sync_notify_state()

        # Releases are hosted publicly on GitHub. Checking is user initiated; the
        # app opens the release page so the user can review and install updates.
        inner = self._section(scroll, "settings.updates.title")
        update_row = ctk.CTkFrame(inner, fg_color="transparent", height=0)
        update_row.pack(anchor="w", fill="x")
        secondary_button(update_row, t("settings.updates.check"), self._check_updates,
                         width=190).pack(side="left")
        self.update_status = ctk.CTkLabel(update_row, text="", font=font(12), anchor="w",
                                          text_color=C("text_secondary"))
        self.update_status.pack(side="left", padx=12)

    # ---------- TikTok ----------
    def _build_tiktok(self, inner) -> None:
        t, ctx = self.t, self.ctx
        auth = ctx.tiktok
        self._tt_busy = False
        grid = ctk.CTkFrame(inner, fg_color="transparent", height=0)
        grid.pack(anchor="w", fill="x")
        for i, (key, tkey) in enumerate((("key", "settings.tiktok.client_key"),
                                         ("secret", "settings.tiktok.client_secret"))):
            cell = ctk.CTkFrame(grid, fg_color="transparent", height=0)
            cell.pack(side="left", padx=(0, 14))
            label(cell, t(tkey), 13, secondary=True).pack(anchor="w")
            e = ctk.CTkEntry(cell, width=260, height=40, corner_radius=20, fg_color=C("bg"),
                             border_color=C("border"), text_color=C("text"),
                             show="•" if key == "secret" else "")
            e.pack(pady=(4, 0))
            if key == "key":
                e.insert(0, ctx.settings.get("tiktok_client_key", ""))
            elif auth and auth.store.get("client_secret"):
                e.configure(placeholder_text=t("settings.tiktok.secret_saved"))
            setattr(self, f"tt_{key}", e)
        primary_button(grid, t("settings.tiktok.save_keys"), self._tt_save_keys, width=150).pack(
            side="left", pady=(20, 0))

        label(inner, t("settings.tiktok.redirect"), 12, secondary=True).pack(anchor="w", pady=(12, 2))
        rrow = ctk.CTkFrame(inner, fg_color="transparent", height=0)
        rrow.pack(anchor="w")
        uri = auth.redirect_uri if auth else ""
        ctk.CTkLabel(rrow, text=uri, font=font(13, True), text_color=C("accent")).pack(side="left")
        secondary_button(rrow, t("settings.tiktok.copy"), lambda: self._copy(uri), width=110,
                         height=34).pack(side="left", padx=12)

        srow = ctk.CTkFrame(inner, fg_color="transparent", height=0)
        srow.pack(anchor="w", pady=(14, 0))
        label(srow, t("settings.tiktok.status") + ":", 14, secondary=True).pack(side="left")
        connected = bool(auth and auth.is_connected())
        name = auth.account_name() if auth else ""
        self.tt_status = ctk.CTkLabel(
            srow, font=font(14, True), text="  " + (t("settings.tiktok.connected", name=name or "TikTok")
                                                  if connected else t("settings.tiktok.not_connected")),
            text_color=C("status_published" if connected else "status_error"))
        self.tt_status.pack(side="left")

        btns = ctk.CTkFrame(inner, fg_color="transparent", height=0)
        btns.pack(anchor="w", pady=(10, 0))
        self.tt_connect = primary_button(btns, t("settings.tiktok.connect"), self._tt_connect, width=170)
        self.tt_connect.pack(side="left", padx=(0, 8))
        secondary_button(btns, t("settings.tiktok.check"), self._tt_check, width=170).pack(side="left", padx=(0, 8))
        secondary_button(btns, t("settings.tiktok.disconnect"), self._tt_disconnect, width=130).pack(side="left")
        self.tt_msg = ctk.CTkLabel(inner, text="", font=font(12, True), anchor="w", wraplength=640,
                                   justify="left")
        self.tt_msg.pack(anchor="w", pady=(8, 0))

        label(inner, t("settings.tiktok.mode"), 13, secondary=True).pack(anchor="w", pady=(14, 4))
        self._mode_names = {m: t(f"settings.tiktok.mode.{m}") for m in ("manual", "inbox", "direct")}
        self.tt_mode = segmented(inner, list(self._mode_names.values()), self._tt_mode)
        self.tt_mode.set(self._mode_names[ctx.settings.get("tiktok_mode", "manual")])
        self.tt_mode.pack(anchor="w")
        self.tt_mode_desc = ctk.CTkLabel(inner, text="", font=font(12), anchor="w", wraplength=640,
                                         justify="left", text_color=C("text_secondary"))
        self.tt_mode_desc.pack(anchor="w", pady=(6, 0))
        self._tt_mode_desc_update()

        label(inner, t("settings.tiktok.privacy"), 13, secondary=True).pack(anchor="w", pady=(12, 4))
        self._privacy = {c: t(f"settings.tiktok.privacy.{c}") for c in
                         ("SELF_ONLY", "MUTUAL_FOLLOW_FRIENDS", "FOLLOWER_OF_CREATOR", "PUBLIC_TO_EVERYONE")}
        self.tt_privacy = ctk.CTkOptionMenu(
            inner, values=list(self._privacy.values()), width=220, height=40, corner_radius=20,
            fg_color=C("bg"), button_color=C("accent"), button_hover_color=C("accent_hover"),
            text_color=C("text"), command=self._tt_privacy)
        self.tt_privacy.set(self._privacy.get(ctx.settings.get("tiktok_privacy", "SELF_ONLY"),
                                              self._privacy["SELF_ONLY"]))
        self.tt_privacy.pack(anchor="w")
        ctk.CTkLabel(inner, text=t("settings.tiktok.audit_note"), font=font(12, True), wraplength=640,
                     justify="left", anchor="w", text_color=C("accent")).pack(anchor="w", pady=(8, 0))

    def _tt_say(self, text: str, ok: bool = True, busy: bool = False) -> None:
        if self.tt_msg.winfo_exists():
            self.tt_msg.configure(text=text, text_color=C("accent" if busy else (
                "status_published" if ok else "status_error")))

    def _tt_err(self, exc) -> str:
        code = getattr(exc, "code", "")
        key = f"error.{code}"
        return self.t(key) if key in self.ctx.lang._tables["en"] else str(exc)[:200]

    def _copy(self, text: str) -> None:
        self.clipboard_clear()
        self.clipboard_append(text)

    def _tt_save_keys(self) -> None:
        key, secret = self.tt_key.get().strip(), self.tt_secret.get().strip()
        if not key or not (secret or self.ctx.tiktok.store.get("client_secret")):
            return self._tt_say(self.t("settings.tiktok.keys_need"), ok=False)
        try:
            self.ctx.tiktok.save_credentials(key, secret)
        except TikTokError as exc:
            return self._tt_say(self._tt_err(exc), ok=False)
        self.tt_secret.delete(0, "end")
        self.tt_secret.configure(placeholder_text=self.t("settings.tiktok.secret_saved"))
        self._tt_say(self.t("settings.tiktok.keys_saved"))

    def _tt_run(self, work, done) -> None:
        """Мережеві дії — у фоні, щоб вікно не «замерзало»."""
        if self._tt_busy:
            return
        self._tt_busy, box = True, {}

        def runner():
            try:
                box["value"] = work()
            except TikTokError as exc:
                box["error"] = exc
            except Exception as exc:  # noqa: BLE001
                box["error"] = TikTokError("error", str(exc))
            box["done"] = True
        threading.Thread(target=runner, daemon=True).start()

        def poll():
            if not self.winfo_exists():
                return
            if not box.get("done"):
                self.after(200, poll)
                return
            self._tt_busy = False
            done(box)
        poll()

    def _tt_connect(self) -> None:
        if not self.ctx.tiktok.is_configured():
            return self._tt_say(self.t("settings.tiktok.keys_need"), ok=False)
        self._tt_say(self.t("settings.tiktok.waiting"), busy=True)

        def done(box):
            if "error" in box:
                return self._tt_say(self._tt_err(box["error"]), ok=False)
            name = box["value"]
            self.tt_status.configure(text="  " + self.t("settings.tiktok.connected", name=name),
                                     text_color=C("status_published"))
            self._tt_say(self.t("settings.tiktok.connect_ok", name=name))
        self._tt_run(self.ctx.tiktok.login, done)

    def _tt_check(self) -> None:
        auth = self.ctx.tiktok
        if not auth.is_connected():
            return self._tt_say(self._tt_err(TikTokError("reauth")), ok=False)
        self._tt_say("…", busy=True)

        def done(box):
            if "error" in box:
                return self._tt_say(self._tt_err(box["error"]), ok=False)
            opts = ", ".join(self._privacy.get(o, o) for o in box["value"].get("privacy_level_options", []))
            self._tt_say(self.t("settings.tiktok.check_ok", opts=opts or "—"))
        self._tt_run(lambda: auth.client.creator_info(auth.access_token()), done)

    def _tt_disconnect(self) -> None:
        self.ctx.tiktok.disconnect()
        self.tt_status.configure(text="  " + self.t("settings.tiktok.not_connected"),
                                 text_color=C("status_error"))
        self._tt_say("")

    def _tt_mode(self, value: str) -> None:
        mode = next(k for k, v in self._mode_names.items() if v == value)
        self.ctx.settings.set("tiktok_mode", mode)
        self._tt_mode_desc_update()

    def _tt_mode_desc_update(self) -> None:
        self.tt_mode_desc.configure(
            text=self.t(f"settings.tiktok.mode_desc.{self.ctx.settings.get('tiktok_mode', 'manual')}"))

    def _tt_privacy(self, value: str) -> None:
        code = next(k for k, v in self._privacy.items() if v == value)
        self.ctx.settings.set("tiktok_privacy", code)

    # ---------- обробники ----------
    def _on_theme(self, value: str) -> None:
        mode = next(k for k, v in self._theme_names.items() if v == value)
        self.ctx.theme.apply(mode)

    def _on_language(self, value: str) -> None:
        code = next(k for k, v in LANGUAGES.items() if v == value)
        self.ctx.lang.set_language(code)  # застосунок перебудує інтерфейс

    def _save_schedule(self) -> None:
        cfg = planning_service.load_config(self.ctx.settings)
        try:
            cfg.per_day = int(self.sch["per_day"].get().strip())
        except ValueError:
            return self._sch_error("per_day")
        first, last = parse_time(self.sch["first"].get()), parse_time(self.sch["last"].get())
        if first is None or last is None:
            return self._sch_error("bad_time")
        cfg.first, cfg.last = first, last
        err = cfg.validate()
        if err:
            return self._sch_error(err)
        planning_service.save_config(self.ctx.settings, cfg)
        self.sch_msg.configure(text=self.t("settings.schedule.saved"), text_color=C("status_published"))

    def _sch_error(self, code: str) -> None:
        self.sch_msg.configure(text=self.t(f"scheduler.err.{code}"), text_color=C("status_error"))

    def _on_timezone(self, value: str) -> None:
        self.ctx.settings.set("timezone", value)

    def _on_notify(self, key: str, value: bool, notify: bool = True) -> None:
        self.ctx.settings.set(key, bool(value))
        if notify:
            self._sync_notify_state()

    def _sync_notify_state(self) -> None:
        state = "normal" if self.ctx.settings.get("notify_enabled", True) else "disabled"
        self.sw_sched.configure(state=state)
        self.sw_err.configure(state=state)

    def _check_updates(self) -> None:
        self.update_status.configure(text=self.t("settings.updates.checking"))
        result: dict = {}

        def fetch() -> None:
            try:
                response = requests.get(
                    "https://api.github.com/repos/maksimstahiv03-del/apost-macos/releases/latest",
                    headers={"Accept": "application/vnd.github+json",
                             "User-Agent": "APOST-macOS"}, timeout=8)
                if response.status_code == 404:
                    result["version"] = None
                else:
                    response.raise_for_status()
                    release = response.json()
                    tag = str(release.get("tag_name", "")).lstrip("v")
                    result["version"] = tag
                    result["url"] = release.get(
                        "html_url", "https://github.com/maksimstahiv03-del/apost-macos/releases/latest")
            except Exception:
                result["error"] = True
            result["done"] = True

        def poll() -> None:
            if not self.winfo_exists():
                return
            if not result.get("done"):
                self.after(150, poll)
                return
            if result.get("error"):
                text = self.t("settings.updates.failed")
            elif not result.get("version"):
                text = self.t("settings.updates.none_published")
            else:
                current = tuple(int(x) for x in config.APP_VERSION.split(".") if x.isdigit())
                latest = tuple(int(x) for x in result["version"].split(".") if x.isdigit())
                if latest > current:
                    text = self.t("settings.updates.available", version=result["version"])
                    webbrowser.open(result["url"])
                else:
                    text = self.t("settings.updates.current", version=config.APP_VERSION)
            self.update_status.configure(text=text)

        threading.Thread(target=fetch, daemon=True).start()
        self.after(150, poll)
