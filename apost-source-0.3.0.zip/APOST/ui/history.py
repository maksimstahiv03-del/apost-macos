"""Історія публікацій з фільтрами за датою та статусом."""
from __future__ import annotations

from datetime import datetime, timedelta

import customtkinter as ctk

from core.schedule_planner import parse_date
from ui.base_page import BasePage
from ui.widgets import (C, Card, EmptyState, PagedRows, chip, font, label, primary_button,
                        secondary_button)

EVENTS = [("published", "published"), ("error", "error"), ("manual", "posting")]  # (код, колір)


class HistoryPage(BasePage):
    title_key = "history.title"
    subtitle_key = "history.subtitle"

    def build(self) -> None:
        t = self.t
        self._rev = -1
        self.body.rowconfigure(1, weight=1)

        bar = ctk.CTkFrame(self.body, fg_color="transparent", height=0)
        bar.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        label(bar, t("history.filter.status"), 13, secondary=True).pack(side="left", padx=(0, 8))
        self._names = {t("history.filter.all"): None}
        for code, _ in EVENTS:
            self._names[t(f"history.event.{code}")] = code
        self.status_menu = ctk.CTkOptionMenu(
            bar, values=list(self._names), width=170, height=40, corner_radius=20,
            fg_color=C("bg_secondary"), button_color=C("accent"), button_hover_color=C("accent_hover"),
            text_color=C("text"), command=lambda _v: self.refresh(force=True))
        self.status_menu.set(t("history.filter.all"))
        self.status_menu.pack(side="left")
        self.d_from = self._date_entry(bar, t("history.from"))
        self.d_to = self._date_entry(bar, t("history.to"))
        primary_button(bar, t("history.apply"), lambda: self.refresh(force=True), width=120).pack(
            side="left", padx=(12, 6))
        secondary_button(bar, t("history.reset"), self._reset, width=100).pack(side="left")
        self.msg = label(bar, "", 12, secondary=True)
        self.msg.pack(side="right")

        self.holder = ctk.CTkFrame(self.body, fg_color="transparent")
        self.holder.grid(row=1, column=0, sticky="nsew")
        self.holder.columnconfigure(0, weight=1)
        self.holder.rowconfigure(0, weight=1)
        self.refresh(force=True)

    def _date_entry(self, bar, text: str) -> ctk.CTkEntry:
        label(bar, text, 13, secondary=True).pack(side="left", padx=(16, 6))
        e = ctk.CTkEntry(bar, width=120, height=40, corner_radius=20, placeholder_text="РРРР-ММ-ДД",
                         fg_color=C("bg_secondary"), border_color=C("border"), text_color=C("text"))
        e.pack(side="left")
        return e

    def _reset(self) -> None:
        for e in (self.d_from, self.d_to):
            e.delete(0, "end")
        self.status_menu.set(self.t("history.filter.all"))
        self.refresh(force=True)

    def _utc_bounds(self):
        lo = hi = None
        for entry, which in ((self.d_from, "lo"), (self.d_to, "hi")):
            txt = entry.get().strip()
            if not txt:
                continue
            d = parse_date(txt)
            if d is None:
                raise ValueError
            if which == "lo":
                lo = self.ctx.to_utc(datetime.combine(d, datetime.min.time()))
            else:
                hi = self.ctx.to_utc(datetime.combine(d + timedelta(days=1), datetime.min.time()))
        return lo, hi

    def refresh(self, force: bool = False) -> None:
        ctx, t = self.ctx, self.t
        if not force and self._rev == ctx.db.revision:
            return
        self._rev = ctx.db.revision
        for w in self.holder.winfo_children():
            w.destroy()
        try:
            lo, hi = self._utc_bounds()
        except ValueError:
            self.msg.configure(text=t("history.err.date"), text_color=C("status_error"))
            return
        rows = ctx.db.history(self._names.get(self.status_menu.get()), lo, hi)
        self.msg.configure(text=t("history.count", n=len(rows)), text_color=C("text_secondary"))
        if not rows:
            EmptyState(self.holder, "history", t("history.empty.title"),
                       t("history.empty.text")).grid(row=0, column=0, sticky="nsew")
            return
        scroll = ctk.CTkScrollableFrame(self.holder, fg_color="transparent", corner_radius=0)
        scroll.grid(row=0, column=0, sticky="nsew")
        scroll.columnconfigure(0, weight=1)
        colors = dict(EVENTS)

        def make_row(parent, i, r):
            card = Card(parent)
            card.grid(row=i, column=0, sticky="ew", pady=4)
            card.columnconfigure(2, weight=1)
            dt = ctx.to_local(r["at"])
            label(card, dt.strftime("%d.%m.%Y"), 13, secondary=True, width=90).grid(
                row=0, column=0, padx=(18, 4), pady=14)
            label(card, dt.strftime("%H:%M"), 13, secondary=True, width=50).grid(row=0, column=1)
            box = ctk.CTkFrame(card, fg_color="transparent", height=0)
            box.grid(row=0, column=2, sticky="ew", padx=10)
            label(box, r["video_title"], 14, bold=True).pack(anchor="w")
            msg = r["message"] or ""
            if r["status"] == "error" and msg:
                msg = t(f"error.{msg}") if f"error.{msg}" in ctx.lang._tables["en"] else msg
            elif r["status"] == "published":
                msg = t("history.by_user" if msg == "user" else "history.by_tiktok")
            else:
                msg = ""
            if msg:
                ctk.CTkLabel(box, text=msg, font=font(12), anchor="w", wraplength=520, justify="left",
                             text_color=C("status_error" if r["status"] == "error" else "text_secondary")
                             ).pack(anchor="w")
            chip(card, t(f"history.event.{r['status']}"), colors.get(r["status"], "pending")).grid(
                row=0, column=3, padx=16)

        self._paged = PagedRows(scroll, rows, make_row, lambda n: t("common.show_more", n=n))
