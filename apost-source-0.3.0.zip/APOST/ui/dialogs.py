"""Діалогові вікна: підтвердження, інформація, редагування публікації."""
from __future__ import annotations

from datetime import datetime

import customtkinter as ctk

from core.schedule_planner import parse_date, parse_time
from core.video_manager import build_caption, normalize_hashtags

CAPTION_LIMIT = 2200  # ліміт довжини опису TikTok
from ui.widgets import C, font, label, primary_button, secondary_button


class BaseDialog(ctk.CTkToplevel):
    def __init__(self, parent, title: str, width: int, height: int) -> None:
        super().__init__(parent, fg_color=C("bg"))
        self.title(title)
        self.resizable(False, False)
        top = parent.winfo_toplevel()
        self.transient(top)
        x = top.winfo_rootx() + (top.winfo_width() - width) // 2
        y = top.winfo_rooty() + max((top.winfo_height() - height) // 3, 20)
        self.geometry(f"{width}x{height}+{max(x, 0)}+{max(y, 0)}")
        self.after(150, self._grab)

    def _grab(self) -> None:
        try:
            self.grab_set()
            self.focus_force()
        except Exception:
            pass


class ConfirmDialog(BaseDialog):
    """Підтвердження (або інформація, якщо cancel_text=None)."""

    def __init__(self, parent, title: str, text: str, ok_text: str,
                 cancel_text: str | None = None, danger: bool = False) -> None:
        lines = max(3, text.count("\n") + len(text) // 48 + 1)
        super().__init__(parent, title, 460, 150 + lines * 20)
        self.result = False
        label(self, title, 18, bold=True).pack(anchor="w", padx=28, pady=(26, 6))
        ctk.CTkLabel(self, text=text, font=font(13), text_color=C("text_secondary"),
                     wraplength=400, justify="left", anchor="w").pack(anchor="w", padx=28)
        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack(side="bottom", anchor="e", padx=28, pady=22)
        if cancel_text:
            secondary_button(row, cancel_text, self._cancel, width=120).pack(side="left", padx=(0, 8))
        btn = primary_button(row, ok_text, self._ok, width=140)
        if danger:
            btn.configure(fg_color=C("status_error"), hover_color=C("status_error"))
        btn.pack(side="left")
        self.protocol("WM_DELETE_WINDOW", self._cancel)

    def _ok(self) -> None:
        self.result = True
        self.destroy()

    def _cancel(self) -> None:
        self.result = False
        self.destroy()


def ask(parent, title: str, text: str, ok_text: str, cancel_text: str, danger: bool = False) -> bool:
    dlg = ConfirmDialog(parent, title, text, ok_text, cancel_text, danger)
    parent.wait_window(dlg)
    return dlg.result


def info(parent, title: str, text: str, ok_text: str) -> None:
    dlg = ConfirmDialog(parent, title, text, ok_text, None)
    parent.wait_window(dlg)


class EditDialog(BaseDialog):
    """Редагування опису/хештегів відео та (для публікації) дати й часу."""

    def __init__(self, parent, ctx, post_id: int | None = None, video_id: int | None = None,
                 on_saved=None) -> None:
        self.ctx, self.on_saved = ctx, on_saved
        t = ctx.t
        self.post = ctx.db.get_post(post_id) if post_id else None
        self.video = ctx.db.get_video(self.post["video_id"] if self.post else video_id)
        has_sched = self.post is not None
        super().__init__(parent, t("edit.title" if has_sched else "edit.title_video"),
                         520, 560 if has_sched else 410)

        label(self, self.video["original_name"], 16, bold=True).pack(anchor="w", padx=28, pady=(24, 12))
        label(self, t("edit.description"), 12, secondary=True).pack(anchor="w", padx=28)
        self.desc = ctk.CTkTextbox(self, height=90, corner_radius=14, border_width=1,
                                   border_color=C("border"), fg_color=C("bg_secondary"),
                                   text_color=C("text"), font=font(13))
        self.desc.pack(fill="x", padx=28, pady=(4, 10))
        self.desc.insert("1.0", self.video["description"])
        label(self, t("edit.hashtags"), 12, secondary=True).pack(anchor="w", padx=28)
        self.tags = self._entry()
        self.tags.insert(0, self.video["hashtags"])

        self.date_e = self.time_e = None
        if has_sched:
            locked = self.post["status"] in ("posting", "published")
            row = ctk.CTkFrame(self, fg_color="transparent")
            row.pack(fill="x", padx=28, pady=(10, 0))
            row.columnconfigure((0, 1), weight=1, uniform="dt")
            for i, key in enumerate(("edit.date", "edit.time")):
                cell = ctk.CTkFrame(row, fg_color="transparent")
                cell.grid(row=0, column=i, sticky="ew", padx=(0, 8) if i == 0 else (8, 0))
                label(cell, t(key), 12, secondary=True).pack(anchor="w")
                e = self._entry(cell, pady=(4, 0))
                if i == 0:
                    self.date_e = e
                else:
                    self.time_e = e
            cur = self._current_local()
            if cur:
                self.date_e.insert(0, cur.strftime("%Y-%m-%d"))
                self.time_e.insert(0, cur.strftime("%H:%M"))
            if locked:
                self.date_e.configure(state="disabled"); self.time_e.configure(state="disabled")
                label(self, t("edit.locked"), 12, secondary=True).pack(anchor="w", padx=28, pady=(6, 0))
            else:
                label(self, t("edit.hint_empty"), 12, secondary=True).pack(anchor="w", padx=28, pady=(8, 0))

        self.err = ctk.CTkLabel(self, text="", font=font(12, True), text_color=C("status_error"),
                                anchor="w", wraplength=460, justify="left")
        self.err.pack(anchor="w", padx=28, pady=(8, 0))

        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack(side="bottom", fill="x", padx=28, pady=22)
        if has_sched and self.post["status"] != "posting":
            secondary_button(row, t("edit.remove"), self._remove).pack(side="left")
        primary_button(row, t("common.save"), self.save, width=130).pack(side="right")
        secondary_button(row, t("common.cancel"), self.destroy, width=120).pack(side="right", padx=8)

    def _entry(self, master=None, pady=(4, 10)) -> ctk.CTkEntry:
        e = ctk.CTkEntry(master or self, height=42, corner_radius=14, border_color=C("border"),
                         fg_color=C("bg_secondary"), text_color=C("text"))
        e.pack(fill="x", padx=28 if master is None else 0, pady=pady)
        return e

    def _current_local(self) -> datetime | None:
        if self.post and self.post["scheduled_at"]:
            return self.ctx.to_local(self.post["scheduled_at"])
        return None

    def save(self) -> None:
        t, ctx = self.ctx.t, self.ctx
        new_when = None
        sched_change = False
        if self.date_e is not None and self.date_e.cget("state") == "normal":
            ds, ts = self.date_e.get().strip(), self.time_e.get().strip()
            if ds or ts:
                if not (ds and ts):
                    return self._error(t("edit.err.both"))
                d, tm = parse_date(ds), parse_time(ts)
                if d is None:
                    return self._error(t("edit.err.date"))
                if tm is None:
                    return self._error(t("edit.err.time"))
                new_when = datetime.combine(d, tm)
            cur = self._current_local()
            sched_change = (new_when != (cur.replace(second=0) if cur else None))
            if sched_change and new_when and new_when <= ctx.now_local():
                return self._error(t("edit.err.past"))

        desc = self.desc.get("1.0", "end").strip()
        tags = normalize_hashtags(self.tags.get())
        caption_len = len(build_caption(desc, tags))
        if caption_len > CAPTION_LIMIT:
            return self._error(t("edit.err.long", n=caption_len))
        ctx.db.update_video_text(self.video["id"], desc, tags)
        if sched_change:
            ctx.db.set_schedule(self.post["id"], ctx.to_utc(new_when) if new_when else None)
        self.destroy()
        if self.on_saved:
            self.on_saved()

    def _remove(self) -> None:
        self.ctx.db.remove_post(self.post["id"])
        self.destroy()
        if self.on_saved:
            self.on_saved()

    def _error(self, text: str) -> None:
        self.err.configure(text=text)
