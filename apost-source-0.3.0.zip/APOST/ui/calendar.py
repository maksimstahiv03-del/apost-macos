"""Календар публікацій у стилі iPhone: місяць (клітинки), тиждень і день (години).

Події беруться з БД (публікації з призначеною датою). Клік по події відкриває редагування.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta

import customtkinter as ctk

from core.models import CalendarEvent
from ui.base_page import BasePage
from ui.dialogs import EditDialog
from ui.widgets import C, font, label, secondary_button, segmented
from utils.logger import get_logger

log = get_logger("calendar")

HOUR_H = 64     # висота години в тижневому/денному вигляді (px)
GUTTER = 58     # ширина колонки з годинами
EVENT_H = 44    # висота блока події
WEEKDAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
EVENT_TEXT = ("#FFFFFF", "#111111")  # текст на кольорових плашках статусів


def _status_color(ev: CalendarEvent):
    """Колір плашки: пауза — сірий, «час публікувати» — бурштиновий, інакше за статусом."""
    if ev.status in ("scheduled", "pending") and ev.paused:
        return C("status_pending")
    if ev.manual_due:
        return C("status_posting")
    return C(f"status_{ev.status}")


class CalendarPage(BasePage):
    title_key = "calendar.title"
    subtitle_key = "calendar.subtitle"

    # ---------- побудова ----------
    def build(self) -> None:
        t = self.t
        self.view = "month"
        self.anchor = date.today()
        self.events: list[CalendarEvent] = []
        self._rev = -1

        self._view_names = {"month": t("calendar.view.month"),
                            "week": t("calendar.view.week"),
                            "day": t("calendar.view.day")}
        self.view_seg = segmented(self.header_actions, list(self._view_names.values()),
                                  command=self._on_view)
        self.view_seg.set(self._view_names[self.view])
        self.view_seg.pack(side="right")

        self.body.rowconfigure(2, weight=1)
        bar = ctk.CTkFrame(self.body, fg_color="transparent", height=0)
        bar.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        bar.columnconfigure(3, weight=1)
        nav_kw = dict(width=44, height=44, corner_radius=22, font=font(20, True),
                      fg_color=C("bg_secondary"), hover_color=C("hover"), text_color=C("text"))
        ctk.CTkButton(bar, text="‹", command=lambda: self._shift(-1), **nav_kw).grid(row=0, column=0)
        ctk.CTkButton(bar, text="›", command=lambda: self._shift(1), **nav_kw).grid(
            row=0, column=1, padx=(6, 10))
        secondary_button(bar, t("calendar.today"), self._go_today, width=110).grid(row=0, column=2)
        self.title_lbl = label(bar, "", 22, bold=True, anchor="e")
        self.title_lbl.grid(row=0, column=3, sticky="e")

        self.content = ctk.CTkFrame(self.body, fg_color="transparent")
        self.content.grid(row=2, column=0, sticky="nsew")
        self.content.columnconfigure(0, weight=1)
        self.content.rowconfigure(0, weight=1)
        self._render()

    # ---------- події інтерфейсу ----------
    def _on_view(self, value: str) -> None:
        self.view = next(k for k, v in self._view_names.items() if v == value)
        self._render()

    def _go_today(self) -> None:
        self.anchor = date.today()
        self._render()

    def _shift(self, direction: int) -> None:
        if self.view == "month":
            m = self.anchor.month - 1 + direction
            y, m = self.anchor.year + m // 12, m % 12 + 1
            self.anchor = self.anchor.replace(year=y, month=m, day=1)
        elif self.view == "week":
            self.anchor += timedelta(days=7 * direction)
        else:
            self.anchor += timedelta(days=direction)
        self._render()

    def _open_day(self, d: date) -> None:
        self.anchor = d
        self.view = "day"
        self.view_seg.set(self._view_names["day"])
        self._render()

    def refresh(self, force: bool = False) -> None:
        if not force and self._rev == self.ctx.db.revision:
            return
        self._render()

    def _edit(self, ev: CalendarEvent) -> None:
        EditDialog(self, self.ctx, post_id=ev.id)

    def _range(self) -> tuple[datetime, datetime]:
        a = self.anchor
        if self.view == "month":
            first = a.replace(day=1)
            start = first - timedelta(days=first.weekday())
            return datetime.combine(start, datetime.min.time()), datetime.combine(
                start + timedelta(days=42), datetime.min.time())
        if self.view == "week":
            start = a - timedelta(days=a.weekday())
            return datetime.combine(start, datetime.min.time()), datetime.combine(
                start + timedelta(days=7), datetime.min.time())
        return datetime.combine(a, datetime.min.time()), datetime.combine(
            a + timedelta(days=1), datetime.min.time())

    def _load_events(self) -> None:
        ctx = self.ctx
        lo, hi = self._range()
        # беремо з запасом ±1 день через різницю часових поясів, потім фільтруємо за локальним часом
        rows = ctx.db.posts_between(ctx.to_utc(lo - timedelta(days=1)), ctx.to_utc(hi + timedelta(days=1)))
        self.events = []
        for r in rows:
            start = ctx.to_local(r["scheduled_at"])
            if lo <= start < hi:
                self.events.append(CalendarEvent(r["id"], r["name"], start, r["status"],
                                                 r["video_id"], bool(r["paused"]), bool(r["manual_due"])))

    # ---------- рендер ----------
    def _events_on(self, d: date) -> list[CalendarEvent]:
        return sorted((e for e in self.events if e.start.date() == d), key=lambda e: e.start)

    def _title(self) -> str:
        t, a = self.t, self.anchor
        if self.view == "month":
            return f"{t(f'month.{a.month}').capitalize()} {a.year}"
        if self.view == "week":
            d1 = a - timedelta(days=a.weekday())
            d2 = d1 + timedelta(days=6)
            if d1.month == d2.month:
                return f"{d1.day}–{d2.day} {t(f'month_gen.{d2.month}')} {d2.year}"
            return (f"{d1.day} {t(f'month_short.{d1.month}')} – "
                    f"{d2.day} {t(f'month_short.{d2.month}')} {d2.year}")
        wd = t(f"weekday_full.{WEEKDAYS[a.weekday()]}")
        return f"{wd}, {a.day} {t(f'month_gen.{a.month}')} {a.year}"

    def _render(self) -> None:
        for w in self.content.winfo_children():
            w.destroy()
        self._rev = self.ctx.db.revision
        self.title_lbl.configure(text=self._title())
        try:
            self._load_events()
            if self.view == "month":
                self._render_month()
            else:
                if self.view == "week":
                    start = self.anchor - timedelta(days=self.anchor.weekday())
                    days = [start + timedelta(days=i) for i in range(7)]
                else:
                    days = [self.anchor]
                self._render_timeline(days)
        except Exception:
            log.exception("Помилка відображення календаря")

    # ----- місяць -----
    def _render_month(self) -> None:
        t, today = self.t, date.today()
        self.content.rowconfigure(0, weight=1)   # кожен вигляд сам задає ваги рядків
        self.content.rowconfigure(1, weight=0)
        grid = ctk.CTkFrame(self.content, fg_color="transparent")
        grid.grid(row=0, column=0, sticky="nsew")
        for c in range(7):
            grid.columnconfigure(c, weight=1, uniform="col")
        for r in range(1, 7):
            grid.rowconfigure(r, weight=1, uniform="row")

        for c, wd in enumerate(WEEKDAYS):
            label(grid, t(f"weekday.{wd}"), 13, bold=True, secondary=True,
                  anchor="center").grid(row=0, column=c, pady=(0, 6))

        first = self.anchor.replace(day=1)
        start = first - timedelta(days=first.weekday())
        for i in range(42):
            d = start + timedelta(days=i)
            r, c = divmod(i, 7)
            in_month = d.month == first.month
            cell = ctk.CTkFrame(
                grid, width=10, height=10, corner_radius=14, border_width=1,
                border_color=C("accent") if d == today else C("border"),
                fg_color=C("bg") if in_month else C("bg_secondary"))
            cell.grid(row=r + 1, column=c, sticky="nsew", padx=3, pady=3)
            cell.pack_propagate(False)

            top = ctk.CTkFrame(cell, fg_color="transparent", height=0)
            top.pack(fill="x", padx=8, pady=(4, 1))
            evs = self._events_on(d)
            if d == today:
                num = ctk.CTkLabel(top, text=str(d.day), width=22, height=22, corner_radius=11,
                                   fg_color=C("accent"), text_color=C("accent_text"),
                                   font=font(12, True))
            else:
                num = ctk.CTkLabel(top, text=str(d.day), font=font(13, in_month),
                                   text_color=C("text" if in_month else "disabled"))
            num.pack(side="left")
            if evs:   # кількість публікацій на день
                ctk.CTkLabel(top, text=str(len(evs)), width=22, height=18, corner_radius=9,
                             font=font(11, True), fg_color=C("bg_secondary" if in_month else "bg"),
                             text_color=C("text_secondary")).pack(side="right")
            for w in (cell, top, num):
                w.bind("<Button-1>", lambda _e, dd=d: self._open_day(dd))

            shown = evs if len(evs) <= 3 else evs[:2]
            for ev in shown:
                color = _status_color(ev)
                ctk.CTkButton(
                    cell, text=f"{ev.start:%H:%M}  {ev.title}", height=16, corner_radius=8,
                    font=font(10, True), anchor="w", border_spacing=1,
                    fg_color=color, hover_color=color, text_color=EVENT_TEXT,
                    command=lambda e=ev: self._edit(e),
                ).pack(fill="x", padx=6, pady=(0, 2))
            if len(evs) > len(shown):
                label(cell, t("calendar.more", n=len(evs) - len(shown)), 11,
                      secondary=True).pack(anchor="w", padx=10)

    # ----- тиждень / день -----
    def _render_timeline(self, days: list[date]) -> None:
        t, today, n = self.t, date.today(), len(days)
        wrap = self.content
        wrap.rowconfigure(0, weight=0)
        wrap.rowconfigure(1, weight=1)

        head = ctk.CTkFrame(wrap, fg_color="transparent", height=0)
        head.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        head.columnconfigure(0, minsize=GUTTER)
        for i, d in enumerate(days):
            head.columnconfigure(i + 1, weight=1, uniform="hd")
            col = ctk.CTkFrame(head, fg_color="transparent", height=0)
            col.grid(row=0, column=i + 1)
            label(col, t(f"weekday.{WEEKDAYS[d.weekday()]}"), 12, bold=True,
                  secondary=True, anchor="center").pack()
            if d == today:
                ctk.CTkLabel(col, text=str(d.day), width=30, height=30, corner_radius=15,
                             fg_color=C("accent"), text_color=C("accent_text"),
                             font=font(15, True)).pack(pady=2)
            else:
                label(col, str(d.day), 18, bold=True, anchor="center").pack(pady=2)
            cnt = len(self._events_on(d))
            if cnt:
                label(col, t("calendar.day_count", n=cnt), 11, secondary=True, anchor="center").pack()

        scroll = ctk.CTkScrollableFrame(wrap, fg_color=C("bg"), corner_radius=16,
                                        border_width=1, border_color=C("border"))
        scroll.grid(row=1, column=0, sticky="nsew")
        scroll.columnconfigure(1, weight=1)
        total = 24 * HOUR_H
        gutter = ctk.CTkFrame(scroll, width=GUTTER, height=total, fg_color="transparent")
        gutter.grid(row=0, column=0, sticky="n")
        area = ctk.CTkFrame(scroll, height=total, fg_color="transparent")
        area.grid(row=0, column=1, sticky="ew")

        for h in range(24):
            y = h * HOUR_H
            ctk.CTkFrame(area, height=2, corner_radius=0, fg_color=C("grid")).place(
                x=0, y=y, relwidth=1)
            if h:
                ctk.CTkLabel(gutter, text=f"{h:02d}:00", font=font(11),
                             text_color=C("text_secondary"), width=GUTTER - 10,
                             anchor="e").place(x=0, y=y - 9)
        for i in range(1, n):
            ctk.CTkFrame(area, width=2, corner_radius=0, fg_color=C("grid")).place(
                relx=i / n, y=0, relheight=1)

        first_hour = None
        for i, d in enumerate(days):
            evs = self._events_on(d)
            lanes, lane_end = [], []          # розкладання перекритих подій по смугах
            for ev in evs:
                y = (ev.start.hour * 60 + ev.start.minute) / 60 * HOUR_H
                for li, end in enumerate(lane_end):
                    if y >= end:
                        lane_end[li] = y + EVENT_H
                        lanes.append(li)
                        break
                else:
                    lane_end.append(y + EVENT_H)
                    lanes.append(len(lane_end) - 1)
            total_lanes = max(len(lane_end), 1)
            for ev, lane in zip(evs, lanes):
                y = (ev.start.hour * 60 + ev.start.minute) / 60 * HOUR_H
                first_hour = ev.start.hour if first_hour is None else min(first_hour, ev.start.hour)
                color = _status_color(ev)
                slot = ctk.CTkFrame(area, width=10, height=EVENT_H, fg_color="transparent")
                slot.place(relx=(i + lane / total_lanes) / n, y=y, relwidth=1 / (n * total_lanes))
                slot.pack_propagate(False)
                ctk.CTkButton(
                    slot, text=f"{ev.start:%H:%M}\n{ev.title}", height=EVENT_H - 4,
                    corner_radius=12, font=font(11, True), anchor="w", border_spacing=4,
                    fg_color=color, hover_color=color, text_color=EVENT_TEXT,
                    command=lambda e=ev: self._edit(e),
                ).pack(fill="both", expand=True, padx=3, pady=2)
            if d == today:  # червона лінія поточного часу
                now = datetime.now()
                ny = (now.hour * 60 + now.minute) / 60 * HOUR_H
                ctk.CTkFrame(area, height=2, corner_radius=0, fg_color=C("status_error")).place(
                    relx=i / n, y=ny, relwidth=1 / n)

        target = first_hour if first_hour is not None else (
            datetime.now().hour if today in days else 8)
        frac = max(0, (target - 1) * HOUR_H) / total
        self.after(80, lambda: self._scroll_to(scroll, frac))

    @staticmethod
    def _scroll_to(scroll: ctk.CTkScrollableFrame, frac: float) -> None:
        try:
            scroll._parent_canvas.yview_moveto(frac)
        except Exception:
            pass
