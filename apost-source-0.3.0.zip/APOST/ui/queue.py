"""Черга публікацій: порядок, дата/час, пауза, видалення, ручна публікація."""
from __future__ import annotations

import os

import customtkinter as ctk

from core import planning_service
from core.video_manager import build_caption
from publisher.tiktok_publisher import open_upload_page, reveal_file
from ui.base_page import BasePage
from ui.dialogs import EditDialog, ask, info
from ui.widgets import (C, Card, EmptyState, chip, font, fmt_dt, icon_button, label,
                        PagedRows, secondary_button, small_button, thumb_image)


class QueuePage(BasePage):
    title_key = "queue.title"
    subtitle_key = "queue.subtitle"

    def build(self) -> None:
        self._rev = -1
        self.count_lbl = label(self.header_actions, "", 14, secondary=True)
        self.count_lbl.pack(side="left", padx=(0, 12))
        self.resched_btn = secondary_button(self.header_actions, self.t("queue.reschedule_missed"),
                                            self._reschedule_missed)
        self.body.rowconfigure(0, weight=1)
        self.holder = ctk.CTkFrame(self.body, fg_color="transparent")
        self.holder.grid(row=0, column=0, sticky="nsew")
        self.holder.columnconfigure(0, weight=1)
        self.holder.rowconfigure(0, weight=1)
        self.refresh(force=True)

    # ---------- дії ----------
    def _move(self, pid: int, direction: int) -> None:
        self.ctx.db.move_post(pid, direction)

    def _toggle_pause(self, p) -> None:
        self.ctx.db.set_paused(p["id"], not p["paused"])

    def _remove(self, p) -> None:
        if ask(self, self.t("queue.remove.title"), self.t("queue.remove.text", name=p["name"]),
               self.t("common.delete"), self.t("common.cancel"), danger=True):
            self.ctx.db.remove_post(p["id"])

    def _prepare(self, p) -> None:
        """Ручний режим: копіюємо опис у буфер, показуємо файл і відкриваємо сторінку TikTok."""
        self.clipboard_clear()
        self.clipboard_append(build_caption(p["description"], p["hashtags"]))
        self.update()
        reveal_file(p["path"])
        open_upload_page()
        info(self, self.t("queue.prepare.title"), self.t("queue.prepare.text"), self.t("common.ok"))

    def _confirm(self, p) -> None:
        if ask(self, self.t("queue.confirm.title"), self.t("queue.confirm.text"),
               self.t("queue.confirm"), self.t("common.cancel")):
            self.ctx.db.mark_published(p["id"], p["name"], "user")

    def _reschedule(self, ids: list[int]) -> None:
        done, left = planning_service.reschedule(self.ctx, ids)
        if left:
            info(self, self.t("queue.reschedule"), self.t("queue.reschedule.none"), self.t("common.ok"))

    def _reschedule_missed(self) -> None:
        ids = [p["id"] for p in self.ctx.db.queue_posts() if p["status"] == "error"]
        self._reschedule(ids)

    # ---------- відображення ----------
    def refresh(self, force: bool = False) -> None:
        if not force and self._rev == self.ctx.db.revision:
            return
        self._rev = self.ctx.db.revision
        shown = getattr(self, "_paged", None).n if getattr(self, "_paged", None) else 0
        for w in self.holder.winfo_children():
            w.destroy()
        rows = self.ctx.db.queue_posts()
        self.count_lbl.configure(text=self.t("queue.count", n=len(rows)))
        if any(r["status"] == "error" for r in rows):
            self.resched_btn.pack(side="left")
        else:
            self.resched_btn.pack_forget()
        if not rows:
            EmptyState(self.holder, "queue", self.t("queue.empty.title"),
                       self.t("queue.empty.text")).grid(row=0, column=0, sticky="nsew")
            return
        scroll = ctk.CTkScrollableFrame(self.holder, fg_color="transparent", corner_radius=0)
        scroll.grid(row=0, column=0, sticky="nsew")
        scroll.columnconfigure(0, weight=1)
        total = len(rows)
        self._paged = PagedRows(
            scroll, rows, lambda par, i, p: self._row(par, i, p, first=i == 0, last=i == total - 1),
            lambda n: self.t("common.show_more", n=n), shown=shown)

    def _status_chip(self, parent, p):
        t = self.t
        if p["status"] == "error":
            return chip(parent, t("status.error"), "error")
        if p["manual_due"]:
            return chip(parent, t("queue.manual_due"), "posting")
        if p["paused"]:
            return chip(parent, t("queue.paused"), "pending")
        return chip(parent, t(f"status.{p['status']}"), p["status"])

    def _row(self, parent, i: int, p, first: bool, last: bool) -> None:
        t = self.t
        card = Card(parent)
        card.grid(row=i, column=0, sticky="ew", pady=5)
        card.columnconfigure(2, weight=1)

        order = ctk.CTkFrame(card, fg_color="transparent")
        order.grid(row=0, column=0, padx=(8, 0))
        icon_button(order, "up", lambda pid=p["id"]: self._move(pid, -1), size=28,
                    state="disabled" if first else "normal").pack()
        icon_button(order, "down", lambda pid=p["id"]: self._move(pid, 1), size=28,
                    state="disabled" if last else "normal").pack()
        ctk.CTkLabel(card, text="", image=thumb_image(p["thumb_path"])).grid(
            row=0, column=1, padx=10, pady=12)

        box = ctk.CTkFrame(card, fg_color="transparent")
        box.grid(row=0, column=2, sticky="ew", pady=10)
        label(box, p["name"], 15, bold=True).pack(anchor="w")
        when = fmt_dt(self.ctx.to_local(p["scheduled_at"])) if p["scheduled_at"] else t("queue.when")
        label(box, when, 13, secondary=True).pack(anchor="w")
        if p["description"]:
            label(box, p["description"].replace("\n", " ")[:80], 12).pack(anchor="w", pady=(3, 0))
        if p["hashtags"]:
            ctk.CTkLabel(box, text=p["hashtags"][:80], font=font(12), anchor="w",
                         text_color=C("accent")).pack(anchor="w")
        if p["status"] == "error" and p["error"]:
            code = p["error"]
            text = t(f"error.{code}") if f"error.{code}" in self.ctx.lang._tables["en"] else code
            ctk.CTkLabel(box, text=text, font=font(12), anchor="w", wraplength=520, justify="left",
                         text_color=C("status_error")).pack(anchor="w", pady=(3, 0))

        if p["status"] in ("pending", "scheduled") and not os.path.exists(p["path"]):
            ctk.CTkLabel(box, text=t("queue.file_missing"), font=font(12), anchor="w", wraplength=520,
                         justify="left", text_color=C("status_error")).pack(anchor="w", pady=(3, 0))
        if p["manual_due"] and p["publish_id"]:
            ctk.CTkLabel(box, text=t("queue.inbox_hint"), font=font(12, True), anchor="w", wraplength=520,
                         justify="left", text_color=C("accent")).pack(anchor="w", pady=(3, 0))
        self._status_chip(card, p).grid(row=0, column=3, padx=8)

        btns = ctk.CTkFrame(card, fg_color="transparent")
        btns.grid(row=0, column=4, padx=(4, 12))
        if p["manual_due"]:
            if not p["publish_id"]:
                small_button(btns, t("queue.prepare"), lambda x=p: self._prepare(x),
                             icon="upload").pack(side="left", padx=2)
            small_button(btns, t("queue.confirm"), lambda x=p: self._confirm(x),
                         icon="check").pack(side="left", padx=2)
        elif p["status"] == "error":
            small_button(btns, t("queue.reschedule"), lambda pid=p["id"]: self._reschedule([pid]),
                         icon="refresh").pack(side="left", padx=2)
        if p["status"] in ("pending", "scheduled") and not p["manual_due"]:
            icon_button(btns, "play" if p["paused"] else "pause",
                        lambda x=p: self._toggle_pause(x)).pack(side="left")
        icon_button(btns, "pencil", lambda pid=p["id"]: EditDialog(self, self.ctx, post_id=pid)).pack(
            side="left")
        icon_button(btns, "trash", lambda x=p: self._remove(x), tone="danger").pack(side="left")
