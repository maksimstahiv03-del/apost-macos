"""Векторні лінійні іконки APOST, намальовані через Pillow (суперсемплінг).

Іконки створюються у світлому й темному варіантах, тому змінюються разом із темою.
"""
from __future__ import annotations

import math
import tkinter

import customtkinter as ctk
from PIL import Image, ImageDraw

U = 24          # логічна сітка іконки
S = 16          # коефіцієнт суперсемплінгу
STROKE = 1.9    # товщина лінії (в логічних одиницях)

# (світла, темна) — для неактивного і активного стану
COLORS = {
    "muted":  ("#666666", "#AAAAAA"),
    "active": ("#FFFFFF", "#FFFFFF"),
    "accent": ("#2563EB", "#A78BFA"),
    "danger": ("#DC2626", "#F87171"),
    "ok":     ("#16A34A", "#4ADE80"),
}


def _pt(p):
    return (p[0] * S, p[1] * S)


def _dot(d, p, r, color):
    x, y = _pt(p)
    d.ellipse((x - r * S, y - r * S, x + r * S, y + r * S), fill=color)


def _stroke(d, pts, color, closed=False, w=STROKE):
    pts = list(pts) + ([pts[0]] if closed else [])
    P = [_pt(p) for p in pts]
    d.line(P, fill=color, width=int(w * S), joint="curve")
    for p in pts:                      # заокруглені кінці та кути
        _dot(d, p, w / 2, color)


def _circle(d, c, r, color, w=STROKE):
    d.ellipse(((c[0] - r) * S, (c[1] - r) * S, (c[0] + r) * S, (c[1] + r) * S),
              outline=color, width=int(w * S))


def _rrect(d, box, radius, color, w=STROKE):
    d.rounded_rectangle(tuple(v * S for v in box), radius=radius * S,
                        outline=color, width=int(w * S))


def _arc(d, c, r, start, end, color, w=STROKE):
    d.arc(((c[0] - r) * S, (c[1] - r) * S, (c[0] + r) * S, (c[1] + r) * S),
          start, end, fill=color, width=int(w * S))
    for a in (start, end):
        rad = math.radians(a)
        _dot(d, (c[0] + r * math.cos(rad), c[1] + r * math.sin(rad)), w / 2, color)


# ---------- іконки ----------
def _home(d, c):
    _stroke(d, [(3, 11.5), (12, 4), (21, 11.5)], c)
    _stroke(d, [(5.5, 10), (5.5, 20), (18.5, 20), (18.5, 10)], c)
    _stroke(d, [(10, 20), (10, 14.5), (14, 14.5), (14, 20)], c)


def _library(d, c):
    _rrect(d, (3, 5, 21, 19), 4.5, c)
    _stroke(d, [(10.5, 9), (10.5, 15), (15.5, 12)], c, closed=True)


def _queue(d, c):
    for y in (7, 12, 17):
        _stroke(d, [(9.5, y), (20, y)], c)
        _dot(d, (4.8, y), 1.3, c)


def _calendar(d, c):
    _rrect(d, (3, 5, 21, 21), 4.5, c)
    _stroke(d, [(3.5, 10), (20.5, 10)], c)
    _stroke(d, [(8, 3), (8, 6.5)], c)
    _stroke(d, [(16, 3), (16, 6.5)], c)
    for x in (8, 12, 16):
        _dot(d, (x, 14.5), 1.0, c)
    for x in (8, 12):
        _dot(d, (x, 18), 1.0, c)


def _scheduler(d, c):
    _circle(d, (12, 12), 9, c)
    _stroke(d, [(12, 7), (12, 12), (15.5, 14)], c)


def _history(d, c):
    _arc(d, (12, 12), 9, 270, 540, c)             # велика дуга: верх → низ → ліво
    _arc(d, (12, 12), 9, 225, 270, c)             # коротка дуга до стрілки
    _stroke(d, [(5.6, 5.6), (3, 8.2)], c)
    _stroke(d, [(3, 3), (3, 8.2), (8.2, 8.2)], c)  # кутик стрілки
    _stroke(d, [(12, 7.5), (12, 12), (15.2, 14)], c)


def _settings(d, c):
    pts = []
    for i in range(8):
        a = i * 45
        for da, r in ((-17, 7.4), (-10, 9.9), (10, 9.9), (17, 7.4)):
            rad = math.radians(a + da)
            pts.append((12 + r * math.cos(rad), 12 + r * math.sin(rad)))
    _stroke(d, pts, c, closed=True, w=1.7)
    _circle(d, (12, 12), 3.2, c, w=1.7)


def _plus(d, c):
    _stroke(d, [(12, 5), (12, 19)], c, w=2.2); _stroke(d, [(5, 12), (19, 12)], c, w=2.2)


def _pencil(d, c):
    _stroke(d, [(4, 20), (4.8, 15.4), (16, 4.2), (19.8, 8), (8.6, 19.2)], c, closed=True)
    _stroke(d, [(13.5, 6.8), (17.2, 10.5)], c)


def _trash(d, c):
    _stroke(d, [(4, 7), (20, 7)], c)
    _stroke(d, [(9, 7), (9, 4.5), (15, 4.5), (15, 7)], c)
    _stroke(d, [(6, 7), (7, 19.5), (17, 19.5), (18, 7)], c)
    _stroke(d, [(10.2, 11), (10.2, 16)], c); _stroke(d, [(13.8, 11), (13.8, 16)], c)


def _up(d, c):
    _stroke(d, [(6, 14.5), (12, 8.5), (18, 14.5)], c, w=2.2)


def _down(d, c):
    _stroke(d, [(6, 9.5), (12, 15.5), (18, 9.5)], c, w=2.2)


def _pause(d, c):
    _stroke(d, [(9, 6), (9, 18)], c, w=2.8); _stroke(d, [(15, 6), (15, 18)], c, w=2.8)


def _play(d, c):
    d.polygon([_pt(p) for p in [(8, 5.5), (8, 18.5), (19, 12)]], fill=c)
    _stroke(d, [(8, 5.5), (8, 18.5), (19, 12)], c, closed=True, w=1.6)


def _check(d, c):
    _stroke(d, [(5, 12.5), (10, 17.5), (19, 7)], c, w=2.4)


def _upload(d, c):
    _stroke(d, [(12, 15), (12, 4.5)], c)
    _stroke(d, [(7.5, 9), (12, 4.5), (16.5, 9)], c)
    _stroke(d, [(4.5, 14.5), (4.5, 19.5), (19.5, 19.5), (19.5, 14.5)], c)


def _refresh(d, c):
    _arc(d, (12, 12), 8, 20, 300, c)
    _stroke(d, [(17.2, 3.8), (17.2, 8.2), (12.8, 8.2)], c)


def _eye(d, c):
    _stroke(d, [(2.5, 12), (6, 7.5), (12, 5.5), (18, 7.5), (21.5, 12),
                (18, 16.5), (12, 18.5), (6, 16.5)], c, closed=True)
    _circle(d, (12, 12), 3, c)


DRAWERS = {
    "dashboard": _home, "library": _library, "queue": _queue, "calendar": _calendar,
    "scheduler": _scheduler, "history": _history, "settings": _settings,
    "plus": _plus, "pencil": _pencil, "trash": _trash, "up": _up, "down": _down,
    "pause": _pause, "play": _play, "check": _check, "upload": _upload,
    "refresh": _refresh, "eye": _eye,
}

_cache: dict[tuple, ctk.CTkImage] = {}


def _render(name: str, color: str, px: int) -> Image.Image:
    img = Image.new("RGBA", (U * S, U * S), (0, 0, 0, 0))
    DRAWERS[name](ImageDraw.Draw(img), color)
    return img.resize((px, px), Image.LANCZOS)


def get_icon(name: str, size: int = 22, active: bool = False, tone: str | None = None) -> ctk.CTkImage:
    """CTkImage із варіантами для світлої та темної теми."""
    tone = tone or ("active" if active else "muted")
    key = (name, size, tone, id(tkinter._default_root))  # кеш прив'язаний до вікна
    if key not in _cache:
        light, dark = COLORS[tone]
        px = size * 3  # запас для Retina
        _cache[key] = ctk.CTkImage(
            light_image=_render(name, light, px),
            dark_image=_render(name, dark, px),
            size=(size, size),
        )
    return _cache[key]
