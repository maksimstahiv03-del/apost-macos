"""Налаштування логування APOST (файл з ротацією + консоль)."""
from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler

from core import config

_configured = False


def setup_logging(level: int = logging.INFO) -> logging.Logger:
    """Ініціалізує логер 'apost' один раз і повертає його."""
    global _configured
    logger = logging.getLogger("apost")
    if _configured:
        return logger

    config.ensure_dirs()
    logger.setLevel(level)
    fmt = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")

    try:
        fh = RotatingFileHandler(
            config.LOG_FILE, maxBytes=1_000_000, backupCount=3, encoding="utf-8"
        )
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    except OSError as exc:  # диск read-only тощо — не валимо програму
        print(f"[APOST] Не вдалося відкрити лог-файл: {exc}")

    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    logger.addHandler(sh)
    _configured = True
    return logger


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"apost.{name}")
