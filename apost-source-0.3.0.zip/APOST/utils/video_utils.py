"""Робота з відео через FFmpeg: перевірка, тривалість, мініатюри, відбиток файлу."""
from __future__ import annotations

import hashlib
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from utils.logger import get_logger

log = get_logger("video")

_ffmpeg_cache: str | None | bool = False  # False = ще не шукали


def find_ffmpeg() -> str | None:
    """Системний ffmpeg або вбудований у пакет imageio-ffmpeg."""
    global _ffmpeg_cache
    if _ffmpeg_cache is not False:
        return _ffmpeg_cache  # type: ignore[return-value]
    exe = shutil.which("ffmpeg")
    if not exe:
        try:
            import imageio_ffmpeg
            exe = imageio_ffmpeg.get_ffmpeg_exe()
        except Exception:
            exe = None
    if exe and not os.path.exists(exe):
        exe = None
    _ffmpeg_cache = exe
    return exe


@dataclass
class VideoInfo:
    ok: bool
    duration: float | None = None
    width: int | None = None
    height: int | None = None


_DUR = re.compile(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)")
_RES = re.compile(r"Video:.*?,\s*(\d{2,5})x(\d{2,5})")


def _run(args: list[str], timeout: int = 60) -> subprocess.CompletedProcess:
    kwargs = {}
    if sys.platform == "win32":
        kwargs["creationflags"] = 0x08000000
    return subprocess.run(args, capture_output=True, text=True, timeout=timeout,
                          errors="replace", **kwargs)


def probe(path: str | Path) -> VideoInfo:
    ff = find_ffmpeg()
    if not ff:
        return VideoInfo(ok=True)  # без ffmpeg не можемо перевірити — не блокуємо
    try:
        res = _run([ff, "-hide_banner", "-i", str(path)])
    except (subprocess.TimeoutExpired, OSError):
        log.exception("ffmpeg probe не вдався для %s", path)
        return VideoInfo(ok=False)
    text = res.stderr or ""
    m = _DUR.search(text)
    if not m or "Video:" not in text:
        log.warning("ffmpeg не зміг прочитати %s: %s", path, " | ".join(text.strip().splitlines()[-3:]))
        return VideoInfo(ok=False)
    dur = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
    r = _RES.search(text)
    return VideoInfo(True, dur, int(r.group(1)) if r else None, int(r.group(2)) if r else None)


def make_thumbnail(path: str | Path, out: str | Path, duration: float | None = None,
                   width: int = 360) -> bool:
    ff = find_ffmpeg()
    if not ff:
        return False
    ts = 1.0 if (duration or 0) > 2 else 0.0
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    try:
        _run([ff, "-hide_banner", "-loglevel", "error", "-y", "-ss", str(ts), "-i", str(path),
              "-frames:v", "1", "-vf", f"scale={width}:-2", "-q:v", "4", str(out)])
    except (subprocess.TimeoutExpired, OSError):
        log.exception("Не вдалося створити мініатюру %s", path)
        return False
    return Path(out).exists() and Path(out).stat().st_size > 0


def fingerprint(path: str | Path, chunk: int = 1024 * 1024) -> str:
    """Швидкий відбиток: розмір + перший і останній мегабайт (для виявлення дублікатів)."""
    p = Path(path)
    size = p.stat().st_size
    h = hashlib.sha1(str(size).encode())
    with open(p, "rb") as fh:
        h.update(fh.read(chunk))
        if size > chunk * 2:
            fh.seek(-chunk, os.SEEK_END)
            h.update(fh.read(chunk))
    return h.hexdigest()


def format_duration(sec: float | None) -> str:
    if sec is None:
        return "—"
    s = int(round(sec))
    return f"{s // 60}:{s % 60:02d}"


def format_size(n: int) -> str:
    for unit in ("Б", "КБ", "МБ", "ГБ"):
        if n < 1024 or unit == "ГБ":
            return f"{n:.0f} {unit}" if unit == "Б" else f"{n:.1f} {unit}"
        n /= 1024
    return ""
