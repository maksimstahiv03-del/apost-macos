"""Допоміжні функції для роботи з файлами."""
from __future__ import annotations

import json
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any


def atomic_write_json(path: Path, data: Any) -> None:
    """Безпечний запис JSON: у тимчасовий файл, потім атомарна заміна."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(dir=path.parent, prefix=path.name, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp_name, path)
    except Exception:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise


def free_space_mb(path: Path) -> int:
    """Вільне місце на диску (МБ) для вказаного шляху."""
    target = path if path.exists() else path.parent
    return shutil.disk_usage(target).free // (1024 * 1024)
