"""Глобальна конфігурація: назва, версія, шляхи (Application Support на macOS)."""
from __future__ import annotations

import os
import sys
from pathlib import Path

APP_NAME = "APOST"
APP_VERSION = "0.3.0"

DEFAULT_THEME = "light"
DEFAULT_LANGUAGE = "uk"
DEFAULT_TIMEZONE = "Europe/Kyiv"


def _data_dir() -> Path:
    """Папка даних. Можна перевизначити змінною середовища APOST_HOME (для тестів)."""
    override = os.environ.get("APOST_HOME")
    if override:
        return Path(override).expanduser()
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / APP_NAME
    return Path.home() / f".{APP_NAME.lower()}"  # dev-режим на інших ОС


def resource_path(relative: str) -> Path:
    """Шлях до ресурсів (працює і з PyInstaller, і з вихідного коду)."""
    base = getattr(sys, "_MEIPASS", None)
    root = Path(base) if base else Path(__file__).resolve().parent.parent
    return root / relative


DATA_DIR = _data_dir()
VIDEOS_DIR = DATA_DIR / "videos"
THUMBS_DIR = DATA_DIR / "thumbnails"
LOGS_DIR = DATA_DIR / "logs"
SETTINGS_FILE = DATA_DIR / "settings.json"
DB_FILE = DATA_DIR / "apost.db"  # використовується з Етапу 2
LOG_FILE = LOGS_DIR / "apost.log"
LOCALIZATION_DIR = resource_path("localization")


def ensure_dirs() -> None:
    for d in (DATA_DIR, VIDEOS_DIR, THUMBS_DIR, LOGS_DIR):
        d.mkdir(parents=True, exist_ok=True)
