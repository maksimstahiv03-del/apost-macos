"""Локальне сховище налаштувань (JSON у Application Support)."""
from __future__ import annotations

import json
import shutil
import time
from pathlib import Path
from typing import Any

from core import config
from utils.file_utils import atomic_write_json
from utils.logger import get_logger

log = get_logger("settings")

DEFAULTS: dict[str, Any] = {
    "theme": config.DEFAULT_THEME,          # "light" | "dark"
    "language": config.DEFAULT_LANGUAGE,    # "uk" | "en"
    "timezone": config.DEFAULT_TIMEZONE,
    "notify_enabled": True,
    "notify_scheduled": True,
    "notify_errors": True,
    "copy_videos": False,           # копіювати відео в папку програми (за замовчуванням — ні)
    "scheduler_paused": False,
    "tiktok_client_key": "",        # не секретний; client_secret і токени — лише в Keychain
    "tiktok_port": 8765,
    "tiktok_mode": "manual",        # manual | inbox | direct
    "tiktok_privacy": "SELF_ONLY",
    "tiktok_account": "",           # відображуване ім'я підключеного акаунта
    "schedule": {                   # останні параметри планувальника
        "per_day": 3, "first": "12:00", "last": "20:00",
        "start": "", "end": "", "weekdays": [0, 1, 2, 3, 4, 5, 6],
    },
}

VALID = {
    "tiktok_mode": {"manual", "inbox", "direct"},
    "theme": {"light", "dark"},
    "language": {"uk", "en"},
}


class SettingsStore:
    def __init__(self, path: Path | None = None) -> None:
        self.path = path or config.SETTINGS_FILE
        self._data: dict[str, Any] = dict(DEFAULTS)
        self._load()

    def _load(self) -> None:
        if not self.path.exists():
            return
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                raise ValueError("settings root is not an object")
        except (OSError, ValueError) as exc:
            backup = self.path.with_suffix(f".corrupt-{int(time.time())}.json")
            log.error("Файл налаштувань пошкоджено (%s). Копія: %s", exc, backup)
            try:
                shutil.copy2(self.path, backup)
            except OSError:
                pass
            return
        for key, value in raw.items():
            if key in VALID and value not in VALID[key]:
                log.warning("Некоректне значення %s=%r — використано стандартне", key, value)
                continue
            self._data[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, DEFAULTS.get(key, default))

    def set(self, key: str, value: Any) -> None:
        if key in VALID and value not in VALID[key]:
            raise ValueError(f"Недопустиме значення {value!r} для {key}")
        self._data[key] = value
        self.save()

    def save(self) -> None:
        try:
            atomic_write_json(self.path, self._data)
        except OSError:
            log.exception("Не вдалося зберегти налаштування")
