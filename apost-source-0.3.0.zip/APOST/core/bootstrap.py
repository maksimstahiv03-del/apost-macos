"""Збирає всі компоненти застосунку в AppContext."""
from __future__ import annotations

from core import config
from core.context import AppContext
from core.database import Database
from core.language_manager import LanguageManager
from core.notification_manager import NotificationManager
from core.scheduler_engine import SchedulerEngine
from core.settings_store import SettingsStore
from core.theme_manager import ThemeManager
from core.video_manager import VideoManager
from publisher.tiktok_api import TikTokClient
from publisher.tiktok_auth import TikTokAuth
from publisher.tiktok_publisher import ManualPublisher, RoutingPublisher, TikTokPublisher


def build_context() -> AppContext:
    config.ensure_dirs()
    settings = SettingsStore()
    theme = ThemeManager(settings)
    theme.apply(save=False)             # тема застосовується ДО створення вікна
    lang = LanguageManager(settings)
    db = Database(config.DB_FILE)
    notifier = NotificationManager(settings, lang)
    client = TikTokClient()
    auth = TikTokAuth(settings, client=client)
    publisher = RoutingPublisher(ManualPublisher(), TikTokPublisher(auth, client, settings),
                                 auth, settings)
    engine = SchedulerEngine(db, settings, publisher, notifier)
    videos = VideoManager(db, settings)
    return AppContext(settings=settings, theme=theme, lang=lang, db=db, videos=videos,
                      engine=engine, notifier=notifier, publisher=publisher, tiktok=auth)
