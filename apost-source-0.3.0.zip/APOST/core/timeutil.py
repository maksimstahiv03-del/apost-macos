"""Робота з часом: у БД усе зберігається в UTC, у інтерфейсі — у вибраному часовому поясі."""
from __future__ import annotations

from datetime import datetime, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

DB_FMT = "%Y-%m-%d %H:%M:%S"


def get_tz(name: str) -> ZoneInfo:
    try:
        return ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError, OSError):
        return ZoneInfo("UTC")


def utcnow_str() -> str:
    return datetime.now(timezone.utc).strftime(DB_FMT)


def now_local(tzname: str) -> datetime:
    """Поточний локальний час (naive) у вказаному поясі."""
    return datetime.now(timezone.utc).astimezone(get_tz(tzname)).replace(tzinfo=None)


def local_to_utc_str(local: datetime, tzname: str) -> str:
    aware = local.replace(tzinfo=get_tz(tzname))
    return aware.astimezone(timezone.utc).strftime(DB_FMT)


def utc_str_to_local(s: str, tzname: str) -> datetime:
    dt = datetime.strptime(s, DB_FMT).replace(tzinfo=timezone.utc)
    return dt.astimezone(get_tz(tzname)).replace(tzinfo=None)
