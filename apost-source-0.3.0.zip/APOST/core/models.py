"""Прості моделі даних (використовуються UI; на етапі 2–3 заповнюватимуться з БД)."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

STATUSES = ("pending", "scheduled", "posting", "published", "error")


@dataclass(frozen=True)
class CalendarEvent:
    id: int
    title: str
    start: datetime
    status: str  # один зі STATUSES
    video_id: int = 0
    paused: bool = False
    manual_due: bool = False
