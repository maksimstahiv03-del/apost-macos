"""Прикладна логіка планування: збереження графіка, розподіл черги, перепланування."""
from __future__ import annotations

from datetime import time

from core.schedule_planner import ScheduleConfig, generate_slots, parse_date, parse_time

DEFAULT_SAVED = {"per_day": 3, "first": "12:00", "last": "20:00", "start": "", "end": "",
                 "weekdays": [0, 1, 2, 3, 4, 5, 6]}


def load_config(settings) -> ScheduleConfig:
    d = {**DEFAULT_SAVED, **(settings.get("schedule") or {})}
    return ScheduleConfig(
        per_day=int(d["per_day"]), first=parse_time(d["first"]) or time(12),
        last=parse_time(d["last"]) or time(20), start=parse_date(d["start"]),
        end=parse_date(d["end"]), weekdays=set(d["weekdays"]) or set(range(7)))


def save_config(settings, cfg: ScheduleConfig) -> None:
    settings.set("schedule", {
        "per_day": cfg.per_day, "first": cfg.first.strftime("%H:%M"),
        "last": cfg.last.strftime("%H:%M"),
        "start": cfg.start.isoformat() if cfg.start else "",
        "end": cfg.end.isoformat() if cfg.end else "",
        "weekdays": sorted(cfg.weekdays)})


def taken_slots(ctx) -> set:
    return {ctx.to_local(s).replace(second=0) for s in ctx.db.scheduled_times()}


def preview(ctx, cfg: ScheduleConfig):
    """(публікації без дати, слоти) — без змін у БД."""
    pending = list(ctx.db.pending_posts())
    slots = generate_slots(cfg, len(pending), ctx.now_local(), taken_slots(ctx))
    return pending, slots


def distribute(ctx, cfg: ScheduleConfig | None = None, post_ids: list[int] | None = None):
    """Призначає найближчі вільні слоти публікаціям без дати (у порядку черги).

    Повертає (скільки заплановано, скільки лишилось без дати).
    """
    cfg = cfg or load_config(ctx.settings)
    pending = [p for p in ctx.db.pending_posts() if post_ids is None or p["id"] in post_ids]
    slots = generate_slots(cfg, len(pending), ctx.now_local(), taken_slots(ctx))
    for post, slot in zip(pending, slots):
        ctx.db.set_schedule(post["id"], ctx.to_utc(slot))
    return len(slots), len(pending) - len(slots)


def redistribute_all(ctx, cfg: ScheduleConfig | None = None):
    """Знімає час з усіх запланованих (крім ручних/опублікованих) і розподіляє заново."""
    for p in ctx.db.queue_posts():
        if p["status"] == "scheduled" and not p["manual_due"]:
            ctx.db.set_schedule(p["id"], None)
    return distribute(ctx, cfg)


def reschedule(ctx, post_ids: list[int]):
    """Пропущені/помилкові/ручні публікації → знову в чергу на найближчі вільні слоти."""
    for pid in post_ids:
        ctx.db.set_schedule(pid, None)
    return distribute(ctx, None, post_ids)
