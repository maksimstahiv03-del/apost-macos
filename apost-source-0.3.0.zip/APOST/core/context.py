"""Спільний контекст застосунку, який передається сторінкам."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable

from core import timeutil
from core.language_manager import LanguageManager
from core.settings_store import SettingsStore
from core.theme_manager import ThemeManager


@dataclass
class AppContext:
    settings: SettingsStore
    theme: ThemeManager
    lang: LanguageManager
    navigate: Callable[[str], None] = field(default=lambda key: None)
    db: Any = None
    videos: Any = None
    engine: Any = None
    notifier: Any = None
    publisher: Any = None
    tiktok: Any = None          # TikTokAuth

    @property
    def t(self):
        return self.lang.t

    @property
    def tzname(self) -> str:
        return self.settings.get("timezone", "Europe/Kyiv")

    def now_local(self) -> datetime:
        return timeutil.now_local(self.tzname)

    def to_local(self, utc_str: str) -> datetime:
        return timeutil.utc_str_to_local(utc_str, self.tzname)

    def to_utc(self, local: datetime) -> str:
        return timeutil.local_to_utc_str(local, self.tzname)
