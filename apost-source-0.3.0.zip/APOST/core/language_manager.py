"""Система локалізації: JSON-файли + підписники на зміну мови."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

from core import config
from core.settings_store import SettingsStore
from utils.logger import get_logger

log = get_logger("lang")

LANGUAGES = {"uk": "Українська", "en": "English"}
FALLBACK = "en"


class LanguageManager:
    def __init__(self, settings: SettingsStore, loc_dir: Path | None = None) -> None:
        self._settings = settings
        self._dir = loc_dir or config.LOCALIZATION_DIR
        self._tables: dict[str, dict[str, str]] = {}
        self._listeners: list[Callable[[], None]] = []
        self.code = settings.get("language", config.DEFAULT_LANGUAGE)
        if self.code not in LANGUAGES:
            self.code = config.DEFAULT_LANGUAGE
        self._load(self.code)
        self._load(FALLBACK)

    def _load(self, code: str) -> None:
        if code in self._tables:
            return
        path = self._dir / f"{code}.json"
        try:
            self._tables[code] = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            log.exception("Не вдалося завантажити переклад %s", path)
            self._tables[code] = {}

    def t(self, key: str, **kwargs) -> str:
        """Переклад ключа; якщо немає — англійський; інакше сам ключ."""
        text = self._tables.get(self.code, {}).get(key)
        if text is None:
            text = self._tables.get(FALLBACK, {}).get(key, key)
        if kwargs:
            try:
                return text.format(**kwargs)
            except (KeyError, IndexError):
                return text
        return text

    def subscribe(self, callback: Callable[[], None]) -> None:
        self._listeners.append(callback)

    def set_language(self, code: str, save: bool = True) -> None:
        if code not in LANGUAGES:
            raise ValueError(f"Непідтримувана мова: {code}")
        if code == self.code:
            return
        self._load(code)
        self.code = code
        if save:
            self._settings.set("language", code)
        for cb in list(self._listeners):
            try:
                cb()
            except Exception:
                log.exception("Помилка в обробнику зміни мови")
