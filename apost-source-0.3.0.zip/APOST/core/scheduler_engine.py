"""Фоновий рушій публікацій (APScheduler).

Принципи надійності:
* розклад живе в БД — після перезапуску нічого не втрачається;
* кожна публікація «забирається» атомарно (claim) — двічі не опублікується;
* якщо програма була закрита й час минув більш ніж на GRACE хвилин — це «Пропущено»
  (статус Помилка), програма НЕ вдає, що публікація відбулась;
* без доступу до API застосунок лише сповіщає і чекає ручного підтвердження.
"""
from __future__ import annotations

import os
from datetime import datetime, timezone

from apscheduler.schedulers.background import BackgroundScheduler

from core.database import Database
from core.notification_manager import NotificationManager
from core.settings_store import SettingsStore
from core.timeutil import DB_FMT, utcnow_str
from publisher.tiktok_api import TikTokError
from publisher.tiktok_publisher import BasePublisher
from utils.logger import get_logger

log = get_logger("engine")

GRACE_MINUTES = 15
TICK_SECONDS = 15
PROCESS_TIMEOUT_MIN = 90      # скільки чекаємо підтвердження від TikTok
KNOWN_ERRORS = {"reauth", "not_configured", "network", "keyring_unavailable", "privacy_not_allowed",
                "too_long", "spam_risk_too_many_posts", "spam_risk_user_banned_from_posting",
                "upload_failed", "timeout"}


def error_text(exc: Exception) -> str:
    """Код помилки (якщо для нього є переклад) або короткий текст."""
    if isinstance(exc, TikTokError):
        return exc.code if exc.code in KNOWN_ERRORS else str(exc)[:300]
    return str(exc)[:300]


def _minutes_late(now_utc: str, scheduled_utc: str) -> float:
    a = datetime.strptime(now_utc, DB_FMT).replace(tzinfo=timezone.utc)
    b = datetime.strptime(scheduled_utc, DB_FMT).replace(tzinfo=timezone.utc)
    return (a - b).total_seconds() / 60


class SchedulerEngine:
    def __init__(self, db: Database, settings: SettingsStore, publisher: BasePublisher,
                 notifier: NotificationManager) -> None:
        self.db, self.settings, self.publisher, self.notifier = db, settings, publisher, notifier
        self._sched: BackgroundScheduler | None = None

    # ---------- керування ----------
    @property
    def paused(self) -> bool:
        return bool(self.settings.get("scheduler_paused", False))

    @property
    def running(self) -> bool:
        return self._sched is not None and self._sched.running

    def state(self) -> str:
        if not self.running:
            return "stopped"
        return "paused" if self.paused else "running"

    def start(self) -> None:
        if self.running:
            return
        self.recover()
        self._sched = BackgroundScheduler(timezone="UTC")
        self._sched.add_job(self._safe_tick, "interval", seconds=TICK_SECONDS, id="tick",
                            max_instances=1, coalesce=True,
                            next_run_time=datetime.now(timezone.utc))
        self._sched.start()
        log.info("Планувальник запущено (пауза=%s)", self.paused)

    def stop(self) -> None:
        if self._sched is not None:
            try:
                self._sched.shutdown(wait=False)
            except Exception:
                log.exception("Помилка зупинки планувальника")
            self._sched = None

    def pause(self) -> None:
        self.settings.set("scheduler_paused", True)
        self.db.revision += 1

    def resume(self) -> None:
        self.settings.set("scheduler_paused", False)
        self.db.revision += 1

    # ---------- відновлення ----------
    def recover(self, now_utc: str | None = None) -> None:
        """Після запуску: перервані та пропущені завдання позначаються чесно."""
        for p in self.db.interrupted_posts():
            if p["publish_id"]:          # уже відправлено в TikTok — продовжимо перевіряти статус
                continue
            self.db.mark_error(p["id"], p["name"], "interrupted")
        self._flag_missed(now_utc or utcnow_str())

    def _flag_missed(self, now_utc: str) -> None:
        for p in self.db.due_posts(now_utc):
            if _minutes_late(now_utc, p["scheduled_at"]) > GRACE_MINUTES:
                self.db.mark_error(p["id"], p["name"], "missed")
                self.notifier.failed(p["name"], self.notifier.lang.t("error.missed"))

    # ---------- основний цикл ----------
    def _safe_tick(self) -> None:
        try:
            self.tick()
        except Exception:
            log.exception("Помилка в циклі планувальника")

    def tick(self, now_utc: str | None = None) -> None:
        if self.paused:
            return
        now_utc = now_utc or utcnow_str()
        for p in self.db.due_posts(now_utc):
            if _minutes_late(now_utc, p["scheduled_at"]) > GRACE_MINUTES:
                self.db.mark_error(p["id"], p["name"], "missed")
                self.notifier.failed(p["name"], self.notifier.lang.t("error.missed"))
                continue
            if not os.path.exists(p["path"]):
                self.db.mark_error(p["id"], p["name"], "file_missing")
                self.notifier.failed(p["name"], self.notifier.lang.t("error.file_missing"))
                continue
            if not self.db.claim_post(p["id"]):
                continue  # хтось інший уже забрав
            self._publish(dict(p))
        self._poll_processing(now_utc)

    def _publish(self, post: dict) -> None:
        try:
            res = self.publisher.publish(post)
        except Exception as exc:
            log.exception("Помилка публікації %s", post["name"])
            self._fail(post, error_text(exc))
            return
        self._apply(post, res)

    def _fail(self, post: dict, text: str) -> None:
        self.db.mark_error(post["id"], post["name"], text)
        self.notifier.failed(post["name"], self.notifier.lang.t(f"error.{text}")
                             if f"error.{text}" in self.notifier.lang._tables.get("en", {}) else text[:120])

    def _apply(self, post: dict, res) -> None:
        if res.state == "manual_required":
            self.db.mark_manual_due(post["id"], post["name"])
            self.notifier.time_to_publish(post["name"])
        elif res.state == "processing":
            if res.message:
                self.db.set_publish_id(post["id"], res.message)   # далі опитуємо статус у TikTok
        elif res.state == "inbox_ready":
            self.db.mark_manual_due(post["id"], post["name"], "inbox")
            self.notifier.inbox_ready(post["name"])
        elif res.state == "published":
            self.db.mark_published(post["id"], post["name"], "tiktok")   # лише за відповіддю TikTok
            self.notifier.published(post["name"])
        else:
            self._fail(post, res.message or "failed")

    def _poll_processing(self, now_utc: str) -> None:
        """Питає TikTok про фактичний статус відправлених відео (підтвердження публікації)."""
        for p in self.db.processing_posts():
            if _minutes_late(now_utc, p["updated_at"]) > PROCESS_TIMEOUT_MIN:
                self._fail(dict(p), "timeout")
                continue
            try:
                res = self.publisher.check_status(dict(p))
            except TikTokError as exc:
                if exc.needs_reauth:
                    self._fail(dict(p), "reauth")
                else:
                    log.warning("Статус %s тимчасово недоступний: %s", p["name"], exc)
                continue
            except Exception:
                log.exception("Помилка перевірки статусу %s", p["name"])
                continue
            if res.state != "processing":
                self._apply(dict(p), res)
