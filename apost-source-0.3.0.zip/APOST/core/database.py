"""SQLite: відео, публікації (черга/розклад) та історія.

* Усі дати зберігаються в UTC ('YYYY-MM-DD HH:MM:SS').
* Доступ потокобезпечний (планувальник працює у фоновому потоці).
* `revision` збільшується після кожного запису — UI за ним дізнається про зміни.
* Захист від повторної публікації: часткований унікальний індекс + «claim» одним UPDATE.
"""
from __future__ import annotations

import sqlite3
import threading
from pathlib import Path
from typing import Any, Iterable

from core.timeutil import utcnow_str
from utils.logger import get_logger

log = get_logger("db")

SCHEMA_VERSION = 2

SCHEMA = """
CREATE TABLE IF NOT EXISTS videos(
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    path          TEXT NOT NULL UNIQUE,
    original_name TEXT NOT NULL,
    is_copy       INTEGER NOT NULL DEFAULT 0,
    size_bytes    INTEGER NOT NULL DEFAULT 0,
    duration_sec  REAL,
    thumb_path    TEXT,
    fingerprint   TEXT,
    description   TEXT NOT NULL DEFAULT '',
    hashtags      TEXT NOT NULL DEFAULT '',
    added_at      TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS posts(
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    video_id     INTEGER NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
    scheduled_at TEXT,
    status       TEXT NOT NULL DEFAULT 'pending',
    position     INTEGER NOT NULL DEFAULT 0,
    paused       INTEGER NOT NULL DEFAULT 0,
    manual_due   INTEGER NOT NULL DEFAULT 0,
    error        TEXT,
    published_at TEXT,
    confirmed_by TEXT,
    publish_id   TEXT,
    created_at   TEXT NOT NULL,
    updated_at   TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_live_post ON posts(video_id)
    WHERE status IN ('pending','scheduled','posting','published');
CREATE INDEX IF NOT EXISTS ix_posts_sched ON posts(status, scheduled_at);
CREATE TABLE IF NOT EXISTS history(
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id     INTEGER,
    video_title TEXT NOT NULL,
    at          TEXT NOT NULL,
    status      TEXT NOT NULL,
    message     TEXT
);
CREATE INDEX IF NOT EXISTS ix_history_at ON history(at);
"""

POST_SELECT = """
SELECT p.*, v.path AS path, v.original_name AS name, v.description AS description,
       v.hashtags AS hashtags, v.thumb_path AS thumb_path, v.duration_sec AS duration_sec
FROM posts p JOIN videos v ON v.id = p.video_id
"""

POST_FIELDS = {"scheduled_at", "status", "position", "paused", "manual_due", "error",
               "published_at", "confirmed_by", "publish_id"}


class Database:
    def __init__(self, path: Path | str) -> None:
        self.path = str(path)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")
        try:
            self._conn.execute("PRAGMA journal_mode = WAL")
        except sqlite3.DatabaseError:
            pass
        self.revision = 0
        self._migrate()

    # ---------- службові ----------
    def _migrate(self) -> None:
        with self._lock:
            self._conn.executescript(SCHEMA)
            cols = {r[1] for r in self._conn.execute("PRAGMA table_info(posts)")}
            if "publish_id" not in cols:      # міграція v1 → v2
                self._conn.execute("ALTER TABLE posts ADD COLUMN publish_id TEXT")
            self._conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
            self._conn.commit()

    def close(self) -> None:
        with self._lock:
            try:
                self._conn.commit()
                self._conn.close()
            except sqlite3.Error:
                log.exception("Помилка закриття БД")

    def _read(self, sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
        with self._lock:
            return self._conn.execute(sql, tuple(params)).fetchall()

    def _one(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Row | None:
        rows = self._read(sql, params)
        return rows[0] if rows else None

    def _write(self, sql: str, params: Iterable[Any] = ()) -> sqlite3.Cursor:
        with self._lock:
            try:
                cur = self._conn.execute(sql, tuple(params))
                self._conn.commit()
            except sqlite3.Error:
                self._conn.rollback()
                raise
            self.revision += 1
            return cur

    def _log(self, post_id: int | None, title: str, status: str, message: str | None = None) -> None:
        self._conn.execute(
            "INSERT INTO history(post_id, video_title, at, status, message) VALUES (?,?,?,?,?)",
            (post_id, title, utcnow_str(), status, message))

    # ---------- відео ----------
    def add_video(self, *, path: str, original_name: str, is_copy: bool, size_bytes: int,
                  duration_sec: float | None, thumb_path: str | None, fingerprint: str | None,
                  description: str = "", hashtags: str = "") -> int:
        cur = self._write(
            """INSERT INTO videos(path, original_name, is_copy, size_bytes, duration_sec,
               thumb_path, fingerprint, description, hashtags, added_at)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (path, original_name, int(is_copy), size_bytes, duration_sec, thumb_path,
             fingerprint, description, hashtags, utcnow_str()))
        return int(cur.lastrowid)

    def find_video(self, *, path: str | None = None, fingerprint: str | None = None):
        if path is not None:
            r = self._one("SELECT * FROM videos WHERE path=?", (path,))
            if r:
                return r
        if fingerprint is not None:
            return self._one("SELECT * FROM videos WHERE fingerprint=?", (fingerprint,))
        return None

    def get_video(self, video_id: int):
        return self._one("SELECT * FROM videos WHERE id=?", (video_id,))

    def list_videos(self):
        return self._read(
            """SELECT v.*, (SELECT p.status FROM posts p WHERE p.video_id=v.id
                            ORDER BY p.id DESC LIMIT 1) AS post_status
               FROM videos v ORDER BY v.id DESC""")

    def update_video_text(self, video_id: int, description: str, hashtags: str) -> None:
        self._write("UPDATE videos SET description=?, hashtags=? WHERE id=?",
                    (description, hashtags, video_id))

    def delete_video(self, video_id: int):
        """Видаляє відео та його публікації (історія лишається). Повертає рядок відео."""
        row = self.get_video(video_id)
        if row:
            self._write("DELETE FROM videos WHERE id=?", (video_id,))
        return row

    # ---------- черга / публікації ----------
    def add_to_queue(self, video_ids: Iterable[int]) -> int:
        """Додає відео в кінець черги (лише ті, що ще не мають публікації)."""
        added = 0
        with self._lock:
            pos = self._conn.execute("SELECT COALESCE(MAX(position),0) FROM posts").fetchone()[0]
            now = utcnow_str()
            for vid in video_ids:
                if self._conn.execute("SELECT 1 FROM posts WHERE video_id=?", (vid,)).fetchone():
                    continue
                if not self._conn.execute("SELECT 1 FROM videos WHERE id=?", (vid,)).fetchone():
                    continue
                pos += 1
                self._conn.execute(
                    "INSERT INTO posts(video_id, status, position, created_at, updated_at) "
                    "VALUES (?, 'pending', ?, ?, ?)", (vid, pos, now, now))
                added += 1
            self._conn.commit()
            if added:
                self.revision += 1
        return added

    def get_post(self, post_id: int):
        return self._one(POST_SELECT + " WHERE p.id=?", (post_id,))

    def queue_posts(self):
        """Усе, що ще не опубліковано: очікує, заплановано, публікується, помилка."""
        return self._read(POST_SELECT + " WHERE p.status != 'published' ORDER BY p.position, p.id")

    def pending_posts(self):
        return self._read(POST_SELECT + " WHERE p.status='pending' ORDER BY p.position, p.id")

    def posts_between(self, start_utc: str, end_utc: str):
        return self._read(
            POST_SELECT + " WHERE p.scheduled_at >= ? AND p.scheduled_at < ? "
                          "ORDER BY p.scheduled_at", (start_utc, end_utc))

    def scheduled_times(self) -> list[str]:
        return [r[0] for r in self._read(
            "SELECT scheduled_at FROM posts WHERE scheduled_at IS NOT NULL "
            "AND status IN ('scheduled','posting')")]

    def update_post(self, post_id: int, **fields) -> None:
        bad = set(fields) - POST_FIELDS
        if bad:
            raise ValueError(f"Недопустимі поля: {bad}")
        if not fields:
            return
        sets = ", ".join(f"{k}=?" for k in fields)
        self._write(f"UPDATE posts SET {sets}, updated_at=? WHERE id=?",
                    (*fields.values(), utcnow_str(), post_id))

    def set_schedule(self, post_id: int, when_utc: str | None) -> None:
        """Призначає (або знімає) час публікації; скидає помилку та ручний режим."""
        p = self.get_post(post_id)
        if not p or p["status"] in ("posting", "published"):
            return
        status = "scheduled" if when_utc else "pending"
        self.update_post(post_id, scheduled_at=when_utc, status=status, manual_due=0, error=None)

    def set_paused(self, post_id: int, paused: bool) -> None:
        self.update_post(post_id, paused=int(paused))

    def remove_post(self, post_id: int) -> None:
        p = self.get_post(post_id)
        if p and p["status"] != "posting":
            self._write("DELETE FROM posts WHERE id=?", (post_id,))

    def move_post(self, post_id: int, direction: int) -> None:
        """direction = -1 (вгору) або +1 (вниз) серед елементів черги."""
        rows = list(self.queue_posts())
        ids = [r["id"] for r in rows]
        if post_id not in ids:
            return
        i, j = ids.index(post_id), ids.index(post_id) + direction
        if not 0 <= j < len(ids):
            return
        ids[i], ids[j] = ids[j], ids[i]
        with self._lock:
            for n, pid in enumerate(ids, start=1):
                self._conn.execute("UPDATE posts SET position=? WHERE id=?", (n, pid))
            self._conn.commit()
            self.revision += 1

    # ---------- життєвий цикл публікації ----------
    def due_posts(self, now_utc: str):
        return self._read(
            POST_SELECT + " WHERE p.status='scheduled' AND p.paused=0 AND p.manual_due=0 "
                          "AND p.scheduled_at <= ? ORDER BY p.scheduled_at", (now_utc,))

    def interrupted_posts(self):
        return self._read(POST_SELECT + " WHERE p.status='posting'")

    def processing_posts(self):
        """Публікації, відправлені в TikTok і ще не підтверджені (є publish_id)."""
        return self._read(POST_SELECT + " WHERE p.status='posting' AND p.publish_id IS NOT NULL")

    def set_publish_id(self, post_id: int, publish_id: str) -> None:
        self.update_post(post_id, publish_id=publish_id)

    def claim_post(self, post_id: int) -> bool:
        """Атомарно «забирає» публікацію: гарантує, що її візьме лише один виконавець."""
        cur = self._write(
            "UPDATE posts SET status='posting', updated_at=? "
            "WHERE id=? AND status='scheduled' AND manual_due=0 AND paused=0",
            (utcnow_str(), post_id))
        return cur.rowcount == 1

    def mark_manual_due(self, post_id: int, title: str, message: str | None = None) -> None:
        with self._lock:
            self._conn.execute(
                "UPDATE posts SET status='scheduled', manual_due=1, updated_at=? WHERE id=?",
                (utcnow_str(), post_id))
            self._log(post_id, title, "manual", message)
            self._conn.commit()
            self.revision += 1

    def mark_published(self, post_id: int, title: str, confirmed_by: str) -> None:
        with self._lock:
            self._conn.execute(
                "UPDATE posts SET status='published', manual_due=0, error=NULL, published_at=?, "
                "confirmed_by=?, updated_at=? WHERE id=?",
                (utcnow_str(), confirmed_by, utcnow_str(), post_id))
            self._log(post_id, title, "published", confirmed_by)
            self._conn.commit()
            self.revision += 1

    def mark_error(self, post_id: int, title: str, message: str) -> None:
        with self._lock:
            self._conn.execute(
                "UPDATE posts SET status='error', manual_due=0, error=?, updated_at=? WHERE id=?",
                (message, utcnow_str(), post_id))
            self._log(post_id, title, "error", message)
            self._conn.commit()
            self.revision += 1

    # ---------- статистика ----------
    def stats(self) -> dict[str, int]:
        def n(sql, *a):
            return self._one(sql, a)[0]
        return {
            "total_videos": n("SELECT COUNT(*) FROM videos"),
            "in_queue": n("SELECT COUNT(*) FROM posts WHERE status IN ('pending','scheduled','posting')"),
            "scheduled": n("SELECT COUNT(*) FROM posts WHERE status='scheduled'"),
            "published": n("SELECT COUNT(*) FROM posts WHERE status='published'"),
            "failed": n("SELECT COUNT(*) FROM posts WHERE status='error'"),
            "manual_due": n("SELECT COUNT(*) FROM posts WHERE manual_due=1 AND status='scheduled'"),
            "missed": n("SELECT COUNT(*) FROM posts WHERE status='error' AND error='missed'"),
        }

    def upcoming(self, limit: int = 5):
        return self._read(
            POST_SELECT + " WHERE p.status='scheduled' AND p.scheduled_at IS NOT NULL "
                          "ORDER BY p.manual_due DESC, p.scheduled_at LIMIT ?", (limit,))

    def history(self, status: str | None = None, from_utc: str | None = None,
                to_utc: str | None = None, limit: int = 500):
        sql, params = "SELECT * FROM history WHERE 1=1", []
        if status:
            sql += " AND status=?"; params.append(status)
        if from_utc:
            sql += " AND at >= ?"; params.append(from_utc)
        if to_utc:
            sql += " AND at < ?"; params.append(to_utc)
        sql += " ORDER BY at DESC, id DESC LIMIT ?"; params.append(limit)
        return self._read(sql, params)
