"""Централізована система тем.

Кожен колір — кортеж (light, dark). CustomTkinter сам обирає потрібне значення
залежно від режиму, тому тема перемикається миттєво для ВСІХ віджетів без
перезапуску й без ручного оновлення.
"""
from __future__ import annotations

import customtkinter as ctk

from core.settings_store import SettingsStore

#                          світла      темна
PALETTE: dict[str, tuple[str, str]] = {
    "bg":             ("#FFFFFF", "#090909"),
    "bg_secondary":   ("#F5F5F5", "#1C1C1C"),
    "accent":         ("#2563EB", "#7C3AED"),
    "accent_hover":   ("#1D4ED8", "#6D28D9"),
    "accent_text":    ("#FFFFFF", "#FFFFFF"),
    "text":           ("#111111", "#FFFFFF"),
    "text_secondary": ("#666666", "#AAAAAA"),
    "border":         ("#E2E2E2", "#2E2E2E"),
    "grid":           ("#D4D4DA", "#3A3A3F"),
    "hover":          ("#EAEAEA", "#262626"),
    "disabled":       ("#B5B5B5", "#555555"),
    # статуси публікацій
    "status_pending":   ("#6B7280", "#9CA3AF"),
    "status_scheduled": ("#2563EB", "#A78BFA"),
    "status_posting":   ("#D97706", "#FBBF24"),
    "status_published": ("#16A34A", "#4ADE80"),
    "status_error":     ("#DC2626", "#F87171"),
}


class ThemeManager:
    MODES = ("light", "dark")

    def __init__(self, settings: SettingsStore) -> None:
        self._settings = settings
        self._mode = settings.get("theme", "light")

    @property
    def mode(self) -> str:
        return self._mode

    @staticmethod
    def color(name: str) -> tuple[str, str]:
        return PALETTE[name]

    def apply(self, mode: str | None = None, save: bool = True) -> None:
        """Застосовує тему миттєво. Без аргументу — застосовує збережену."""
        mode = mode or self._mode
        if mode not in self.MODES:
            raise ValueError(f"Невідома тема: {mode}")
        self._mode = mode
        ctk.set_appearance_mode("Dark" if mode == "dark" else "Light")
        if save:
            self._settings.set("theme", mode)
