"""Чиста логіка розподілу відео за розкладом (без UI та БД — легко тестується)."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta


@dataclass
class ScheduleConfig:
    per_day: int = 3
    first: time = time(12, 0)
    last: time = time(20, 0)
    start: date | None = None          # None → сьогодні
    end: date | None = None            # None → без обмеження
    weekdays: set[int] = field(default_factory=lambda: set(range(7)))  # 0=Пн

    def validate(self) -> str | None:
        """Повертає код помилки або None."""
        if not 1 <= self.per_day <= 24:
            return "per_day"
        if self.per_day > 1 and self.last <= self.first:
            return "time_order"
        if not self.weekdays:
            return "no_weekdays"
        if self.start and self.end and self.end < self.start:
            return "date_order"
        return None


def day_times(cfg: ScheduleConfig) -> list[time]:
    """Час публікацій протягом дня: рівномірно від першої до останньої (включно)."""
    if cfg.per_day == 1:
        return [cfg.first]
    a = cfg.first.hour * 60 + cfg.first.minute
    b = cfg.last.hour * 60 + cfg.last.minute
    step = (b - a) / (cfg.per_day - 1)
    out = []
    for i in range(cfg.per_day):
        m = round(a + step * i)
        out.append(time(m // 60, m % 60))
    return out


def interval_minutes(cfg: ScheduleConfig) -> int:
    if cfg.per_day <= 1:
        return 0
    a = cfg.first.hour * 60 + cfg.first.minute
    b = cfg.last.hour * 60 + cfg.last.minute
    return round((b - a) / (cfg.per_day - 1))


def last_from_interval(first: time, per_day: int, interval: int) -> time | None:
    """Час останньої публікації за інтервалом; None, якщо виходить за межі доби."""
    m = first.hour * 60 + first.minute + interval * max(per_day - 1, 0)
    if m >= 24 * 60:
        return None
    return time(m // 60, m % 60)


def generate_slots(cfg: ScheduleConfig, count: int, now: datetime,
                   taken: set[datetime] | None = None, max_days: int = 3650) -> list[datetime]:
    """До `count` вільних майбутніх слотів (локальний naive-час).

    * слоти раніше за `now` (+1 хв) пропускаються;
    * слоти з `taken` (вже зайняті іншими публікаціями) пропускаються;
    * зупиняється на даті завершення (якщо задана), тож може повернути менше за `count`.
    """
    taken = taken or set()
    times = day_times(cfg)
    day = max(cfg.start or now.date(), now.date())
    threshold = now + timedelta(minutes=1)
    slots: list[datetime] = []
    for _ in range(max_days):
        if len(slots) >= count or (cfg.end and day > cfg.end):
            break
        if day.weekday() in cfg.weekdays:
            for t in times:
                dt = datetime.combine(day, t)
                if dt >= threshold and dt not in taken:
                    slots.append(dt)
                    if len(slots) >= count:
                        break
        day += timedelta(days=1)
    return slots


def parse_time(text: str) -> time | None:
    try:
        h, m = text.strip().split(":")
        return time(int(h), int(m))
    except (ValueError, AttributeError):
        return None


def parse_date(text: str) -> date | None:
    try:
        return datetime.strptime(text.strip(), "%Y-%m-%d").date()
    except (ValueError, AttributeError):
        return None
