"""Імпорт, перевірка та видалення відео."""
from __future__ import annotations

import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from core import config
from core.database import Database
from core.settings_store import SettingsStore
from utils import video_utils
from utils.file_utils import free_space_mb
from utils.logger import get_logger

log = get_logger("videos")

MIN_FREE_MB = 300
ALLOWED_EXT = (".mp4", ".mov", ".m4v", ".webm")   # формати, які приймає TikTok


@dataclass
class ImportResult:
    added: list[int] = field(default_factory=list)
    skipped: list[tuple[str, str]] = field(default_factory=list)  # (шлях, код причини)


def normalize_hashtags(text: str) -> str:
    """'a, #b  c' → '#a #b #c' (без дублікатів, зберігає порядок)."""
    seen, out = set(), []
    for tok in re.split(r"[\s,;]+", text.strip()):
        tok = tok.lstrip("#").strip()
        if not tok:
            continue
        tag = "#" + tok
        if tag.lower() not in seen:
            seen.add(tag.lower())
            out.append(tag)
    return " ".join(out)


def build_caption(description: str, hashtags: str) -> str:
    return (description.strip() + "\n\n" + hashtags.strip()).strip()


class VideoManager:
    def __init__(self, db: Database, settings: SettingsStore) -> None:
        self.db = db
        self.settings = settings

    def validate(self, path: Path) -> str | None:
        if not path.is_file():
            return "not_found"
        if path.suffix.lower() not in ALLOWED_EXT:
            return "not_mp4"
        if path.stat().st_size == 0:
            return "empty"
        return None

    def import_files(self, paths: list[str],
                     progress: Callable[[int, int], None] | None = None) -> ImportResult:
        result = ImportResult()
        total = len(paths)
        for i, raw in enumerate(paths, start=1):
            path = Path(raw).expanduser()
            try:
                self._import_one(path, result)
            except Exception:
                log.exception("Помилка імпорту %s", path)
                result.skipped.append((str(path), "error"))
            if progress:
                progress(i, total)
        return result

    def _import_one(self, path: Path, result: ImportResult) -> None:
        reason = self.validate(path)
        if reason:
            result.skipped.append((str(path), reason)); return
        fp = video_utils.fingerprint(path)
        if self.db.find_video(path=str(path), fingerprint=fp):
            result.skipped.append((str(path), "duplicate")); return
        info = video_utils.probe(path)
        if not info.ok:
            result.skipped.append((str(path), "unreadable")); return

        size = path.stat().st_size
        stored, is_copy = path, False
        if self.settings.get("copy_videos", False):
            config.ensure_dirs()
            if free_space_mb(config.VIDEOS_DIR) < size // (1024 * 1024) + MIN_FREE_MB:
                result.skipped.append((str(path), "no_space")); return
            stored = config.VIDEOS_DIR / f"{fp[:10]}_{path.name}"
            shutil.copy2(path, stored)
            is_copy = True

        thumb = config.THUMBS_DIR / f"{fp[:16]}.jpg"
        thumb_ok = video_utils.make_thumbnail(stored, thumb, info.duration)
        vid = self.db.add_video(
            path=str(stored), original_name=path.name, is_copy=is_copy, size_bytes=size,
            duration_sec=info.duration, thumb_path=str(thumb) if thumb_ok else None,
            fingerprint=fp)
        result.added.append(vid)

    def delete_video(self, video_id: int) -> None:
        """Видаляє запис і мініатюру. Оригінальні файли користувача НЕ чіпає (лише власні копії)."""
        row = self.db.delete_video(video_id)
        if not row:
            return
        for p, own in ((row["thumb_path"], True), (row["path"], bool(row["is_copy"]))):
            if p and own:
                try:
                    Path(p).unlink(missing_ok=True)
                except OSError:
                    log.warning("Не вдалося видалити %s", p)
