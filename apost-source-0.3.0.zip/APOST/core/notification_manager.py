"""Системні сповіщення (macOS — через osascript, без додаткових залежностей)."""
from __future__ import annotations

import subprocess
import sys

from core.language_manager import LanguageManager
from core.settings_store import SettingsStore
from utils.logger import get_logger

log = get_logger("notify")


class NotificationManager:
    def __init__(self, settings: SettingsStore, lang: LanguageManager) -> None:
        self.settings = settings
        self.lang = lang

    def _allowed(self, kind: str) -> bool:
        if not self.settings.get("notify_enabled", True):
            return False
        return bool(self.settings.get("notify_scheduled" if kind == "scheduled" else "notify_errors", True))

    def send(self, kind: str, title: str, body: str) -> None:
        log.info("Сповіщення [%s] %s — %s", kind, title, body)
        if not self._allowed(kind):
            return
        if sys.platform == "darwin":
            esc = lambda s: s.replace("\\", "\\\\").replace('"', '\\"')
            script = f'display notification "{esc(body)}" with title "{esc(title)}"'
            try:
                subprocess.Popen(["osascript", "-e", script])
            except OSError:
                log.exception("Не вдалося показати сповіщення")

    def time_to_publish(self, video_name: str) -> None:
        t = self.lang.t
        self.send("scheduled", t("notify.due.title"), t("notify.due.body", name=video_name))

    def failed(self, video_name: str, reason: str) -> None:
        t = self.lang.t
        self.send("error", t("notify.error.title"), f"{video_name}: {reason}")

    def inbox_ready(self, video_name: str) -> None:
        t = self.lang.t
        self.send("scheduled", t("notify.inbox.title"), t("notify.inbox.body", name=video_name))

    def published(self, video_name: str) -> None:
        t = self.lang.t
        self.send("scheduled", t("notify.published.title"), t("notify.published.body", name=video_name))
