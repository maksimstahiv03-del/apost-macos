"""APOST — точка входу."""
from __future__ import annotations

import sys
import traceback

from core import config
from utils.logger import setup_logging


def main() -> int:
    config.ensure_dirs()
    logger = setup_logging()
    logger.info("Запуск %s %s (%s)", config.APP_NAME, config.APP_VERSION, sys.platform)

    from core.bootstrap import build_context
    from ui.app_window import AppWindow

    ctx = build_context()
    app = AppWindow(ctx)

    def on_tk_error(exc, val, tb):   # помилки в callback-ах Tk не мають «мовчати»
        logger.error("Необроблена помилка UI:\n%s", "".join(traceback.format_exception(exc, val, tb)))
    app.report_callback_exception = on_tk_error

    ctx.engine.start()               # відновлення розкладу + фоновий планувальник
    try:
        app.mainloop()
    finally:
        ctx.engine.stop()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:
        logger = setup_logging()
        logger.exception("Критична помилка під час запуску")
        raise
